package com.aa.android_public.utils;

import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.aa.android_public.activity.MainActivity;
import com.alibaba.fastjson.JSONObject;
import com.support.fastthink.BaseParam;
import com.support.fastthink.network.OkHttpManager;
import com.support.fastthink.network.Param;
import com.support.fastthink.network.PathConstant;
import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.SPUtils;
import com.support.fastthink.utils.UniformString;
import com.support.fastthink.utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class MainUtils {
    /**
     * 回到当前APP主页
     */
    public static void backAPP() {
        try {
            Intent intent = new Intent(Utils.getContext(), MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            Utils.getContext().startActivity(intent);
        } catch (Exception e) {
        }
    }

    /**
     * 活跃状态检测
     *
     * @param context
     * @param type
     */
    public static void setActive(Context context, String type) {
        //发送到主页
        Intent broadCastIntent = new Intent();
        broadCastIntent.putExtra(UniformString.ACTIVETYPE, type);
        broadCastIntent.setAction(UniformString.ACTIVE_HOME_ACTION);
        context.sendBroadcast(broadCastIntent);
    }

    /**
     * 判断支付宝是否运行
     *
     * @param context
     * @return
     */
    public static boolean isAlipayRunning(Context context) {
        if (Utils.isAppRunning(context, "com.eg.android.AlipayGphone")) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 跳转到支付宝APP
     *
     * @param context
     */
    public static void LaunchAlipay(Context context) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage("com.eg.android.AlipayGphone");
        if (intent != null) {
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        }

        try {
            Thread.sleep(300);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        backAPP();
    }


    /**
     * 判断微信是否运行
     *
     * @param context
     * @return
     */
    public static boolean isWeChatRunning(Context context) {
        if (Utils.isAppRunning(context, "com.tencent.mm")) {
            return true;
        } else {
            return false;
        }
    }


    /**
     * 跳转到微信APP
     *
     * @param context
     */
    public static void LaunchWeChat(Context context) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage("com.tencent.mm");
        if (intent != null) {
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        }

        try {
            Thread.sleep(300);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        backAPP();
    }


//获取手机的唯一标识

    public static String getPesudoUniqueID() {
        String m_szDevIDShort = "35" + //we make this look like a valid IMEI
                Build.BOARD.length() % 10 +
                Build.BRAND.length() % 10 +
                Build.CPU_ABI.length() % 10 +
                Build.DEVICE.length() % 10 +
                Build.DISPLAY.length() % 10 +
                Build.HOST.length() % 10 +
                Build.ID.length() % 10 +
                Build.MANUFACTURER.length() % 10 +
                Build.MODEL.length() % 10 +
                Build.PRODUCT.length() % 10 +
                Build.TAGS.length() % 10 +
                Build.TYPE.length() % 10 +
                Build.USER.length() % 10; //13 digits
        System.out.println("当前的唯一设备id" + m_szDevIDShort);
        return m_szDevIDShort;
    }


    public static void postGetway(final Context context, int type,final boolean isOpen) {
        //type 1,支付宝  2,微信
        String alipayAcount = SPUtils.getInstance().getString(BaseParam.ALIPAY, "");
        String wechatAccount = SPUtils.getInstance().getString(BaseParam.WECHAT, "");

        List<Param> params = new ArrayList<Param>();
        params.add(new Param("merchants_id", "" + SPUtils.getInstance().getInt(BaseParam.MERCHANTSID)));
        if (type==2){
            params.add(new Param("wechatid", wechatAccount));
        }else {
            params.add(new Param("alipayid", alipayAcount));
        }


        params.add(new Param("bool", isOpen + ""));

        OkHttpManager.getInstance().post(params, PathConstant.URL_GETAWAY, new OkHttpManager.HttpCallBack() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                LogUtils.sendConsole(context,"请求网关参数"+isOpen+"，网关接口返回" + jsonObject.toJSONString());
            }

            @Override
            public void onFailure(String errorMsg) {
                //失败
                LogUtils.sendConsole(context,"请求网关参数"+isOpen+"，网关接口返回失败" + errorMsg);
            }
        });
    }
}
