package com.aa.android_public.hook;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;

import com.support.fastthink.data.XmlToJson;
import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.UniformString;

import org.json.JSONObject;

import java.lang.reflect.Field;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * 微信Hook
 */
public class WechatHook {

    public void hook(final ClassLoader appClassLoader, final Context context) {
        // TODO Auto-generated method stub

        XposedHelpers.findAndHookMethod("com.tencent.wcdb.database.SQLiteDatabase", appClassLoader, "insert", String.class, String.class, ContentValues.class,
                new XC_MethodHook() {

                    @Override
                    protected void beforeHookedMethod(MethodHookParam param)
                            throws Throwable {
                        try {
                            ContentValues contentValues = (ContentValues) param.args[2];
                            String tableName = (String) param.args[0];
                            if (TextUtils.isEmpty(tableName) || !tableName.equals("message")) {
                                return;
                            }
                            Integer type = contentValues.getAsInteger("type");
                            if (null == type) {
                                return;
                            }
                            if (type == 318767153) {
                                LogUtils.sendLogger("======微信start=========");

                                JSONObject msg = new XmlToJson.Builder(contentValues.getAsString("content")).build().getJSONObject("msg");
                                LogUtils.sendLogger("1收到微信支付订单完整数据：" + msg.toString());

                                String money = msg.getJSONObject("appmsg").getJSONObject("mmreader").getJSONObject("template_detail").getJSONObject("line_content").getJSONObject("topline").getJSONObject("value").getString("word");
                                String mark = msg.getJSONObject("appmsg").getJSONObject("mmreader").getJSONObject("template_detail").getJSONObject("line_content").getJSONObject("lines").getJSONArray("line").getJSONObject(0).getJSONObject("value").getString("word");
                                String pay_outtradeno = msg.getJSONObject("appmsg").getString("template_id");
                                LogUtils.sendLogger("2收到微信支付订单： 订单号：" + pay_outtradeno + " 金额：" + money + " 备注：" + mark);

                                Intent broadCastIntent = new Intent();
                                broadCastIntent.putExtra("bill_no", pay_outtradeno);
                                broadCastIntent.putExtra("bill_money", money.replace("￥", ""));
                                broadCastIntent.putExtra("bill_mark", mark);
                                broadCastIntent.putExtra("bill_type", UniformString.WECHAT);
                                broadCastIntent.setAction(UniformString.BILLRECEIVED_ACTION);
                                context.sendBroadcast(broadCastIntent);
                                LogUtils.sendLogger("======微信end=========");
                            }
                        } catch (Exception e) {
                            LogUtils.sendLogger("收到微信支付订单异常：" + e.getMessage());
                        }
                    }

                    @Override
                    protected void afterHookedMethod(MethodHookParam param)
                            throws Throwable {
                    }
                });

        try {
            Class<?> clazz = XposedHelpers.findClass("com.tencent.mm.plugin.collect.b.s", appClassLoader);
            XposedBridge.hookAllMethods(clazz, "a", new XC_MethodHook() {

                @Override
                protected void beforeHookedMethod(MethodHookParam param)
                        throws Throwable {
                }

                @Override
                protected void afterHookedMethod(MethodHookParam param)
                        throws Throwable {
//					double money=XposedHelpers.getDoubleField(param.thisObject, "llG");

//                    Field moneyField = XposedHelpers.findField(param.thisObject.getClass(), "llG");
//                    double money = (double) moneyField.get(param.thisObject);
//
//                    Field markField = XposedHelpers.findField(param.thisObject.getClass(), "desc");
//                    String mark = (String) markField.get(param.thisObject);
//
//                    Field payurlField = XposedHelpers.findField(param.thisObject.getClass(), "llF");
//                    String payurl = (String) payurlField.get(param.thisObject);
                    Field moneyField = XposedHelpers.findField(param.thisObject.getClass(), "kcp");
                    double money = (double) moneyField.get(param.thisObject);

                    Field markField = XposedHelpers.findField(param.thisObject.getClass(), "desc");
                    String mark = (String) markField.get(param.thisObject);

                    Field payurlField = XposedHelpers.findField(param.thisObject.getClass(), "kco");
                    String payurl = (String) payurlField.get(param.thisObject);

//					AlipayTradeUtils.addQrCode(money+"", mark, "wechat", payurl);
                    Intent broadCastIntent = new Intent();
                    broadCastIntent.putExtra("money", money + "");
                    broadCastIntent.putExtra("mark", mark);
                    broadCastIntent.putExtra("type", UniformString.WECHAT);
                    broadCastIntent.putExtra("payurl", payurl);
                    broadCastIntent.setAction(UniformString.QRCODERECEIVED_ACTION);
                    context.sendBroadcast(broadCastIntent);

                    LogUtils.setConsoleLogger(context, "微信实时码生成：4" + " 金额：" + money + " 备注：" + mark + " 二维码链接：" + payurl);

                }
            });

        } catch (Exception e) {
        }
        try {
            XposedHelpers.findAndHookMethod("com.tencent.mm.plugin.collect.ui.CollectCreateQRCodeUI", appClassLoader, "initView",
                    new XC_MethodHook() {

                        @Override
                        protected void beforeHookedMethod(MethodHookParam param)
                                throws Throwable {
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param)
                                throws Throwable {
                            XposedBridge.log("Hook微信开始......");
                            Intent intent = ((Activity) param.thisObject).getIntent();
                            String mark = intent.getStringExtra("mark");
                            String money = intent.getStringExtra("money");
//                            //获取WalletFormView控件
//                            Field WalletFormViewField = XposedHelpers.findField(param.thisObject.getClass(), "loz");
//                            Object WalletFormView = WalletFormViewField.get(param.thisObject);
//                            Class<?> WalletFormViewClass = XposedHelpers.findClass("com.tencent.mm.wallet_core.ui.formview.WalletFormView", appClassLoader);
//                            //获取金额控件
//                            Field AefField = XposedHelpers.findField(WalletFormViewClass, "Aef");
//                            Object AefView = AefField.get(WalletFormView);
//                            //call设置金额方法
//                            XposedHelpers.callMethod(AefView, "setText", money);
//                            //call设置备注方法
//                            Class<?> clazz = XposedHelpers.findClass("com.tencent.mm.plugin.collect.ui.CollectCreateQRCodeUI", appClassLoader);
//                            XposedHelpers.callStaticMethod(clazz, "a", param.thisObject, mark);
//                            XposedHelpers.callStaticMethod(clazz, "c", param.thisObject);
//                            //点击确定
//                            Button click = (Button) XposedHelpers.callMethod(param.thisObject, "findViewById", 2131756780);
//                            click.performClick();

                            Field WalletFormViewField = XposedHelpers.findField(param.thisObject.getClass(), "kff");
                            Object WalletFormView = WalletFormViewField.get(param.thisObject);
                            Class<?> WalletFormViewClass=XposedHelpers.findClass("com.tencent.mm.wallet_core.ui.formview.WalletFormView", appClassLoader);
                            //获取金额控件
                            Field AefField = XposedHelpers.findField(WalletFormViewClass, "zsl");
                            Object AefView = AefField.get(WalletFormView);
                            //call设置金额方法
                            XposedHelpers.callMethod(AefView, "setText", money);
                            XposedBridge.log("Hook微信开始设置收款码.....1.");
                            //call设置备注方法
                            Class<?> clazz=XposedHelpers.findClass("com.tencent.mm.plugin.collect.ui.CollectCreateQRCodeUI", appClassLoader);
                            XposedHelpers.callStaticMethod(clazz, "a", param.thisObject,mark);
                            XposedHelpers.callStaticMethod(clazz, "c", param.thisObject);
                            //点击确定
//2131822831新
//					Button click=(Button)XposedHelpers.callMethod(param.thisObject, "findViewById",2131756780);
                            Button click=(Button)XposedHelpers.callMethod(param.thisObject, "findViewById",2131822831);
                            click.performClick();

                            LogUtils.setConsoleLogger(context, "微信实时码生成：3" + " 金额：" + money + " 备注：" + mark);

                        }
                    });
//            com.tencent.mm.plugin.setting.ui.setting, Unknown, version 0.0=======SettingsAboutMicroMsgUI
            //保活
            XposedHelpers.findAndHookMethod("com.tencent.mm.plugin.setting.ui.setting.SettingsAboutMicroMsgUI", appClassLoader, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    LogUtils.setConsoleLogger(context, "微信保活---2finish");
                    Intent intent = ((Activity) param.thisObject).getIntent();
                    String isrun = intent.getStringExtra("isrun");
                    if (isrun == null) {

                    } else {
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.setAction(UniformString.LIVE_HOME_ACTION_START);
                        context.sendBroadcast(broadCastIntent);
                        XposedHelpers.callMethod(param.thisObject, "finish", new Object[0]);
                    }

                }
            });

        } catch (Exception e) {
        }

    }
}
