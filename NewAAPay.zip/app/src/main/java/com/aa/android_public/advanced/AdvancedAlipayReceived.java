package com.aa.android_public.advanced;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import de.robv.android.xposed.XposedHelpers;

/**
 * 高级功能----转账广播
 */
public class AdvancedAlipayReceived extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getStringExtra("type").equals("transfer")) {
            //转账支付宝账号
            //每次转账钱，blanceBean要设置 初始值，
            AlipayTransferHook.blanceBean.setNow(false);
            AlipayTransferHook.blanceBean.setNowRemark( intent.getStringExtra("remark"));
            AlipayTransferHook.blanceBean.setGetBlance(false);
            AlipayTransferHook.blanceBean.setBlance(0);

            AlipayTransferHook.isDownTranfer=true;
            AlipayTransferHook.transferMoneyType=intent.getBooleanExtra("isall",true);

            AlipayTransferHook.transferType = intent.getStringExtra("type");
            AlipayTransferHook.transferAccount = intent.getStringExtra("account");
            AlipayTransferHook.transferPw = intent.getStringExtra("pw");
            AlipayTransferHook.transferAmount = intent.getStringExtra("amount");
            AlipayTransferHook.transferRemark = intent.getStringExtra("remark");
            Intent intent4 = new Intent(context, XposedHelpers.findClass("com.alipay.mobile.transferapp.ui.TFToAccountInputActivity_", context.getClassLoader()));
            intent4.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent4);
        } else if (intent.getStringExtra("type").equals("transferCard")) {
            System.out.println("。。。。。。。。。。。。。。。。test2019");
            //每次转账钱，blanceBean要设置 初始值
            AlipayTransferHook.blanceBean.setNow(false);
            AlipayTransferHook.blanceBean.setNowRemark( intent.getStringExtra("remark"));
            AlipayTransferHook.blanceBean.setGetBlance(false);
            AlipayTransferHook.blanceBean.setBlance(0);

            AlipayTransferHook.isDownTranfer=true;
            AlipayTransferHook.transferMoneyType=intent.getBooleanExtra("isall",true);
            //转账银行卡
            AlipayTransferHook.transferType = intent.getStringExtra("type");
            AlipayTransferHook.transferName = intent.getStringExtra("name");
            AlipayTransferHook.transferCard = intent.getStringExtra("card");
            AlipayTransferHook.transferPw = intent.getStringExtra("pw");
            AlipayTransferHook.transferAmount = intent.getStringExtra("amount");
            AlipayTransferHook.transferRemark = intent.getStringExtra("remark");
            Intent intent4 = new Intent(context, XposedHelpers.findClass("com.alipay.mobile.transferapp.ui.TransferToCardFormActivity_", context.getClassLoader()));
            intent4.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent4);
        }

    }
}
