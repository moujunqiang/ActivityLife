package com.aa.android_public.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.aa.android_public.R;
import com.aa.android_public.utils.BalanceAdapter;
import com.support.fastthink.BaseActivity;
import com.support.fastthink.BaseParam;
import com.support.fastthink.entity.BalanceBean;
import com.support.fastthink.network.OkHttpManager;
import com.support.fastthink.network.Param;
import com.support.fastthink.network.PathConstant;
import com.support.fastthink.refresh.RefreshSwipeMenuListView;
import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.SPUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 余额详情
 */
public class BalanceDetailActivity extends BaseActivity implements RefreshSwipeMenuListView.OnRefreshListener {
    private RefreshSwipeMenuListView lvBalanceList;
    private BalanceAdapter balanceAdapter;
    private List<BalanceBean.DataBean> dataBeanList = new ArrayList<>();
    boolean onRefresh = false;
    private int refresh = 1;//页数

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_balance_detail);
        initView();
        getBalanceList(refresh);
    }

    private void initView() {
        //返回
        this.findViewById(R.id.tv_home_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        //列表
        balanceAdapter = new BalanceAdapter(this);
        lvBalanceList = findViewById(R.id.lv_balance_detail_list);
        lvBalanceList.setListViewMode(RefreshSwipeMenuListView.BOTH);
        lvBalanceList.setAdapter(balanceAdapter, RefreshSwipeMenuListView.BOTH);
        lvBalanceList.setOnRefreshListener(this);

    }


    /**
     * @param page//页数
     */
    public void getBalanceList(int page) {

        List<Param> params = new ArrayList<Param>();
        params.add(new Param("merchant_id", SPUtils.getInstance().getInt(BaseParam.MERCHANTSID) + ""));
        params.add(new Param("page", page + ""));

        OkHttpManager.getInstance().post(params, PathConstant.URL_BALANCE, new OkHttpManager.HttpCallBack() {
            @Override
            public void onResponse(JSONObject jsonObject) {

                BalanceBean bean = null;
                try {
                    bean = JSON.parseObject(jsonObject.toString(), BalanceBean.class);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (bean!=null&&bean.getCode() == 1) {
                    if (bean.getData() != null && bean.getData().size() > 0) {
                        if (refresh == 1) {
                            balanceAdapter.addWithClear(bean.getData());
                        } else {
                            balanceAdapter.addAll(bean.getData());
                        }
                    }

                } else if (bean!=null&&bean.getCode() == 0) {
                    if (refresh == 1) {
                        showToast("暂无数据！");
                    } else {
                        showToast("已加载全部数据！");
                    }
                } else {
                    if (bean != null && bean.getMsg() != null) {
                        showDialog(bean.getMsg());
                    } else if (bean != null) {
                        showDialog(bean.getCode());
                    } else {
                        showDialog("获取余额明细列表失败！");
                    }
                }
            }

            @Override
            public void onFailure(String errorMsg) {
                showDialog(errorMsg);
            }
        });
    }

    //下拉刷新
    @Override
    public void onRefresh() {
        if (onRefresh == false) {
            onRefresh = true;
            refresh = 1;
            //下拉中，持续下拉不再刷新，停止后再刷新
            lvBalanceList.postDelayed(new Runnable() {
                @Override
                public void run() {
                    onRefresh = false;
                    lvBalanceList.complete();//listview停止刷新动画
                    getBalanceList(refresh);
                    LogUtils.sendLogger("下拉刷新");
                }
            }, 1000);
        }

    }

    //上拉加载
    @Override
    public void onLoadMore() {
        refresh++;
        lvBalanceList.postDelayed(new Runnable() {
            @Override
            public void run() {
                lvBalanceList.complete();
                getBalanceList(refresh);
                LogUtils.sendLogger("上拉加载  " + "页数：" + refresh + "   数量：" + dataBeanList.size());
            }
        }, 2000);
    }

}
