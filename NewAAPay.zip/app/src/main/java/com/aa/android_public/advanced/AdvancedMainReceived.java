package com.aa.android_public.advanced;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.aa.android_public.utils.MainUtils;
import com.support.fastthink.BaseParam;
import com.support.fastthink.network.OkHttpManager;
import com.support.fastthink.network.Param;
import com.support.fastthink.network.PathConstant;
import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.SPUtils;
import com.support.fastthink.utils.UniformString;
import com.support.fastthink.utils.Utils;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class AdvancedMainReceived extends BroadcastReceiver {
    //
    static Vector<String> ListTranferCreate = new Vector<String>();
    static Vector<String> ListOrderCreate = new Vector<String>();

    public AdvancedMainReceived() {
        ListTranferCreate.clear();
        ListOrderCreate.clear();
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            if (intent.getAction().contentEquals(UniformString.ALIPAY_BACK_TRANFER)) {
                //
                System.out.println("跳转回主页2");
                MainUtils.backAPP();
            } else if (intent.getAction().contentEquals(UniformString.ALIPAY_BACK_TRANFER1)) {
                //
                System.out.println("跳转回主页3");
                Toast.makeText(context, "\n 余额不足，转账取消"
                        + "\n--------------------", Toast.LENGTH_SHORT).show();
                LogUtils.setConsoleCollection(context, "\n 余额不足，转账取消"
                        + "\n--------------------");
                MainUtils.backAPP();

            } else if (intent.getAction().contentEquals(UniformString.ALIPAY_TRANFER)) {
                //支付宝转账 结束
                MainUtils.backAPP();
                String order = intent.getStringExtra("remark");
                if (order.equals("")) {
                    return;
                } else if (ListTranferCreate.contains(order)) {
                    return;
                } else {
                    //跳转回来进行统计等
                    BaseParam.isOnresume = false;
                    postGetway(context, true, intent);
                    ListTranferCreate.add(order);
                    System.out.println("转账完成" + order);
                    String amount = intent.getStringExtra("amount");

                    BaseParam.nowBlanceAlipay = BaseParam.nowBlanceAlipay - Float.parseFloat(amount.replace("￥", ""));
                    if (BaseParam.nowBlanceAlipay <= 0) {
                        BaseParam.nowBlanceAlipay = 0;
                    }
                }
            } else if (intent.getAction().contentEquals(UniformString.ALIPAY_GET_TRANFER)) {
                //收到去转账的 广播，先发送请求到后台，让后台断开网关，然后去转账，转账完成后，再去连接 （中断心跳）
                String remark = intent.getStringExtra("remark");
                //去重
                if (ListOrderCreate.contains(remark)) {
                    return;
                } else {
                    ListOrderCreate.add(remark);
                    postGetway(context, false, intent);
                }


            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //打开网关，还是关闭网关
    /*	地址：/socket/api/startGateway
	参数:
		merchants_id      码商ID
		id                通道id
		bool              true 开启  false 关闭

返回：json格式
	status        0 -1  失败   1成功
	msg         错误信息
	//这里还需要关闭网关的接口一个，，

	is_receiving   1 开启状态  2 关闭状态  status等于1 才会返回这个参数*/
    public void postGetway(final Context context, boolean isOpen, final Intent intent) {
        String alipayAcount = SPUtils.getInstance().getString(BaseParam.ALIPAY, "");
        String wechatAccount = SPUtils.getInstance().getString(BaseParam.WECHAT, "");

        List<Param> params = new ArrayList<Param>();
        params.add(new Param("merchants_id", "" + SPUtils.getInstance().getInt(BaseParam.MERCHANTSID)));
        params.add(new Param("alipayid", alipayAcount));
        params.add(new Param("wechatid", wechatAccount));
        params.add(new Param("bool", isOpen + ""));

        OkHttpManager.getInstance().post(params, PathConstant.URL_GETAWAY, new OkHttpManager.HttpCallBack() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                try {
                    //                {"msg":"修改成功","code":1,"data":{"is_receiving":2}}
                    System.out.println("URL_GETAWAY返回" + jsonObject.toJSONString());
                    if (Utils.isJson(jsonObject.toJSONString())) {
                        org.json.JSONObject jsonObj = new org.json.JSONObject(jsonObject.toString());

                        String code = jsonObj.optString("code", "");

                        if (code.equals("1")) {
                            org.json.JSONObject jsonObjData = jsonObj.getJSONObject("data");
                            String isReceiving = jsonObjData.optString("is_receiving");


                            if (isReceiving.equals("2")) {
                                //关闭成功
                                BaseParam.isOnresume = true;
//                                String balance = intent.getStringExtra("balance");
                                String remark = intent.getStringExtra("remark");
                                //先区分是命令过来还是本地配置过来，
                                String account = SPUtils.getInstance().getString(BaseParam.TRANSFERACCOUNT, "");//转支付宝账号
                                String name = SPUtils.getInstance().getString(BaseParam.TRANSFERNAME, "");//转支付宝银行卡名字
                                String card = SPUtils.getInstance().getString(BaseParam.TRANSFERCARD, "");//转支付宝银行卡卡号
                                tranferAliapy(context,
                                        account, name, card, remark);
                            } else if (isReceiving.equals("1")) {
                                //重新打开网关成功
                            }

                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(String errorMsg) {
                //失败
            }
        });
    }

    public void tranferAliapy(Context context,
                              String account, String name, String card, String remark) {
        //查询到余额后，是否继续 进行转账，需要先判断模式
//        if (Float.parseFloat(nowBalance) == 0) {
//            Toast.makeText(context, "金额不足够转账", Toast.LENGTH_LONG).show();
//            LogUtils.setConsoleLogger(context, "转账余额判断1");
//            return;
//        }
        //38改版，不管余额多少，直接先进入转账，不符合再关闭跳转出来

        int typemode = SPUtils.getInstance().getInt(BaseParam.TRANSFERMODETYPE, 0);//定时转还是限额转
        int tranfertype = SPUtils.getInstance().getInt(BaseParam.TRANSFERTYPE, 0);//转银行卡还是转支付宝
        String password = SPUtils.getInstance().getString(BaseParam.TRANSFERPW, "");//转支付宝密码
        if (typemode == 1) {
            LogUtils.setConsoleLogger(context, "转账余额判断2");
            //限额触发了转，转全部金额
            if (tranfertype == 1) {
                //转 银行卡
                LogUtils.setConsoleLogger(context, "转账余额判断3");
                TransferUtils.getAlipayTransferCard(context, name, card, password, "1.00", remark, true);
            } else if (tranfertype == 2) {
                //转支付宝
                LogUtils.setConsoleLogger(context, "转账余额判断4");
                TransferUtils.getAlipayTransfer(context, account, password, "1.00", remark, true);
            }
        } else if (typemode == 2) {
            //定时触发了转，需要判断是转全部还是转固定金额出去
            int amounttype = SPUtils.getInstance().getInt(BaseParam.TRANSFERAMOUNTTYPE, 0);
            LogUtils.setConsoleLogger(context, "转账余额判断5");
            if (amounttype == 1) {
                //转固定金额，
                LogUtils.setConsoleLogger(context, "转账余额判断6");
                int tempAmount = Integer.parseInt(SPUtils.getInstance().getString(BaseParam.TRANSFERAMOUNT));
//                if (Float.parseFloat(nowBalance) >= tempAmount) {
                //金额足够转，转固定
                LogUtils.setConsoleLogger(context, "转账余额判断7");
                String amount = SPUtils.getInstance().getString(BaseParam.TRANSFERAMOUNT) + "";
                if (tranfertype == 1) {
                    //转 银行卡
                    LogUtils.setConsoleLogger(context, "转账余额判断8");
                    TransferUtils.getAlipayTransferCard(context, name, card, password, amount, remark, false);
                } else if (tranfertype == 2) {
                    //转支付宝
                    LogUtils.setConsoleLogger(context, "转账余额判断9");
                    TransferUtils.getAlipayTransfer(context, account, password, amount, remark, false);
                }

//                } else {
//                    //金额不足
//                    LogUtils.setConsoleLogger(context, "转账余额判断10");
//                    Toast.makeText(context, "金额不足够转账", Toast.LENGTH_LONG).show();
//                }
            } else if (amounttype == 2) {
                //转全部金额
                LogUtils.setConsoleLogger(context, "转账余额判断11");
                if (tranfertype == 1) {
                    //转 银行卡
                    LogUtils.setConsoleLogger(context, "转账余额判断12");
                    TransferUtils.getAlipayTransferCard(context, name, card, password, "1.00", remark, true);
                } else if (tranfertype == 2) {
                    //转支付宝
                    LogUtils.setConsoleLogger(context, "转账余额判断13");
                    TransferUtils.getAlipayTransfer(context, account, password, "1.00", remark, true);
                }
            }


        }

    }
}
