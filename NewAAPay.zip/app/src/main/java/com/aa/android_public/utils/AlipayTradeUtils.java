package com.aa.android_public.utils;

import android.content.Context;
import android.content.Intent;

import com.aa.android_public.activity.MainToolSokcetUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest;
import com.support.fastthink.BaseParam;
import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.SPUtils;
import com.support.fastthink.utils.UniformString;
import com.support.fastthink.utils.Utils;

import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import de.robv.android.xposed.XposedHelpers;

public class AlipayTradeUtils {

    public static String getCookieStr(ClassLoader appClassLoader) {
        String cookieStr = "";
        // 获得cookieStr
        XposedHelpers.callStaticMethod(XposedHelpers.findClass(
                "com.alipay.mobile.common.transportext.biz.appevent.AmnetUserInfo", appClassLoader), "getSessionid");
        Context context = (Context) XposedHelpers.callStaticMethod(XposedHelpers.findClass(
                "com.alipay.mobile.common.transportext.biz.shared.ExtTransportEnv", appClassLoader), "getAppContext");
        if (context != null) {
            Object readSettingServerUrl = XposedHelpers.callStaticMethod(
                    XposedHelpers.findClass("com.alipay.mobile.common.helper.ReadSettingServerUrl", appClassLoader),
                    "getInstance");
            if (readSettingServerUrl != null) {
                String gWFURL = ".alipay.com";
                cookieStr = (String) XposedHelpers.callStaticMethod(XposedHelpers
                                .findClass("com.alipay.mobile.common.transport.http.GwCookieCacheHelper", appClassLoader),
                        "getCookie", gWFURL);
                LogUtils.sendLogger("3支付宝商家收款cookie获取cookie成功");
            } else {
                LogUtils.sendLogger("支付宝商家收款cookie获取cookie异常readSettingServerUrl为空");
            }
        } else {
            LogUtils.sendLogger("支付宝商家收款cookie获取cookie异常context为空");
        }
        return cookieStr;
    }


    public static void getTradeInfo(final Context context, final String cookie) {
        LogUtils.sendLogger("4支付宝商家收款cookie获取数据中(1/20)");
        long current = System.currentTimeMillis();
        //long s = current - 864000000;
        long s = current - 60000;
        String c = Utils.getCurrentDate();
        String url = "https://mbillexprod.alipay.com/enterprise/simpleTradeOrderQuery.json?beginTime=" + s
                + "&limitTime=" + current + "&pageSize=20&pageNum=1&channelType=ALL";
        HttpUtils httpUtils = new HttpUtils(15000);
        httpUtils.configResponseTextCharset("GBK");
        RequestParams params = new RequestParams();
        params.addHeader("Cookie", cookie);
        params.addHeader("Referer", "https://render.alipay.com/p/z/merchant-mgnt/simple-order.html?beginTime=" + c
                + "&endTime=" + c + "&fromBill=true&channelType=ALL");
        httpUtils.send(HttpRequest.HttpMethod.GET, url, params, new RequestCallBack<String>() {

            @Override
            public void onFailure(HttpException arg0, String arg1) {
                LogUtils.sendLogger("支付宝商家收款cookie获取数据失败");
            }

            @Override
            public void onSuccess(ResponseInfo<String> arg0) {
                String result = arg0.result;
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    JSONObject res = jsonObject.getJSONObject("result");
                    JSONArray jsonArray = res.getJSONArray("list");

                    LogUtils.sendLogger("5支付宝商家收款cookie获取数据成功，完整数据为：" + res);

                    if (jsonArray != null && jsonArray.length() > 0) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            String tradeNo = object.getString("tradeNo");
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("tradeno", tradeNo);
                            broadCastIntent.putExtra("cookie", cookie);
                            broadCastIntent.setAction(UniformString.TRADENORECEIVED_ACTION);
                            context.sendBroadcast(broadCastIntent);
                        }
                    }

                } catch (Exception e) {
                    LogUtils.sendLogger("支付宝商家收款cookie获取数据异常：" + e.getMessage());
                }

            }
        });
    }


    public static void getTradeInfo(final MainToolSokcetUtils mainToolSokcetUtils, final Context context, final String tradeno, String cookie) {
        LogUtils.sendLogger("6支付宝商家收款获取到cookie和订单号后查询中");
        String url = "https://tradeeportlet.alipay.com/wireless/tradeDetail.htm?tradeNo=" + tradeno + "&source=channel&_from_url=https%3A%2F%2Frender.alipay.com%2Fp%2Fz%2Fmerchant-mgnt%2Fsimple-order._h_t_m_l_%3Fsource%3Dmdb_card";
        try {
            HttpUtils httpUtils = new HttpUtils(15000);
            httpUtils.configResponseTextCharset("GBK");
            RequestParams params = new RequestParams();
            params.addHeader("Cookie", cookie);

            httpUtils.send(HttpRequest.HttpMethod.GET, url, params, new RequestCallBack<String>() {

                @Override
                public void onFailure(HttpException arg0, String arg1) {
                    LogUtils.sendLogger("支付宝商家收款获取到cookie和订单号后查询失败：" + arg1);
                    //关闭网关，
                    MainUtils.setActive(context, UniformString.ACTIVEALIPAYERRORCLOSE);
                }

                @Override
                public void onSuccess(ResponseInfo<String> arg0) {
                    try {
                        String result = arg0.result;
                        //LogUtils.sendLogger("支付宝商家收款获取到cookie和订单号后查询成功,当前完整数据为："+result);

                        Document document = Jsoup.parse(result);
                        Elements elements = document.getElementsByClass("trade-info-value");

                        LogUtils.sendLogger("7支付宝商家收款获取到cookie和订单号后查询成功,当前数据为：0  " + elements.get(0).ownText() + "  1  " +
                                elements.get(1).ownText() + "   2  " + elements.get(2).ownText() + "   3  " + elements.get(3).ownText() + "  4  " + elements.get(4).ownText() + "  5  " + elements.get(5).ownText());


                        if (elements.size() >= 5) {
                            //普通支付
                            String money = elements.get(2).ownText();
                            String mark = elements.get(3).ownText();

                            //信用卡
                            if (money.contains("-")) {
                                money = elements.get(3).ownText();
                                mark = elements.get(4).ownText();
                            }

                            //添加本地数据库
                            Utils.addOrder(tradeno, 2, money, mark, 1);

                            //打印
                            LogUtils.setConsoleLogger(context, "结果：收到支付宝商家支付成功订单\n  订单号：" + tradeno + " 金额：" + money + " 备注：" + mark);
                            LogUtils.setConsoleCollection(context, "\n(支付宝商家收款)" + "\n订单ID：" + tradeno + "\n订单金额：" + money + "\n订单备注：" + mark
                            +"\n--------------------");


                            //发送服务器----订单回调
                            SocketSendUtils.sendOrderServer(mainToolSokcetUtils, context, UniformString.ALIPAY, tradeno, money, mark,
                                    SPUtils.getInstance().getString(BaseParam.ALIPAY, ""));

                        } else {
                            //关闭网关，
                            MainUtils.setActive(context, UniformString.ACTIVEALIPAYERRORCLOSE);
                            LogUtils.sendLogger("支付宝商家收款获取到cookie和订单号后查询成功,但数据为空：" + result);
                        }
                    } catch (Exception e) {
                        LogUtils.sendLogger("支付宝商家收款获取到cookie和订单号后查询异常：" + e.getMessage());
                        //关闭网关，
                        MainUtils.setActive(context, UniformString.ACTIVEALIPAYERRORCLOSE);
                    }
                }
            });
        } catch (Exception e) {
            LogUtils.sendLogger("支付宝商家收款获取到cookie和订单号后网页查询异常：" + e.getMessage());
            //关闭网关，
            MainUtils.setActive(context, UniformString.ACTIVEALIPAYERRORCLOSE);
        }
    }


}
