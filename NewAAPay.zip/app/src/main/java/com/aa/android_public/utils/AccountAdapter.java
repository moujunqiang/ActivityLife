package com.aa.android_public.utils;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

import com.aa.android_public.R;
import com.support.fastthink.BaseAdapter;
import com.support.fastthink.entity.AccountBean;

import java.util.List;

public class AccountAdapter extends BaseAdapter<AccountBean.DataBean> {
    private Context context;

    public AccountAdapter(Context context) {
        super(context);
        this.context = context;
    }

    @Override
    public int getContentView() {
        return R.layout.item_account;
    }


    @Override
    public void onInitView(View view, final int position) {
        List<AccountBean.DataBean> accountBeanList = getList();
        final AccountBean.DataBean accountBean = accountBeanList.get(position);
        TextView tvName = get(view, R.id.tv_account_name);
        TextView tvKey = get(view, R.id.tv_account_key);
        TextView tvType=get(view,R.id.tv_account_type);

        //1实时码  3支付宝红包  5支付宝收款
        int type=accountBean.getChannel_id();

        if (type==1){
            tvType.setTextColor(context.getResources().getColor(R.color.blue));
            tvType.setText("实时码");
        }else if (type==2){
            tvType.setTextColor(context.getResources().getColor(R.color.main_green));
            tvType.setText("微信");
        }else if (type==3){
            tvType.setTextColor(context.getResources().getColor(R.color.red));
            tvType.setText("红包");
        }else if (type==5){
            tvType.setTextColor(context.getResources().getColor(R.color.main_green));
            tvType.setText("收款");
        }else if (type==6){
            tvType.setTextColor(context.getResources().getColor(R.color.red_color));
            tvType.setText("转账");
        }else {
            tvType.setText("");
        }


        //名称
        tvName.setText(accountBean.getName());
        //key
        tvKey.setText(accountBean.getReceipt_name());
    }
}
