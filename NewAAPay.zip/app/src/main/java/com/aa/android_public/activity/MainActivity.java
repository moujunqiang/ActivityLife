package com.aa.android_public.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.aa.android_public.R;
import com.aa.android_public.advanced.AdvancedMainReceived;
import com.aa.android_public.advanced.AdvancedTransferActivity;
import com.aa.android_public.advanced.MainToolAdvacedUtils;
import com.aa.android_public.broadcast.MainReceived;
import com.aa.android_public.broadcast.MainReceivedListener;
import com.aa.android_public.socket.SocketToMainActivityListener;
import com.aa.android_public.ui.CommonDialogCheck;
import com.aa.android_public.utils.AlipayReceivedUtils;
import com.aa.android_public.utils.AlipayWechatLiveUtils;
import com.aa.android_public.utils.CheckUserIdUtils;
import com.aa.android_public.utils.DeleteAlipayUid;
import com.aa.android_public.utils.MD5;
import com.aa.android_public.utils.MainUtils;
import com.support.fastthink.BaseActivity;
import com.support.fastthink.BaseApplication;
import com.support.fastthink.BaseParam;
import com.support.fastthink.ui.CommonDialog;
import com.support.fastthink.utils.LogToFile;
import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.SPUtils;
import com.support.fastthink.utils.UniformString;
import com.support.fastthink.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class MainActivity extends BaseActivity implements View.OnClickListener {
    //init//
    //日志
    private TextView tvLogOpen, tvLogAdress,tv_delete_uid;
    //查询uid
    private TextView tvLogCheckUid,tvLogCheckUid_show;
    private static String userid_now="";
    //ip信息
    private TextView tvIpMessage;
    //1顶部
    private TextView tvTest, tvLogout, tvAccount, tvAlipayType;
    //2余额
    private TextView tvBalance, tvRecharge, tvVersion;
    private RelativeLayout rlBalanceDetail;
    //3支付宝，流水，订单数，限额
    private TextView tvAlipayAccount, tvAlipayFlow, tvAlipayOrderNum, tvAlipayLimit;
    private TextView tvAlipayApp, tvAlipaySocket, tvGetwayStatus, tvAlipayWay;
    private ImageView ivAlipayApp, ivAlipaySocket, ivAlipayGateway;
    //4微信
    private TextView tvWechatAccount, tvWechatFlow, tvWechatOrderNum, tvWechatLimit;
    private TextView tvWechatApp, tvWechatSocket, tvWechatWay;
    private ImageView ivWechatApp, ivWechatSocket, ivWechatGateway;
    private RelativeLayout rlWechatSelect;
    //5日志
    private TextView tvCollectionLog, tvProgramLog, tvLoggerDetail;
    private View viewCollectionLog, viewProgramLog;
    private static TextView console;
    private static TextView collection;
    //6功能
    private TextView tvAdvanced;
    private TextView tvStart;
    private RelativeLayout rlHomeStart, rlHomeAdvanced;
    //init//

    //点击网关开启关闭
    private int AlipayGateway, WeChatGateway;
    private boolean AlipayWayClick = false, WeChatWayClick = false;

    private boolean baohuo = true;
    //string
    private String wechatKey = "", alipayKey = "";

    //控制台Received
    private MsgReceived msgReceived;

    //主页Received
    private MainReceived mainReceived;

    //sokcet模块
    private MainToolSokcetUtils mainToolSokcetUtils = null;
    private MainToolTimerUtils mainToolTimerUtils = null;

    //通讯检测弹框
    private CommonDialogCheck commonDialogCheck = null;

    //登录类型
    private int login_type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (SPUtils.getInstance().getInt(BaseParam.MERCHANTSID) == -1) {
            startIntent(LoginActivity.class);
            finish();
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        setContentView(R.layout.activity_main);
        initModel();
        initView();
        initData();
        performEXTERNAL();//申请存储权限
        payListGetAlipayOrder.clear();

    }


    //初始化
    private void initModel() {
        //初始化socket
        mainToolSokcetUtils = new MainToolSokcetUtils(this);
        mainToolSokcetUtils.setSocketMessage(new SocketToMainActivityListener() {
            @Override
            public void onMessageToMain(final String liushui, final String bishu, final String xiane, final String key_id) {
                //设置余额信息
                final String alipayAcount = SPUtils.getInstance().getString(BaseParam.ALIPAY);
                final String wechatAccount = SPUtils.getInstance().getString(BaseParam.WECHAT);

                (MainActivity.this).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        //已在主线程中，可以更新UI
                        if (key_id.equals(alipayAcount)) {
                            //设置支付宝通道信息
                            tvAlipayFlow.setText("¥" + liushui);
                            tvAlipayOrderNum.setText(bishu + " ");
                            tvAlipayLimit.setText("¥" + xiane);
                        } else if (key_id.equals(wechatAccount)) {
                            //设置微信通道信息
                            tvWechatFlow.setText("¥" + liushui);
                            tvWechatOrderNum.setText(bishu + " ");
                            tvWechatLimit.setText("¥" + xiane);
                        }
                    }
                });


            }

            @Override
            public void onMessageToBlance(final String blance) {
                (MainActivity.this).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        //已在主线程中，可以更新UI
                        tvBalance.setText("¥" + blance);
                    }
                });

            }

            @Override
            public void onCloseChannel(final String keyid) {
                //关闭 支付宝或者 微信通道，如果关闭后没有通道了，关闭网关
                //后台关闭网关后，app不做处理，继续心跳
//                (MainActivity.this).runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        //已在主线程中，可以更新UI
//                        closeConnect();
//                        String alipayAcount = SPUtils.getInstance().getString(BaseParam.ALIPAY, "");
//                        String wechatAccount = SPUtils.getInstance().getString(BaseParam.WECHAT, "");
//                        System.out.println("进入执行3=" + keyid + ">>>>" + alipayAcount);
//                        if (keyid.equals(alipayAcount)) {
//                            //网关设置
//                        } else if (keyid.equals(wechatAccount)) {
//                            //网关设置
//                        }
//
//                        //网关状态最好从后台获取，否则依赖通道下发的指令去设置，启动的时候也无法判断网关是否开启了，需要socket实时
//                    }
//                });

//
            }

            @Override
            public void onMessageError(final String msg, final boolean isShow) {
                System.out.println("进入执行2=" + msg + isShow);
                (MainActivity.this).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isShow) {
                            tvGetwayStatus.setVisibility(View.VISIBLE);
                            tvGetwayStatus.setText(msg + " ");
                        } else {
                            tvGetwayStatus.setVisibility(View.GONE);
                        }
                    }
                });


            }

            @Override
            public void onMessageGetWay(final int alipay, final int wechat) {
                System.out.println("进入执行1==" + alipay + wechat);
                (MainActivity.this).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (alipay == 1) {
                            ivAlipayGateway.setImageResource(R.mipmap.ic_online);
                            AlipayGateway = 1;
                            tvAlipayWay.setText("关闭网关");
                            tvAlipayWay.setBackground(getResources().getDrawable(R.drawable.bg_red_radius));
                            AlipayWayClick = false;
                        } else {
                            ivAlipayGateway.setImageResource(R.mipmap.ic_offline);
                            AlipayGateway = 2;
                            tvAlipayWay.setText("开启网关");
                            tvAlipayWay.setBackground(getResources().getDrawable(R.drawable.bg_blue_radius4));
                            AlipayWayClick = false;
                        }
                        if (wechat == 1) {
                            ivWechatGateway.setImageResource(R.mipmap.ic_online);
                            WeChatGateway = 1;
                            tvWechatWay.setText("关闭网关");
                            tvWechatWay.setBackground(getResources().getDrawable(R.drawable.bg_red_radius));
                            WeChatWayClick = false;
                        } else {
                            ivWechatGateway.setImageResource(R.mipmap.ic_offline);
                            WeChatGateway = 2;
                            tvWechatWay.setText("开启网关");
                            tvWechatWay.setBackground(getResources().getDrawable(R.drawable.bg_blue_radius4));
                            WeChatWayClick = false;
                        }
                    }
                });

            }

            @Override
            public void onMessageIp(final String msg) {
                System.out.println("开始设置ip" + msg);
                (MainActivity.this).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        //已在主线程中，可以更新UI
                        tvIpMessage.setText(msg + "");
                        //网关状态最好从后台获取，否则依赖通道下发的指令去设置，启动的时候也无法判断网关是否开启了，需要socket实时
                    }
                });

            }

            @Override
            public void onMessageIpError(final String msg) {
                System.out.println("开始显示错误信息");
                (MainActivity.this).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        MainActivity.this.showDialog1(msg);

                    }
                });

            }

        });
        //初始化定时
        mainToolTimerUtils = new MainToolTimerUtils(this);
        //////高级功能//////
        mainToolAdvacedUtils = new MainToolAdvacedUtils(this);
        //////高级功能//////
    }

    public void alipayErrorClose() {
        //只需要关闭支付宝，不需要关闭socket
        String alipayAcount = SPUtils.getInstance().getString(BaseParam.ALIPAY, "");
        //网关设置
        //支付宝关闭网关
        //是否需要增加挤通道的操作，或者，连接通道得时候判断当前通道是否有人 使用
        //提示。
        LogUtils.sendLogger("支付宝爬取账单异常");
        LogUtils.sendLogger("支付宝爬取账单异常");
    }


    @Override
    protected void onStart() {
        super.onStart();
        LogUtils.sendLogger("执行当前生命周期onStart");
        MainUtils.setActive(MainActivity.this, UniformString.ACTIVEALL);
    }

    private void initView() {
        login_type=SPUtils.getInstance().getInt(BaseParam.LOGINTYPE);
        //1.
        //日志 tvLogOpen, tvLogAdress;
        tvLogOpen = findViewById(R.id.tv_log_open);
        tvLogOpen.setOnClickListener(this);
        tvLogAdress = findViewById(R.id.tv_log_address);
        tvIpMessage = findViewById(R.id.tv_ip_message);

        tv_delete_uid = findViewById(R.id.tv_delete_uid);
        tv_delete_uid.setOnClickListener(this);

        if (BaseParam.isSaveLogTofile) {
            //记录，
            tvLogOpen.setText("关闭日志记录");
        } else {
            //不记录,
            tvLogOpen.setText("开始日志记录");
        }
        String pathTemp1 = LogToFile.getFilePath(this) + "/Logs";
        tvLogAdress.setText("地址：/" + pathTemp1);

        //uid查询
        tvLogCheckUid = findViewById(R.id.tv_log_checkuid);
        tvLogCheckUid.setOnClickListener(this);

        tvLogCheckUid_show = findViewById(R.id.tv_log_checkuid_show);
        tvLogCheckUid_show.setText("支付宝uid："+userid_now);

        //Test
        tvTest = findViewById(R.id.tv_home_test);
        tvTest.setOnClickListener(this);
        //支付宝类型
        tvAlipayType = findViewById(R.id.tv_home_alipay_type);
        //当前账号
        tvAccount = findViewById(R.id.title_account);
        //退出登录
        tvLogout = findViewById(R.id.tv_home_logout);
        tvLogout.setOnClickListener(this);
        //2.
        //余额
        tvBalance = findViewById(R.id.tv_home_balance);
        //充值
        tvRecharge = findViewById(R.id.tv_home_recharge);
        tvRecharge.setOnClickListener(this);
        //版本
        tvVersion = findViewById(R.id.tv_home_version);
        //余额详情
        rlBalanceDetail = findViewById(R.id.rl_balance_detail);
        rlBalanceDetail.setOnClickListener(this);
        //3.
        //支付宝账号
        tvAlipayAccount = findViewById(R.id.tv_alipay_account);
        //支付宝切换账号
        rlBalanceDetail = findViewById(R.id.rl_alipay_select);
        rlBalanceDetail.setOnClickListener(this);
        //支付宝今日流水
        tvAlipayFlow = findViewById(R.id.tv_alipay_flow);
        //支付宝订单数
        tvAlipayOrderNum = findViewById(R.id.tv_alipay_order_number);
        //支付宝限额
        tvAlipayLimit = findViewById(R.id.tv_alipay_limit);
        //支付宝是否活跃
        tvAlipayApp = findViewById(R.id.tv_alipay_app);
        ivAlipayApp = findViewById(R.id.iv_alipay_app);
        //Socket是否在线
        tvAlipaySocket = findViewById(R.id.tv_alipay_socket);
        ivAlipaySocket = findViewById(R.id.iv_alipay_socket);
        //支付宝网关
        ivAlipayGateway = findViewById(R.id.iv_alipay_gateway);
        tvAlipayWay = findViewById(R.id.tv_alipay_open);
        tvAlipayWay.setOnClickListener(this);

        //错误提示
        tvGetwayStatus = findViewById(R.id.tv_getway_statu);
        tvGetwayStatus.setVisibility(View.GONE);
        //4.
        //微信账号
        tvWechatAccount = findViewById(R.id.tv_wechat_account);
        //微信切换账号
        rlWechatSelect = findViewById(R.id.rl_wechat_select);
        rlWechatSelect.setOnClickListener(this);
        //微信今日流水
        tvWechatFlow = findViewById(R.id.tv_wechat_flow);
        //微信订单数
        tvWechatOrderNum = findViewById(R.id.tv_wechat_order_number);
        //微信限额
        tvWechatLimit = findViewById(R.id.tv_wechat_limit);
        //微信是否活跃
        tvWechatApp = findViewById(R.id.tv_wechat_app);
        ivWechatApp = findViewById(R.id.iv_wechat_app);
        //微信Socket是否在线
        tvWechatSocket = findViewById(R.id.tv_wechat_socket);
        ivWechatSocket = findViewById(R.id.iv_wechat_socket);
        //微信网关
        ivWechatGateway = findViewById(R.id.iv_wechat_gateway);
        tvWechatWay = findViewById(R.id.tv_wechat_open);
        tvWechatWay.setOnClickListener(this);
        //5.
        //收款日志
        tvCollectionLog = findViewById(R.id.tv_collection_log);
        tvCollectionLog.setOnClickListener(this);
        //收款日志横线
        viewCollectionLog = findViewById(R.id.view_collection_log);
        viewCollectionLog.setVisibility(View.VISIBLE);
        //程序日志
        tvProgramLog = findViewById(R.id.tv_program_log);
        tvProgramLog.setOnClickListener(this);
        //程序日志横线
        viewProgramLog = findViewById(R.id.view_program_log);
        viewProgramLog.setVisibility(View.GONE);
        //日志详情
        tvLoggerDetail = findViewById(R.id.tv_logger_detail);
        tvLoggerDetail.setOnClickListener(this);
        //主页日志展示
        console = findViewById(R.id.tv_home_logger);
        setConsoleInit(console);
        collection = findViewById(R.id.tv_collection_logger);
        setConsoleInit(collection);
        //6
        //启动
        rlHomeStart = findViewById(R.id.rl_home_start);
        tvStart = findViewById(R.id.tv_home_start);
        tvStart.setOnClickListener(this);
        //高级功能
        rlHomeAdvanced = findViewById(R.id.rl_home_advanced);
        tvAdvanced = findViewById(R.id.tv_home_advanced);
        tvAdvanced.setOnClickListener(this);

        //注册广播
        msgReceived = new MsgReceived();
        IntentFilter intentFilter = new IntentFilter();
        //控制台打印
        intentFilter.addAction(UniformString.MAINMSGRECEIVER);
        //活跃状态检测
        intentFilter.addAction(UniformString.ACTIVE_HOME_ACTION);
        registerReceiver(msgReceived, intentFilter);
    }


    private void initData() {
        //当前已有余额
        if (!TextUtils.isEmpty(SPUtils.getInstance().getString(BaseParam.NOWAMOUNT))) {
            tvBalance.setText("¥" + SPUtils.getInstance().getString(BaseParam.NOWAMOUNT) + "");
        }
        //版本号
        tvVersion.setText("V " + SPUtils.getInstance().getString(BaseParam.MERCHANTSVERSION));
        //当前登陆账号
        if (login_type==2){
            tvAccount.setText("当前为授权码登录模式");
        }else {
            tvAccount.setText("当前账号:" + SPUtils.getInstance().getString(BaseParam.NOWACCOUNT));
        }

        //判断通道类型
        String channels_id=SPUtils.getInstance().getString(BaseParam.CHANNELSID);
        String channels_key=SPUtils.getInstance().getString(BaseParam.CHANNELSKEY);

        //模式类型-----1.实时码(1alipay\2wechat)  2.红包(3)  3.收款(5)  4.转账码(6)
        if (login_type==2){
            if ("1".equals(channels_id)){
                SPUtils.getInstance().put(BaseParam.NOWALIPAYMODE,1);//实时码
                tvAlipayAccount.setText(channels_key);
            }if ("2".equals(channels_id)){
                //当前是微信，不参与支付宝类型保存
                tvWechatAccount.setText(channels_key);
            }else if ("3".equals(channels_id)){
                SPUtils.getInstance().put(BaseParam.NOWALIPAYMODE,2);//红包
                tvAlipayAccount.setText(channels_key);
            }else if ("5".equals(channels_id)){
                SPUtils.getInstance().put(BaseParam.NOWALIPAYMODE,3);//收款
                tvAlipayAccount.setText(channels_key);
            }else if ("6".equals(channels_id)){
                SPUtils.getInstance().put(BaseParam.NOWALIPAYMODE,4);//转账码
                tvAlipayAccount.setText(channels_key);
            }
            getEditKey();
        }else {
            String alipayAcount = "";
            String wechatAccount = "";
            alipayAcount = SPUtils.getInstance().getString(BaseParam.ALIPAY);
            wechatAccount = SPUtils.getInstance().getString(BaseParam.WECHAT);
            alipayKey = alipayAcount;
            wechatKey = wechatAccount;
            if (!TextUtils.isEmpty(alipayAcount))
                tvAlipayAccount.setText(alipayAcount);
            if (!TextUtils.isEmpty(wechatAccount))
                tvWechatAccount.setText(wechatAccount);
        }
        setAlipayType();//显示支付宝类型

        //常规功能--注册广播//
        mainReceived = new MainReceived(mainToolSokcetUtils, new MainReceivedListener() {
            @Override
            public void reMessageUid(String uid) {
                userid_now=uid;
                tvLogCheckUid_show.setText("支付宝uid："+userid_now);
            }
        });
        IntentFilter intentFilter = new IntentFilter();
        //保活
        intentFilter.addAction(UniformString.LIVE_HOME_ACTION_START);
        //查询UserId
        intentFilter.addAction(UniformString.CHECK_HOME_ACTION_USERID);
        //查询余额
        intentFilter.addAction(UniformString.BALANCERECEIVED_ACTION);
        //设置实时码
        intentFilter.addAction(UniformString.QRCODERECEIVED_ACTION);
        //设置个人转账新，增加uid
        intentFilter.addAction(UniformString.ZHUANZHANG_UID);
        //个人支付成功订单/支付宝/微信
        intentFilter.addAction(UniformString.BILLRECEIVED_ACTION);
        //支付宝商家收款
        intentFilter.addAction(UniformString.TRADENORECEIVED_ACTION);
        intentFilter.addAction(UniformString.TRADENORECEIVED_ACTION);
        ////新模式--收款--红包--/////
        //支付宝收款
        intentFilter.addAction(UniformString.RECEIPT_ORDER);
        intentFilter.addAction(UniformString.ALIPAYRECEIPT_ACTION);
        //支付宝红包
        intentFilter.addAction(UniformString.REDENVELOPE_ACTION);
        intentFilter.addAction(UniformString.ALIPAYUID_ACTION);
        ////新模式--收款--红包--/////
        registerReceiver(mainReceived, intentFilter);

        if (BaseParam.isAdvanced) {
            tvRecharge.setVisibility(View.VISIBLE);
            rlHomeAdvanced.setVisibility(View.VISIBLE);
        } else {
            tvRecharge.setVisibility(View.GONE);
            rlHomeAdvanced.setVisibility(View.GONE);
        }
        //常规功能--注册广播//


        //////高级功能//////
        setAdvanced();
        //////高级功能//////
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_home_test://测试按钮
                //转全部
                break;
            case R.id.tv_log_open://是否记录日志，默认不记录，false
                if (BaseParam.isSaveLogTofile) {
                    BaseParam.isSaveLogTofile = false;
                    //记录，设置为不记录
                    tvLogOpen.setText("开始日志记录");
                    showToast("日志记录功能已关闭");
                } else {
                    BaseParam.isSaveLogTofile = true;
                    //不记录,设置为记录
                    tvLogOpen.setText("关闭日志记录");
                    showToast("日志记录功能已开启");
                }
                break;
            case R.id.tv_log_checkuid://查询uid
                CheckUserIdUtils.getAlipayUserId(MainActivity.this,"" + (int) (Math.random() * 1000000));
                break;
            case R.id.tv_delete_uid://删除好友
                //查询出来多少个好友，然后删除
                try{
                    DeleteAlipayUid.deleteAlipayUid(this);

                    List<String> getAlipayUidList=Utils.getAlipayUidList();
                    if (getAlipayUidList != null && getAlipayUidList.size() > 0) {
                        //删除数据库好友
                        Utils.deleteAllUid();
//                        Toast.makeText(this, "删除支付宝好友开始"+getAlipayUidList.size()+"个", Toast.LENGTH_SHORT).show();
//                        for (int i=0;i<getAlipayUidList.size();i++){
//                            System.out.println("增加支付宝好友3=查询"+i+"    结果"+getAlipayUidList.get(i).trim());
//                            //广播过去让hook删除
//                            DeleteAlipayUid.deleteAlipayUid(this,getAlipayUidList.get(i).trim());
//                        }
//                        Toast.makeText(this, "删除支付宝好友完成"+getAlipayUidList.size()+"个", Toast.LENGTH_SHORT).show();

                    }else{
//                        Toast.makeText(this, "没有记录到好友", Toast.LENGTH_SHORT).show();
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }

                break;

            case R.id.tv_home_logout://退出登录
                new CommonDialog(MainActivity.this, "是否退出当前账号？", new CommonDialog.onButtonCLickListener() {
                    @Override
                    public void onActivityButtonClick(int position) {
                        if (position == 1) {
                            SPUtils.getInstance().clear();
                            startIntent(LoginActivity.class);
                            finish();
                        }
                    }
                }).show();
                break;
            case R.id.rl_balance_detail://余额详情
                startIntent(BalanceDetailActivity.class);
                break;
            case R.id.rl_alipay_select://支付宝账号选择
                if (login_type==2){
                    showToast("当前为授权码登录模式，已自动填充通道值");
                }else {
                    startIntentResult(AccountListActivity.class, UniformString.INTENTTALIPAY, "1");
                }
                break;
            case R.id.rl_wechat_select://微信账号选择
                if (login_type==2){
                    showToast("当前为授权码登录模式，已自动填充通道值");
                }else {
                    startIntentResult(AccountListActivity.class, UniformString.INTENTTWECHAT, "2");
                }
                break;
            case R.id.tv_collection_log://收款日志
                viewCollectionLog.setVisibility(View.VISIBLE);
                viewProgramLog.setVisibility(View.GONE);
                console.setVisibility(View.GONE);
                collection.setVisibility(View.VISIBLE);
                break;
            case R.id.tv_program_log://程序日志
                viewCollectionLog.setVisibility(View.GONE);
                viewProgramLog.setVisibility(View.VISIBLE);
                console.setVisibility(View.VISIBLE);
                collection.setVisibility(View.GONE);
                break;
            case R.id.tv_logger_detail://查看详情日志
                Intent intent = new Intent(MainActivity.this, LoggerDetailActivity.class);
                intent.putExtra("logger", console.getText().toString());
                intent.putExtra("logger2", collection.getText().toString());
                startActivity(intent);
                break;
            case R.id.tv_home_start://启动/关闭
                //如果又支付宝得参数，

                System.out.println("点击开启按钮"+alipayKey+"    "+userid_now);

                if(!alipayKey.equals("")&&(userid_now==null||userid_now.equals("")||userid_now.equals("null"))){
                    Toast.makeText(MainActivity.this, "请先查询支付宝uid", Toast.LENGTH_SHORT).show();

                    System.out.println("点击开启按钮1  "+alipayKey+"    "+userid_now);
                }else{
                    System.out.println("点击开启按钮2  "+alipayKey+"    "+userid_now);
                    if (BaseApplication.isStart) {

                        closeConnect();
                    } else {
                        if (commonDialogCheck == null) {
                            commonDialogCheck = new CommonDialogCheck(MainActivity.this, new CommonDialogCheck.onButtonCLickListener() {
                                @Override
                                public void onActivityButtonClick(int position) {
                                    if (position == 1) {
                                        startConnect();

                                    }
                                }
                            }, mainToolSokcetUtils);
                        }
                        commonDialogCheck.setData(alipayKey, wechatKey);
                        commonDialogCheck.show();


                    }
                }



                break;
            case R.id.tv_home_recharge://高级功能配置
                startIntent(AdvancedTransferActivity.class);
                break;
            case R.id.tv_home_advanced://开启高级功能
                clickAdvanced();
                break;
            case R.id.tv_alipay_open://开启关闭支付宝网关
                if (AlipayWayClick == false) {
                    AlipayWayClick = true;
                    if (AlipayGateway == 1) {
                        //已开启，点击去关闭
                        MainUtils.postGetway(MainActivity.this, 1, false);
                    } else {
                        //已关闭，点击去开启
                        MainUtils.postGetway(MainActivity.this, 1, true);
                    }
                } else {
                    Toast.makeText(this, "确保Socket已连接后，再执行操作！", Toast.LENGTH_SHORT).show();
                }

                break;
            case R.id.tv_wechat_open://开启关闭微信网关
                if (WeChatWayClick == false) {
                    WeChatWayClick = true;
                    if (WeChatGateway == 1) {
                        //已开启，点击去关闭
                        MainUtils.postGetway(MainActivity.this, 2, false);
                    } else {
                        //已关闭，点击去开启
                        MainUtils.postGetway(MainActivity.this, 2, true);
                    }
                } else {
                    Toast.makeText(this, "确保Socket已连接后，再执行操作！", Toast.LENGTH_SHORT).show();
                }

                break;
            default:
                break;
        }
    }

    private void getEditKey() {
        alipayKey = tvAlipayAccount.getText().toString();
        wechatKey = tvWechatAccount.getText().toString();

        SPUtils.getInstance().put(BaseParam.WECHAT, wechatKey);
        SPUtils.getInstance().put(BaseParam.ALIPAY, alipayKey);
    }

    //开启定时脚本
    private void startEvent() {
        mainToolTimerUtils.startTimerHandler();
    }

    //关闭定时脚本
    private void stopEvent() {
        mainToolTimerUtils.stopTimerHandler();
    }


    ////////控制台日志打印////////
    private void setConsoleInit(TextView console) {
        //初始化控件
        console.setMovementMethod(ScrollingMovementMethod.getInstance());
        console.setGravity(Gravity.BOTTOM);
        console.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // TODO Auto-generated method stub
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    //通知父控件不要干扰
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                }
                if (event.getAction() == MotionEvent.ACTION_MOVE) {
                    //通知父控件不要干扰
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                }
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                }
                return false;
            }
        });
    }

    private static void setConsole(String type, String txt) {
        //打印数据
        Message msg = new Message();

        if (type.equals(UniformString.LOGGERCOLLECION)) {
            msg.what = 2;
        } else {
            msg.what = 1;
        }

        Bundle data = new Bundle();
        long l = System.currentTimeMillis();
        Date date = new Date(l);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String d = dateFormat.format(date);
        data.putString("log", d + "：" + txt);
        msg.setData(data);
        try {
            handlerConsole.sendMessage(msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("HandlerLeak")
    public static Handler handlerConsole = new Handler() {
        //接收数据
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 2) {
                final String txt = msg.getData().getString("log");
                if (collection != null) {
                    if (collection.getText() != null) {
                        if (collection.getText().toString().length() > 200000) {
                            collection.setText("日志定时清理完成..." + "\n\n" + txt);
                        } else {
                            collection.setText(collection.getText().toString() + "\n\n" + txt);
                        }

                    } else {
                        collection.setText(txt);
                    }
                }

                collection.post(new Runnable() {
                    @Override
                    public void run() {

                        int lineCount = collection.getLineCount();
                        int height = collection.getHeight();

                        try {
                            int scrollAmount = collection.getLayout().getLineTop(lineCount)
                                    - height;
                            if (scrollAmount > 0)
                                collection.scrollTo(0, scrollAmount);
                            else
                                collection.scrollTo(0, 0);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            } else {
                final String txt = msg.getData().getString("log");
                if (console != null) {
                    if (console.getText() != null) {
                        if (console.getText().toString().length() > 200000) {
                            console.setText("日志定时清理完成..." + "\n\n" + txt);
                        } else {
                            console.setText(console.getText().toString() + "\n\n" + txt);
                        }

                    } else {
                        console.setText(txt);
                    }
                }

                console.post(new Runnable() {
                    @Override
                    public void run() {

                        int lineCount = console.getLineCount();
                        int height = console.getHeight();

                        try {
                            int scrollAmount = console.getLayout().getLineTop(lineCount) - height;
                            if (scrollAmount > 0)
                                console.scrollTo(0, scrollAmount);
                            else
                                console.scrollTo(0, 0);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            }

            super.handleMessage(msg);
        }

    };

    class MsgReceived extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                if (intent.getAction().contentEquals(UniformString.MAINMSGRECEIVER)) {
                    //1.接收打印到控制台内容//
                    setConsole(intent.getStringExtra(UniformString.LOGGERTYPE), intent.getStringExtra(UniformString.MAINMSGTAG));
                }
                if (intent.getAction().contentEquals(UniformString.ACTIVE_HOME_ACTION)) {
                    //2.活跃状态监控//
                    String type = intent.getStringExtra(UniformString.ACTIVETYPE);
                    LogUtils.sendLogger("监控活跃状态中:" + type);
                    if (type.equals(UniformString.ACTIVEALL)) {
                        //启动微信支付宝后检测是否APP活跃
                        LogUtils.sendLogger("启动微信支付宝后检测是否APP活跃");
                        isAlipayWechatRun();
                    } else if (type.equals(UniformString.ACTIVESOCKET)) {
                        //检测socket是否在线
                        isSocetRun();
                    } else if (type.equals(UniformString.ACTIVESOCKETHEART)) {
                        //发送心跳
                        isSocetHeartRun();
                    } else if (type.equals(UniformString.ACTIVEHTTPHEART)) {
                        //发送心跳,0313,请求主动收款订单号，并去创建
                        System.out.println("发送心跳,0313,请求主动收款订单号，并去创建");
//                        isHttpGetalipayNoRun();
                    } else if (type.equals(UniformString.ACTIVEALIPAYISRUN)) {
                        //检查是否需要支付宝保活,微信保活
                        if (baohuo) {
                            baohuo = false;
                            if (!TextUtils.isEmpty(alipayKey)) {
                                AlipayWechatLiveUtils.getAlipayLive(context);
                            }
                        } else {
                            baohuo = true;
                            if (!TextUtils.isEmpty(wechatKey)) {
                                AlipayWechatLiveUtils.getWechatLive(context);
                            }
                        }


                    } else if (type.equals(UniformString.ACTIVEALIPAYERRORCLOSE)) {
                        //支付宝商家爬虫异常，需要关闭支付宝通道
                        (MainActivity.this).runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                //已在主线程中，可以更新UI
                                LogUtils.setConsoleCollection(MainActivity.this, "\n(支付宝风控)" + "\n检测到支付宝收款风控，关闭支付宝通道");
                                alipayErrorClose();
                            }
                        });

                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void onResume() {
        super.onResume();
        BaseParam.isOnresume = false;
    }

    public void onStop() {
        super.onStop();
        BaseParam.isOnresume = true;
    }
    ////////控制台日志打印////////


    ////////支付宝/微信活跃状态监控////////

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == UniformString.INTENTTALIPAY) {
            if (data != null) {
                String account = data.getStringExtra("account");
                tvAlipayAccount.setText(account);
                setAlipayType();
            }
        } else if (resultCode == UniformString.INTENTTWECHAT) {
            if (data != null) {
                String account = data.getStringExtra("account");
                tvWechatAccount.setText(account);
            }
        }

        //保存配置
        getEditKey();

    }

    //微信支付宝app检测并显示在app
    private void isAlipayWechatRun() {
        //微信支付宝通道是否开启，app是否活跃检测
        //支付宝通道存在，去检测
        if (!TextUtils.isEmpty(alipayKey)) {
            if (MainUtils.isAlipayRunning(MainActivity.this)) {
                ivAlipayApp.setImageResource(R.mipmap.ic_online);
            } else {
                ivAlipayApp.setImageResource(R.mipmap.ic_offline);
            }
        } else {
            ivAlipayApp.setImageResource(R.mipmap.ic_offline);
        }
        //微信通道存在，去检测
        if (!TextUtils.isEmpty(wechatKey)) {
            if (MainUtils.isWeChatRunning(MainActivity.this)) {
                ivWechatApp.setImageResource(R.mipmap.ic_online);
            } else {
                ivWechatApp.setImageResource(R.mipmap.ic_offline);
            }
        } else {
            ivWechatApp.setImageResource(R.mipmap.ic_offline);
        }
    }

    //socket检测并显示再主页
    private void isSocetRun() {
        //socket
        //socket开启
        if (mainToolSokcetUtils != null && mainToolSokcetUtils.isOpen()) {
            if (tvAlipayAccount != null & !TextUtils.isEmpty(tvAlipayAccount.getText().toString())) {
                ivAlipaySocket.setImageResource(R.mipmap.ic_online);
            } else {
                ivAlipaySocket.setImageResource(R.mipmap.ic_offline);
            }
            if (tvWechatAccount != null & !TextUtils.isEmpty(tvWechatAccount.getText().toString())) {
                ivWechatSocket.setImageResource(R.mipmap.ic_online);
            } else {
                ivWechatSocket.setImageResource(R.mipmap.ic_offline);
            }
        } else {
            //socket关闭
            ivAlipaySocket.setImageResource(R.mipmap.ic_offline);
            ivWechatSocket.setImageResource(R.mipmap.ic_offline);
        }
    }

    //socket定时心跳
    private void isSocetHeartRun() {
        //满足条件发送心跳
        if (mainToolSokcetUtils != null && mainToolSokcetUtils.isOpen()) {
//
//            {"params":{"red_packet_id":"","wechat_id":"","alipay2_id":"520078259@qq.com","alipay_account_user_id":"2088332230634660",
//            "merchant_id":"1","phoneId":"1"},"type":"login"}
            try {
                JSONObject object = new JSONObject();//创建一个总的对象，这个对象对整个json串
                JSONObject jsonObj = new JSONObject();//pet对象，json形式
                jsonObj.put("messageuuid", "" + (int) (Math.random() * 1000000));//消息id
                jsonObj.put("wechat_id", SPUtils.getInstance().getString(BaseParam.WECHAT, wechatKey));//微信的key_id

                int AlipayMode = SPUtils.getInstance().getInt(BaseParam.NOWALIPAYMODE);

                if (AlipayMode == 1) {
                    jsonObj.put("alipay_id", SPUtils.getInstance().getString(BaseParam.ALIPAY, alipayKey));//支付宝的实时码通道key_id
                } else if (AlipayMode == 2) {
                    jsonObj.put("red_packet_id", SPUtils.getInstance().getString(BaseParam.ALIPAY, alipayKey));//支付宝的红包通道key_id
                } else if (AlipayMode == 3) {
                    jsonObj.put("alipay_pattern_id", SPUtils.getInstance().getString(BaseParam.ALIPAY, alipayKey));//支付宝的收款通道key_id
                } else if (AlipayMode == 4) {
                    jsonObj.put("alipay_transfer_id", SPUtils.getInstance().getString(BaseParam.ALIPAY, alipayKey));//支付宝的转账码通道
                } else {
                  //  LogUtils.setConsoleLogger(this, "当前未保存支付宝模式类型！");
                }


                jsonObj.put("alipay_account_user_id", SPUtils.getInstance().getString(BaseParam.ALIPAYUID, ""));//支付宝官方ID
                jsonObj.put("merchant_id", SPUtils.getInstance().getInt(BaseParam.MERCHANTSID, 0));//码商ID
                jsonObj.put("phoneId", MainUtils.getPesudoUniqueID()); //设备唯一ID

                object.put("params", jsonObj);//向总对象里面添加包含pet的数组
                object.put("type", "login");
                mainToolSokcetUtils.sendSocket(object.toString());
                System.out.println("发送心跳日志完成" + object.toString());
            } catch (JSONException e) {
                e.printStackTrace();
                System.out.println("发送心跳日志错误" + e.toString());
            }

        } else {
            //不满足条件，尝试连接socket
            mainToolSokcetUtils.connectSocket();
        }
    }


    public void startConnect() {
        startEvent();//启动定时
        BaseApplication.isStart = true;
        tvStart.setText("关闭");
        tvStart.setBackgroundResource(R.drawable.bg_login_red_radius);
//        showToast("开启成功");
    }

    public void closeConnect() {
        stopEvent();
        mainToolSokcetUtils.closeSocket();
        BaseApplication.isStart = false;
        tvStart.setText("开启");
        tvStart.setBackgroundResource(R.drawable.bg_blue_radius);
//        showToast("关闭成功");
    }


    protected void onDestroy() {
        super.onDestroy();
        //关闭各种定时
        if (BaseApplication.isStart) {
            closeConnect();
        }

        //////高级功能//////
        if (BaseParam.isStartAdvaced) {
            stopAdvanced();
        }
        //////高级功能//////

    }


    /////高级功能//////
    private MainToolAdvacedUtils mainToolAdvacedUtils = null;


    public void startAdvanced() {
        mainToolAdvacedUtils.startAdvace();
        BaseParam.isStartAdvaced = true;
        tvAdvanced.setText("关闭转账");
        showToast("开启成功");
        tvAdvanced.setBackgroundResource(R.drawable.bg_login_red_radius);
    }

    public void stopAdvanced() {
        mainToolAdvacedUtils.stopAdvace();
        BaseParam.isStartAdvaced = false;
        tvAdvanced.setText("开启转账");
        showToast("关闭成功");
        tvAdvanced.setBackgroundResource(R.drawable.bg_orange_radius);
    }


    private void clickAdvanced() {
        //启动定时器还是限额，先判断条件，再启动
        int tempType = SPUtils.getInstance().getInt(BaseParam.TRANSFERMODETYPE, 0);
        String pw = SPUtils.getInstance().getString(BaseParam.TRANSFERPW);

        if (BaseParam.isStartAdvaced) {
            //关闭
            stopAdvanced();
        } else {
            //启动
            if (!TextUtils.isEmpty(pw)) {
                if (tempType == 1 || tempType == 2) {
                    startAdvanced();
                } else {
                    showToast("高级功能需要先配置信息2");
                }
            } else {
                showToast("高级功能需要先配置信息");
            }
        }
    }

    private void setAdvanced() {
        AdvancedMainReceived additionalReceived = new AdvancedMainReceived();
        IntentFilter intentFilter2 = new IntentFilter();
        //转账
        intentFilter2.addAction(UniformString.ALIPAY_TRANFER);
        intentFilter2.addAction(UniformString.ALIPAY_BACK_TRANFER);
        intentFilter2.addAction(UniformString.ALIPAY_BACK_TRANFER1);
        intentFilter2.addAction(UniformString.ALIPAY_GET_TRANFER);
        registerReceiver(additionalReceived, intentFilter2);
    }

    /////高级功能//////

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent home = new Intent(Intent.ACTION_MAIN);
            home.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            home.addCategory(Intent.CATEGORY_HOME);
            startActivity(home);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void setAlipayType() {
        //显示当前支付宝类型
        //模式类型-----1.实时码  2.红包  3.收款
        int AlipayType = SPUtils.getInstance().getInt(BaseParam.NOWALIPAYMODE);

        if (AlipayType == 1) {
            tvAlipayType.setText("实时码");
        } else if (AlipayType == 2) {
            tvAlipayType.setText("红包");
        } else if (AlipayType == 3) {
            tvAlipayType.setText("收款");
        } else if (AlipayType == 4) {
            tvAlipayType.setText("转账码");
        } else {
            tvAlipayType.setText("");
        }
    }

    private static Vector<String> payListGetAlipayOrder = new Vector<String>();

    private void isHttpGetalipayNoRun() {

        int AlipayMode = SPUtils.getInstance().getInt(BaseParam.NOWALIPAYMODE);

        if (AlipayMode == 1) {

        } else if (AlipayMode == 2) {

        } else if (AlipayMode == 3) {
            //支付宝的收款通道key_id
            String tongdaokey = SPUtils.getInstance().getString(BaseParam.ALIPAY, alipayKey);

            OkHttpClient okHttpClient = new OkHttpClient();
            Request.Builder builder = new Request.Builder();
            //签名：md5($account_id.$equipment_id.'httpReturnOrderInfo');
            //MD5  通道id + 设备id + 字符串'httpReturnOrderInfo'
            String sign = MD5.md5(tongdaokey + MainUtils.getPesudoUniqueID() + "httpReturnOrderInfo");

            System.out.println("心跳请求=" + "请求支付宝主动收款\n" + BaseParam.base_url + BaseParam.base_common + "api/httpReturnOrderInfo?equipment_id=" + MainUtils.getPesudoUniqueID() + "&account_id=" + tongdaokey + "&sign=" + sign);
            LogUtils.setConsoleLogger(MainActivity.this, "请求支付宝主动收款\n" + BaseParam.base_url + BaseParam.base_common + "api/httpReturnOrderInfo?equipment_id=" + MainUtils.getPesudoUniqueID() + "&account_id=" + tongdaokey + "&sign=" + sign);
            Request request = builder.get().url(BaseParam.base_url + BaseParam.base_common + "api/httpReturnOrderInfo?equipment_id=" + MainUtils.getPesudoUniqueID() + "&account_id=" + tongdaokey + "&sign=" + sign).build();

            Call call = okHttpClient.newCall(request);

            call.enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    //失败调用
                    LogUtils.setConsoleLogger(MainActivity.this, "请求支付宝主动收款结果失败\n" + e.getMessage());
                }

                @Override
                public void onResponse(Call call, final Response response) throws IOException {
                    try {
                        //成功调用
                        //                    {"code":1,"msg":"success",
                        // "data":[{"order_no":"C313660708920064","amount":"0.01","receipt_name":"456456","alipay_user_id":null},
                        // {"order_no":"C313661056115520","amount":"0.01","receipt_name":"456456","alipay_user_id":null},{"order_no":"C313662007075716","amount":"0.01","receipt_name":"456456","alipay_user_id":null},{"order_no":"C313662630351435","amount":"0.01","receipt_name":"456456","alipay_user_id":null},{"order_no":"C313664510622734","amount":"0.01","receipt_name":"456456","alipay_user_id":null},{"order_no":"C313666181301387","amount":"0.01","receipt_name":"456456","alipay_user_id":null},{"order_no":"C313670227795056","amount":"0.01","receipt_name":"456456","alipay_user_id":null},{"order_no":"C313670913898035","amount":"0.01","receipt_name":"456456","alipay_user_id":null}]}


                        //获取网络访问返回的字符串
                        final String tempResult = response.body().string();
                        System.out.println("请求主动生成支付宝收款结果" + tempResult);
                        if (Utils.isJson(tempResult)) {
                            JSONObject jsonObj = new JSONObject(tempResult);
                            String code = jsonObj.optString("code", "0");
                            if (code.equals("1")) {
                                JSONArray tempData = jsonObj.getJSONArray("data");
                                LogUtils.setConsoleLogger(MainActivity.this, "请求支付宝主动收款结果\n" + tempData.length() + "条数据");
                                for (int i = 0; i < tempData.length(); i++) {
                                    JSONObject jsonObjTemp = new JSONObject(tempData.get(i).toString());
                                    String order_no = jsonObjTemp.optString("order_no", "");
                                    String amount = jsonObjTemp.optString("amount", "");
                                    String alipay_user_id = jsonObjTemp.optString("alipay_user_id", "");
                                    if (alipay_user_id.equals("") || alipay_user_id.equals("null")) {

                                    } else {
                                        Thread.sleep(500);
                                        System.out.println("请求主动生成支付宝执行：" + order_no);
                                        if (payListGetAlipayOrder.contains(order_no)) {

                                        } else {
                                            payListGetAlipayOrder.add(order_no);
                                            AlipayReceivedUtils.sendAlipayBill(MainActivity.this, order_no, alipay_user_id, amount);
                                        }

                                    }
                                }

                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });


        } else {

        }

    }

    /////申请存储权限/////
    private void performEXTERNAL() {
        if (!checkEXTERNAL())
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);

    }

    private boolean checkEXTERNAL() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }
    /////申请存储权限/////

}
