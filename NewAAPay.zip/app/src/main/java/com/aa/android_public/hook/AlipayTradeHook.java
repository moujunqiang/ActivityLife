package com.aa.android_public.hook;

import android.content.Context;
import android.content.Intent;

import com.aa.android_public.utils.AlipayTradeUtils;
import com.alibaba.fastjson.JSON;
import com.support.fastthink.data.StringUtils;
import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.UniformString;

import org.json.JSONObject;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * 支付宝查订单回调Hook
 */
public class AlipayTradeHook {

    public static String tempCook = "";

    public void hook(final ClassLoader classLoader, final Context context) {
        try {
            Class<?> insertTradeMessageInfo = XposedHelpers.findClass("com.alipay.android.phone.messageboxstatic.biz.dao.TradeDao", classLoader);
            XposedBridge.hookAllMethods(insertTradeMessageInfo, "insertMessageInfo", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    try {
                        LogUtils.sendLogger("======支付宝个人收款start=========");

                        //获取content字段
            			//String content=(String) XposedHelpers.getObjectField(param.args[0], "content");
            			//XposedBridge.log(content);
                        //获取全部字段
                        Object object = param.args[0];
                        String MessageInfo = (String) XposedHelpers.callMethod(object, "toString");

                        LogUtils.sendLogger("支付宝个人收款完整信息：" + MessageInfo);

                        String content = StringUtils.getTextCenter(MessageInfo, "content='", "'");
                        LogUtils.sendLogger("1支付宝个人收款content=信息：" + content);

                        if (content.contains("二维码收款") || content.contains("收到一笔转账") || content.contains("收款金额")) {
                            LogUtils.sendLogger("支付宝个人收款content=信息已包含收款字段");

                            JSONObject jsonObject = new JSONObject(content);
                            String money = jsonObject.getString("content");
                            String mark = jsonObject.getString("assistMsg2");
                            String tradeNo = StringUtils.getTextCenter(MessageInfo, "tradeNO=", "&");

                            LogUtils.sendLogger("2收到支付宝支付订单： 订单号：" + tradeNo + " 金额：" + money + " 备注：" + mark);

                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("bill_no", tradeNo);
                            broadCastIntent.putExtra("bill_money", money.replace("￥", ""));
                            broadCastIntent.putExtra("bill_mark", mark);
                            broadCastIntent.putExtra("bill_type", UniformString.ALIPAY);
                            broadCastIntent.setAction(UniformString.BILLRECEIVED_ACTION);
                            context.sendBroadcast(broadCastIntent);

                        }else
                        ////新模式--收款--/////
                        if (content.contains("收款到账")) {
                            JSONObject jsonObject = new JSONObject(JSON.toJSONString(object));
                            JSONObject contentJson = new JSONObject(jsonObject.getString("content"));
                            String receiveAmount = contentJson.getString("content").replace("￥", "");
                            String remark = contentJson.getString("assistMsg2");
                            String crowdNo = jsonObject.optString("msgId");

                            LogUtils.sendLogger("支付宝收款模式到账： 订单号：" + crowdNo+"金额：" + receiveAmount + " 备注:" + remark + " ");
                            String userId = jsonObject.optString("userId");

                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("no", crowdNo);
                            broadCastIntent.putExtra("userids", userId);
                            broadCastIntent.putExtra("money", receiveAmount);
                            broadCastIntent.putExtra("remark", remark);
                            broadCastIntent.setAction(UniformString.ALIPAYRECEIPT_ACTION);
                            context.sendBroadcast(broadCastIntent);
                        }
                        ////新模式--收款--/////



                        LogUtils.sendLogger("======支付宝个人收款end=========");
                    } catch (Exception e) {
                        LogUtils.sendLogger("支付宝个人收款异常" + e.getMessage());
                    }
                    super.beforeHookedMethod(param);
                }
            });


            Class<?> insertServiceMessageInfo = XposedHelpers.findClass("com.alipay.android.phone.messageboxstatic.biz.dao.ServiceDao", classLoader);
            XposedBridge.hookAllMethods(insertServiceMessageInfo, "insertMessageInfo", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    try {
                        LogUtils.sendLogger("======支付宝商家收款start=========");

                        Object object = param.args[0];
                        String MessageInfo = (String) XposedHelpers.callMethod(object, "toString");
                        LogUtils.sendLogger("支付宝商家收款完整信息：" + MessageInfo);

                        String content = StringUtils.getTextCenter(MessageInfo, "extraInfo='", "'").replace("\\", "");
                        LogUtils.sendLogger("1支付宝商家收款content=信息：" + content);

                        if (content.contains("二维码收款") || content.contains("收到一笔转账") || content.contains("收款金额")) {
                            LogUtils.sendLogger("2支付宝商家收款content=信息已包含收款字段");
                            tempCook = AlipayTradeUtils.getCookieStr(classLoader);

                            String cookie = AlipayTradeUtils.getCookieStr(classLoader);
                            LogUtils.sendLogger("支付宝商家收款cookie=" + cookie);

                            AlipayTradeUtils.getTradeInfo(context, cookie);

                        }
                        LogUtils.sendLogger("======支付宝商家收款end=========");
                    } catch (Exception e) {
                        LogUtils.sendLogger("支付宝商家收款异常" + e.getMessage());
                    }
                    super.beforeHookedMethod(param);
                }
            });
        } catch (Error | Exception e) {
            e.printStackTrace();
        }
    }
}
