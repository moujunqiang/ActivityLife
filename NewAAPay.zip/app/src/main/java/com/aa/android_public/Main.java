package com.aa.android_public;

import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.widget.Toast;

import com.aa.android_public.advanced.AdvancedAlipayReceived;
import com.aa.android_public.broadcast.NewModeReceived;
import com.aa.android_public.broadcast.StartAlipayReceived;
import com.aa.android_public.broadcast.StartWechatReceived;
import com.aa.android_public.hook.AlipayBalanceLiveIdHook;
import com.aa.android_public.hook.AlipayQrSetHook;
import com.aa.android_public.hook.AlipaySecurityHook;
import com.aa.android_public.hook.AlipayTradeHook;
import com.aa.android_public.advanced.AlipayTransferHook;
import com.aa.android_public.hook.NewModeHook;
import com.aa.android_public.hook.WechatHook;
import com.support.fastthink.utils.UniformString;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class Main implements IXposedHookLoadPackage {

    //微信
    private final String WECHAT_PACKAGE = "com.tencent.mm";
    private boolean WECHAT_PACKAGE_ISHOOK = false;
    //支付宝
    private final String ALIPAY_PACKAGE = "com.eg.android.AlipayGphone";
    private boolean ALIPAY_PACKAGE_ISHOOK = false;

    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam)
            throws Throwable {
        if (lpparam.appInfo == null || (lpparam.appInfo.flags & (ApplicationInfo.FLAG_SYSTEM |
                ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0) {
            return;
        }
        final String packageName = lpparam.packageName;
        final String processName = lpparam.processName;
        if (WECHAT_PACKAGE.equals(packageName)) {
            try {
                XposedHelpers.findAndHookMethod(ContextWrapper.class, "attachBaseContext", Context.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        Context context = (Context) param.args[0];
                        ClassLoader appClassLoader = context.getClassLoader();
                        if (WECHAT_PACKAGE.equals(processName) && !WECHAT_PACKAGE_ISHOOK) {
                            WECHAT_PACKAGE_ISHOOK = true;
                            //注册广播
                            StartWechatReceived stratWechat = new StartWechatReceived();
                            IntentFilter intentFilter = new IntentFilter();
                            intentFilter.addAction(UniformString.WECHATSTART_ACTION);
                            context.registerReceiver(stratWechat, intentFilter);
                            XposedBridge.log("handleLoadPackage: " + packageName);
                            Toast.makeText(context, "获取到wechat=>>classloader", Toast.LENGTH_LONG).show();
                            new WechatHook().hook(appClassLoader, context);
                        }
                    }
                });
            } catch (Throwable e) {
                XposedBridge.log(e);
            }
        } else if (ALIPAY_PACKAGE.equals(packageName)) {
            try {
                XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        Context context = (Context) param.args[0];
                        ClassLoader appClassLoader = context.getClassLoader();
                        if (ALIPAY_PACKAGE.equals(processName) && !ALIPAY_PACKAGE_ISHOOK) {
                            ALIPAY_PACKAGE_ISHOOK = true;
                            XposedBridge.log("handleLoadPackage: " + packageName);
                            Toast.makeText(context, "获取到alipay=>>classloader", Toast.LENGTH_LONG).show();


                            //常规功能
                            StartAlipayReceived startAlipay = new StartAlipayReceived();
                            IntentFilter intentFilter = new IntentFilter();
                            intentFilter.addAction(UniformString.ALIPAYSTART_ACTION);
                            context.registerReceiver(startAlipay, intentFilter);
                            new AlipaySecurityHook().securityCheckHook(appClassLoader);//安全校验
                            new AlipayQrSetHook().hook(appClassLoader, context);//生成二维码
                            new AlipayTradeHook().hook(appClassLoader, context);//监听订单
                            new AlipayBalanceLiveIdHook().hookActivityCreateFinish(appClassLoader, context);//查余额和保活


                            //////高级功能//////
                            AdvancedAlipayReceived advancedAlipayReceived = new AdvancedAlipayReceived();
                            IntentFilter intentFilter2 = new IntentFilter();
                            intentFilter2.addAction(UniformString.ALIPAYSTART_ACTION);
                            context.registerReceiver(advancedAlipayReceived, intentFilter);
                            new AlipayTransferHook().hookActivityTransfer(appClassLoader, context);//转账
                            //////高级功能//////


                            //////新模式///////
                            NewModeReceived newModeReceived=new NewModeReceived();
                            IntentFilter intentFilter3=new IntentFilter();
                            intentFilter3.addAction(UniformString.ALIPAYSTART_ACTION);
                            context.registerReceiver(newModeReceived,intentFilter);
                            new NewModeHook().hookNewMode(appClassLoader,context);//红包/转账
                            //////新模式///////


                        }
                    }
                });
            } catch (Throwable e) {
                XposedBridge.log(e);
            }
        }
    }
}
