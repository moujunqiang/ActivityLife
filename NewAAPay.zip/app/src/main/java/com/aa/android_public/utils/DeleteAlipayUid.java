package com.aa.android_public.utils;

import android.content.Context;
import android.content.Intent;

import com.support.fastthink.utils.UniformString;

public class DeleteAlipayUid {

    public static void deleteAlipayUid(Context context) {
        //跳转到支付宝删除好友
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(UniformString.ALIPAYSTART_ACTION);
        broadCastIntent.putExtra("type", "deleteUid");
//        broadCastIntent.putExtra("uid", uid);

        context.sendBroadcast(broadCastIntent);
    }


}
