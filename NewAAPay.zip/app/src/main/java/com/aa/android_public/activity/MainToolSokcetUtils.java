package com.aa.android_public.activity;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.aa.android_public.socket.SocketClient;
import com.aa.android_public.socket.SocketListener;
import com.aa.android_public.socket.SocketToMainActivityListener;
import com.aa.android_public.utils.AlipayReceivedUtils;
import com.aa.android_public.utils.CheckUserIdUtils;
import com.aa.android_public.utils.QrSetUtils;
import com.support.fastthink.BaseParam;
import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.SPUtils;
import com.support.fastthink.utils.UniformString;

import java.net.URI;
import java.net.URISyntaxException;

//处理连接关闭socket等业务
public class MainToolSokcetUtils implements SocketListener {
    private SocketClient client;
    private Context context;
    private SocketToMainActivityListener socketToMainActivityListener;
    public MainToolSokcetUtils(Context context) {
        this.context = context;
    }
    public void setSocketMessage(SocketToMainActivityListener socketToMainActivityListener) {
        this.socketToMainActivityListener = socketToMainActivityListener;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    private int state = 0;//默认0，，连接，关闭，设置0，已打开，已关闭设置1.2

    //建立连接
    public void connectSocket() {
        setState(0);
        try {
            client = new SocketClient(new URI(BaseParam.base_socketurl));
            client.setSocketListener(this);

            client.connect();
            if (context != null) {
                LogUtils.sendConsole(context, BaseParam.base_socketurl);
            }
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }

    }

    //发送数据
    public void sendSocket(String jsonSend) {
        if (client != null) {
            client.send(jsonSend);
        }
    }

    //关闭 socket
    public void closeSocket() {
        setState(0);
        if (client != null) {
            client.close();
        }
    }


    //检测是否在线
    public boolean isOpen() {
        boolean tempOpen = false;
        if (client != null) {
            if (client.isOpen()) {
                tempOpen = true;
            }
        }
        return tempOpen;
    }


    //socket监听
    @Override
    public void onOpen() {
        setState(1);
        if (context != null) {
            LogUtils.sendConsole(context, "通道已打开");
        }
    }

    @Override
    public void onClose() {
        setState(2);
        if (context != null) {
            LogUtils.sendConsole(context, "通道已关闭");
        }
    }

    @Override
    public void onError(Exception ex) {
        if (context != null) {
            LogUtils.sendConsole(context, "通道打开报错：" + ex.toString());
        }
    }

    //回调过来服务端命令内容
    @Override
    public void getAlipayUUid(String keyid,String messageuuid) {
        //发送广播到支付宝，获取uuid

        String alipayAcount = SPUtils.getInstance().getString(BaseParam.ALIPAY);
        if(keyid.equals(alipayAcount)){
            //广播到支付宝获取uuid
            if(context!=null){
                LogUtils.setConsoleLogger(context, "支付宝查询userid start");
                CheckUserIdUtils.getAlipayUserId(context,messageuuid);
            }
        }
    }

    @Override
    public void getQrPayurl(String channle_type,String keyid,String messageuuid,String money,String mark) {
        //取出通道，查询是支付宝还是微信，
        String alipayAcount = SPUtils.getInstance().getString(BaseParam.ALIPAY);
        String wechatAccount = SPUtils.getInstance().getString(BaseParam.WECHAT);
        System.out.println("生成二维码微信000="+wechatAccount);
        if(channle_type.equals("alipay")&&keyid.equals(alipayAcount)){
            //广播到支付宝去生成二维码
            if(context!=null){
                QrSetUtils.getAlipaySetQr(context ,money,mark);
            }
        }else if(channle_type.equals("wechat")&&wechatAccount.equals(keyid)){
            //广播到微信去生成二维码
            System.out.println("生成二维码微信0");
            if(context!=null){
                System.out.println("生成二维码微信1");
                QrSetUtils.getWeChatSetQr(context,money,mark);
            }
        }
    }

    @Override
    public void onMessageToMain( String liushui, String bishu, String xiane, String key_id) {
        if(socketToMainActivityListener!=null){
            socketToMainActivityListener.onMessageToMain(liushui,bishu,xiane,key_id);
        }
    }

    @Override
    public void onMessageToBlance(String blance) {
        if(socketToMainActivityListener!=null){
            socketToMainActivityListener.onMessageToBlance(blance);
        }
    }

    @Override
    public void onCloseChannel(String keyid) {
        //关闭，
        if(socketToMainActivityListener!=null){
            System.out.println("进入执行2="+keyid+">>>>");
            socketToMainActivityListener.onCloseChannel(keyid);
        }
    }

    @Override
    public void onMessageError(String msg, boolean isShow) {
        if(socketToMainActivityListener!=null){
            socketToMainActivityListener.onMessageError(msg,isShow);
        }
    }

    @Override
    public void onMessageGetWay(int alipay, int wechat) {
        if(socketToMainActivityListener!=null){
            socketToMainActivityListener.onMessageGetWay(alipay,wechat);
        }
    }

    @Override
    public void onMainAlipayReceived(String mark, String userid, String money, String keyid) {
        String alipay_received = "";

         String alipayAcount = SPUtils.getInstance().getString(BaseParam.ALIPAY).trim();

        if (!TextUtils.isEmpty(alipayAcount)) {
            alipay_received = alipayAcount.trim();

            LogUtils.sendLogger("2当前通道的指令"+"alipay_received:"+alipay_received+" \n"+keyid.equals(alipay_received)+"  \n"+
            keyid);


            if(keyid.equals(alipay_received)){
                LogUtils.sendLogger("3当前通道的指令"+"mark:"+mark+"  user_id:"+userid+"  money："+money+"  key_id："+keyid);
                LogUtils.setConsoleCollection(context,"接收到后台生成支付宝收款指令:\n "+"当前通道："+alipay_received+" \n"+keyid.equals(alipay_received)+"  \n 指令通道："+
                        keyid+"\n"+" "+"\n mark:"+mark+"  \n user_id:"+userid+"\n  money："+money);
                AlipayReceivedUtils.sendAlipayBill(context,mark,userid,money);

            }
        }
    }

    @Override
    public void onMessageLoginError(String msg, boolean isShow) {
        if(context!=null){
            LogUtils.setConsoleLogger(context, msg);
        }
    }

    @Override
    public void onMessageIp(String msg) {
        if(socketToMainActivityListener!=null){
            socketToMainActivityListener.onMessageIp(msg);
        }
    }

    @Override
    public void onMessageIpError(String msg) {
        if(socketToMainActivityListener!=null){
            socketToMainActivityListener.onMessageIpError(msg);
        }
    }

}
