package com.aa.android_public.utils;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

import com.aa.android_public.R;
import com.support.fastthink.BaseAdapter;
import com.support.fastthink.entity.OrderBean;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class OrderDetailAdapter extends BaseAdapter<OrderBean> {
    private Context context;

    public OrderDetailAdapter(Context context) {
        super(context);
        this.context = context;
    }

    @Override
    public int getContentView() {
        return R.layout.item_order;
    }


    @Override
    public void onInitView(View view, final int position) {
        List<OrderBean> orderBeanList = getList();
        final OrderBean orderBean = orderBeanList.get(position);
        TextView tvSort = get(view, R.id.tv_order_sort);
        TextView tvOrder = get(view, R.id.tv_order_id);
        TextView tvMoney = get(view, R.id.tv_order_money);
        TextView tvType = get(view, R.id.tv_order_type);
        TextView tvRemark = get(view, R.id.tv_order_remark);
        TextView tvTime = get(view, R.id.tv_order_time);
        TextView tvStatus = get(view, R.id.tv_order_status);


        tvSort.setText(position + 1 + "");
        tvOrder.setText("订单号：" + orderBean.getTradeno());
        tvMoney.setText("订单金额：" + orderBean.getMoney());
        tvRemark.setText("订单备注：" + orderBean.getRemark());
        tvTime.setText("订单时间：" + stampToDate(orderBean.getDt()));
        tvStatus.setText(orderBean.getStatus() + "");


        if (orderBean.getType() == 1) {
            tvType.setText("支付宝(个人)");
        } else if (orderBean.getType() == 2) {
            tvType.setText("支付宝(商家)");
        } else if (orderBean.getType() == 3) {
            tvType.setText("微信");
        } else {
            tvType.setText("未知");
        }
    }

    /*
     * 将时间戳转换为时间
     */
    public static String stampToDate(String s) {
        String res;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        long lt = new Long(s);
        Date date = new Date(lt);
        res = simpleDateFormat.format(date);
        return res;
    }
}
