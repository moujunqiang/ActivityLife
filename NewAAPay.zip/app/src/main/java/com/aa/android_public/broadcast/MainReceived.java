package com.aa.android_public.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.aa.android_public.activity.MainToolSokcetUtils;
import com.aa.android_public.utils.AlipayTradeUtils;
import com.aa.android_public.utils.MainUtils;
import com.aa.android_public.utils.SocketSendUtils;
import com.support.fastthink.BaseParam;
import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.SPUtils;
import com.support.fastthink.utils.UniformString;
import com.support.fastthink.utils.Utils;

import java.util.List;
import java.util.Vector;


/**
 * 主页广播接收
 */
public class MainReceived extends BroadcastReceiver {
    private MainToolSokcetUtils mainToolSokcetUtils=null;
    private  MainReceivedListener mainReceivedListener;
    public  MainReceived(MainToolSokcetUtils mainToolSokcetUtils,MainReceivedListener mainReceivedListener){
        this.mainToolSokcetUtils=mainToolSokcetUtils;
        this.mainReceivedListener=mainReceivedListener;
    }
    //

    //广播处统一加过滤，static list，防止多余的广播发出去
    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            if (intent.getAction().contentEquals(UniformString.LIVE_HOME_ACTION_START)) {
                //1.保活,支付宝，微信需要定期跳转//
                MainUtils.backAPP();
            } else if (intent.getAction().contentEquals(UniformString.BALANCERECEIVED_ACTION)) {
                //2.查询余额//
//                MainUtils.backAPP();
//                String balance = intent.getStringExtra("balance");
//                String type = intent.getStringExtra("type");
//                String remark = intent.getStringExtra("remark");
//                if (type.equals(UniformString.ALIPAY)) {
//                    LogUtils.setConsoleLogger(context, "结果：当前支付宝余额为：" + balance);
//                    if(remark.equals("0")||remark.equals("")){
//                        LogUtils.setConsoleLogger(context, "手动查询="+remark );
//                        return;
//                    }else if(ListOrderCreate.contains(remark)){
//                        return;
//                    }else{
//                        ListOrderCreate.add(remark);
//                      //发送广播去转账
//                        Intent broadCastIntent = new Intent();
//                        broadCastIntent.setAction(UniformString.ALIPAY_GET_TRANFER);
//                        broadCastIntent.putExtra("balance", balance);
//                        broadCastIntent.putExtra("remark", remark);
//                        context.sendBroadcast(broadCastIntent);
//                    }
//                } else if (type.equals(UniformString.WECHAT)) {
//
//                }
            } else if (intent.getAction().contentEquals(UniformString.CHECK_HOME_ACTION_USERID)) {
                //3.查询UserId//
                MainUtils.backAPP();
                String userid = intent.getStringExtra("userid");
                String messageuuid = intent.getStringExtra("messageuuid");
                SPUtils.getInstance().put(BaseParam.ALIPAYUID, userid);
                LogUtils.setConsoleLogger(context, "结果：当前支付UserId：" + userid);
                //发送服务器----userid回调
                String key_id = SPUtils.getInstance().getString(BaseParam.ALIPAY);
                SocketSendUtils.sendOrderServer(mainToolSokcetUtils,context,messageuuid,userid,key_id);

                mainReceivedListener.reMessageUid(userid);
            } else if (intent.getAction().contentEquals(UniformString.ZHUANZHANG_UID)) {
                //转账,,实际未进入这里，放弃
                //支付包转转账收款
//                String no = intent.getStringExtra("bill_no");
//                String money = intent.getStringExtra("bill_money");
//                String mark = intent.getStringExtra("bill_mark");
//                String type = intent.getStringExtra("bill_type");
//                String from_u_id = intent.getStringExtra("from_u_id");
//
//                //添加本地数据库
//                Utils.addOrder(no, 1, money, mark, 1);
//
//                //打印
//                LogUtils.setConsoleLogger(context, "结果：收到支付宝个人支付成功订单\n" + "  订单号：" + no + " 订单金额：" + money + " 订单备注：" + mark);
//                LogUtils.setConsoleCollection(context, "\n(支付宝个人收款)" + "\n订单ID：" + no + "\n订单金额：" + money + "\n订单备注：" + mark+
//                        "\n--------------------");
//
//                System.out.println("收到回调----------------"+"\n(支付宝个人收款)" + "\n订单ID：" + no + "\n订单金额：" + money + "\n订单备注：" + mark+
//                        "\n--------------------uid="+from_u_id);
//                //发送服务器----订单回调
//                SocketSendUtils.sendOrderServer(mainToolSokcetUtils,context, type, no, money, mark,
//                        SPUtils.getInstance().getString(BaseParam.ALIPAY, ""),from_u_id);
            } else if (intent.getAction().contentEquals(UniformString.QRCODERECEIVED_ACTION)) {
                //4.实时码生成//
                MainUtils.backAPP();
                String money = intent.getStringExtra("money");
                String mark = intent.getStringExtra("mark");
                String type = intent.getStringExtra("type");
                String payurl = intent.getStringExtra("payurl");

                //打印
                LogUtils.setConsoleLogger(context, "当前生成的二维码：" + payurl);
                LogUtils.setConsoleLogger(context, "结果：当前实时码生成：" + "金额：" + money + " 备注：" + mark + " 类型：" + type + " 二维码链接：" + payurl);

                String tempType="";
                if(type.equals(UniformString.ALIPAY)){
                    tempType="支付宝实时码";
                }else if(type.equals(UniformString.WECHAT)){
                    tempType="微信实时码";
                }
                LogUtils.setConsoleCollection(context, "实时码生成：" + "\n金额：" + money + "\n备注：" + mark + "\n类型：" + tempType + "\n二维码链接：" + payurl);

                //发送服务器----二维码
                SocketSendUtils.sendQrServer(mainToolSokcetUtils,context, type, money, mark, payurl);
            } else if (intent.getAction().contentEquals(UniformString.BILLRECEIVED_ACTION)) {
                //5.个人订单//
                String no = intent.getStringExtra("bill_no");
                String money = intent.getStringExtra("bill_money");
                String mark = intent.getStringExtra("bill_mark");
                String type = intent.getStringExtra("bill_type");

                LogUtils.setConsoleLogger(context, "收到个人支付成功订单" + type);

                if (type.equals(UniformString.ALIPAY)) {

//                    int AlipayType = SPUtils.getInstance().getInt(BaseParam.NOWALIPAYMODE);
//                    if(AlipayType==4){
//                        //转账码，不回调，由另外的数据区回调,过滤
//                        System.out.println("过滤该消息");
//                    }else{
                        //添加本地数据库
                        Utils.addOrder(no, 1, money, mark, 1);

                        //打印
                        LogUtils.setConsoleLogger(context, "结果：收到支付宝个人支付成功订单\n" + "  订单号：" + no + " 订单金额：" + money + " 订单备注：" + mark);
                        LogUtils.setConsoleCollection(context, "\n(支付宝个人收款)" + "\n订单ID：" + no + "\n订单金额：" + money + "\n订单备注：" + mark+
                                "\n--------------------");

                        //发送服务器----订单回调
                        SocketSendUtils.sendOrderServer(mainToolSokcetUtils,context, type, no, money, mark,
                                SPUtils.getInstance().getString(BaseParam.ALIPAY, ""));
//                    }



                } else if (type.equals(UniformString.WECHAT)) {

                    //添加本地数据库
                    Utils.addOrder(no, 3, money, mark, 1);

                    //打印
                    LogUtils.setConsoleLogger(context, "结果：收到微信个人支付成功订单\n" + "  订单号：" + no + " 金额：" + money + " 备注：" + mark);
                    LogUtils.setConsoleCollection(context, "\n(微信收款)" + "\n订单ID：" + no + "\n订单金额：" + money + "\n订单备注：" + mark
                    +"\n--------------------");
                    //发送服务器----订单回调
                    SocketSendUtils.sendOrderServer(mainToolSokcetUtils,context, type, no, money, mark,
                            SPUtils.getInstance().getString(BaseParam.WECHAT, ""));
                }



            } else if (intent.getAction().contentEquals(UniformString.TRADENORECEIVED_ACTION)) {
                //6.支付宝商家订单//
                String tradeno = intent.getStringExtra("tradeno");
                String cookie = intent.getStringExtra("cookie");

                //判断商家订单号是否已经存在
                if (!Utils.isExistMerchantNo(tradeno)) {
                    //获取当前新订单备注及金额
                    AlipayTradeUtils.getTradeInfo(mainToolSokcetUtils,context, tradeno, cookie);
                }
            ////新模式--收款--红包--/////
            } else if (intent.getAction().contentEquals(UniformString.REDENVELOPE_ACTION)) {
                //7.支付宝红包订单//
                String no = intent.getStringExtra("no");
                String userids = intent.getStringExtra("userids");
                String money = intent.getStringExtra("money");
                String remark = intent.getStringExtra("remark");
                LogUtils.setConsoleCollection(context,"发送收到红包订单:\n 支付宝订单号：" + no + "\n 金额:" + money + "\n 备注:" + remark);
                LogUtils.sendLogger("发送收到红包订单:\n 支付宝订单号：" + no + "\n 金额:" + money + "\n 备注:" + remark + "\n userid:" + userids);

                //发送服务器----发送支付宝收款订单号
                SocketSendUtils.sendOrderServer(mainToolSokcetUtils,context, UniformString.ALIPAYRED, no, money, remark,SPUtils.getInstance().getString(BaseParam.ALIPAY, ""),userids);
//                SocketSendUtils.sendAlipayEnvelopeOrder(mainToolSokcetUtils,context,no,money,SPUtils.getInstance().getString(BaseParam.ALIPAY,""),remark);

            } else if (intent.getAction().contentEquals(UniformString.ALIPAYRECEIPT_ACTION)) {
                //8.支付宝主动收款收款订单//
                                    int AlipayType = SPUtils.getInstance().getInt(BaseParam.NOWALIPAYMODE);
                    if(AlipayType==4){

                        System.out.println("过滤改消息，改消息属于转个人不可修改，不属于主动收款");
                    }else{
                        String no = intent.getStringExtra("no");
                        String userids = intent.getStringExtra("userids");
                        String money = intent.getStringExtra("money");
                        String remark = intent.getStringExtra("remark");
                        LogUtils.setConsoleCollection(context,"发送收到收款订单:\n 支付宝订单号：" + no + "\n 金额:" + money + "\n 备注:" + remark);
                        LogUtils.sendLogger("发送收到收款订单:\n 支付宝订单号：" + no + "\n 金额:" + money + "\n 备注:" + remark + "\n userid:" + userids);

                        //发送服务器----发送支付宝收款订单号
                        SocketSendUtils.sendOrderServer(mainToolSokcetUtils,context, UniformString.ALIPAYCOLE, no, money, remark,SPUtils.getInstance().getString(BaseParam.ALIPAY, ""));
//                SocketSendUtils.sendAlipayReceiptOrder(mainToolSokcetUtils,context,no,money,SPUtils.getInstance().getString(BaseParam.ALIPAY,""),remark);

                    }

            } else if (intent.getAction().contentEquals(UniformString.RECEIPT_ORDER)) {
                //9.支付宝收款发送订单号//
                String mark = intent.getStringExtra("mark");
                String userid = intent.getStringExtra("userid");
                String money = intent.getStringExtra("money");
                String alipayNo = intent.getStringExtra("alipayNo");

                String messageError = intent.getStringExtra("message");

                String order_type = intent.getStringExtra("order_type");
                LogUtils.setConsoleCollection(context,"发送生成支付宝收款订单收到:\n 支付宝订单号：" + alipayNo +
                        "\n 金额:" + money + "\n 备注:" + mark+"\n userid:" + userid+"\n成功失败状态"+order_type );
                LogUtils.sendLogger("发送生成支付宝收款订单收到:\n 支付宝订单号：" + alipayNo +
                        "\n 金额:" + money + "\n 备注:" + mark+"\n userid:" + userid+"\n成功失败状态"+order_type );

                //发送服务器----发送支付宝收款订单号
                SocketSendUtils.sendAlipayReceiptNo(mainToolSokcetUtils,context,mark,userid,money,
                        alipayNo,SPUtils.getInstance().getString(BaseParam.ALIPAY,""),order_type,messageError);

            }else if(intent.getAction().contentEquals(UniformString.ALIPAYUID_ACTION)) {

                //增加支付宝好友

                String uid = intent.getStringExtra("uid");
                System.out.println("增加支付宝好友0="+uid);
                if(Utils.isExistAlipayUid(uid)){

                }else{
                    Utils.addAlipayUid(uid);
                    System.out.println("增加支付宝好友1="+uid);


                }
            }
            ////新模式--收款--红包--/////
        } catch (Exception e) {
            e.printStackTrace();
        }
    }




}