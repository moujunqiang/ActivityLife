package com.aa.android_public.hook;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.UniformString;

import java.lang.reflect.Field;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * 支付宝固码生成Hook
 */
public class AlipayQrSetHook {

    public void hook(final ClassLoader classLoader, final Context context) {
        try {


            // hook设置金额和备注的onCreate方法，自动填写数据并点击
            XposedHelpers.findAndHookMethod("com.alipay.mobile.payee.ui.PayeeQRSetMoneyActivity", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    Field jinErField = XposedHelpers.findField(param.thisObject.getClass(), "b");
                    final Object jinErView = jinErField.get(param.thisObject);
                    Field beiZhuField = XposedHelpers.findField(param.thisObject.getClass(), "c");
                    final Object beiZhuView = beiZhuField.get(param.thisObject);
                    Intent intent = ((Activity) param.thisObject).getIntent();
                    String mark = intent.getStringExtra("mark");
                    String money = intent.getStringExtra("money");

                    //设置支付宝金额和备注
                    XposedHelpers.callMethod(jinErView, "setText", money);
                    XposedHelpers.callMethod(beiZhuView, "setText", mark);


                    //点击确认
                    Field quRenField = XposedHelpers.findField(param.thisObject.getClass(), "e");
                    final Button quRenButton = (Button) quRenField.get(param.thisObject);
                    quRenButton.performClick();

                    LogUtils.setConsoleLogger(context, "支付宝实时码生成：2" + " 金额：" + money + " 备注：" + mark);


                }
            });
            // hook获得二维码url的回调方法
            XposedHelpers.findAndHookMethod("com.alipay.mobile.payee.ui.PayeeQRSetMoneyActivity", classLoader, "a",
                    XposedHelpers.findClass("com.alipay.transferprod.rpc.result.ConsultSetAmountRes", classLoader), new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {

                            Field moneyField = XposedHelpers.findField(param.thisObject.getClass(), "g");
                            String money = (String) moneyField.get(param.thisObject);

                            Field markField = XposedHelpers.findField(param.thisObject.getClass(), "c");
                            Object markObject = markField.get(param.thisObject);
                            String mark = (String) XposedHelpers.callMethod(markObject, "getUbbStr");

                            Object consultSetAmountRes = param.args[0];
                            System.out.println("当前数据长度：" + param.args.length);
                            Field consultField = XposedHelpers.findField(consultSetAmountRes.getClass(), "qrCodeUrl");
                            String payurl = (String) consultField.get(consultSetAmountRes);

                            Field consultField1 = XposedHelpers.findField(consultSetAmountRes.getClass(), "codeId");
                            String codeId = (String) consultField1.get(consultSetAmountRes);

                            Field consultField2 = XposedHelpers.findField(consultSetAmountRes.getClass(), "printQrCodeUrl");
                            String printQrCodeUrl = (String) consultField2.get(consultSetAmountRes);

                            System.out.println("当前数据corid：" + codeId + "   " + printQrCodeUrl);

                            XposedBridge.log(money + "  " + mark + "  " + payurl);
                            XposedBridge.log("调用增加数据方法==>支付宝");
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("money", money);
                            broadCastIntent.putExtra("mark", mark);
                            broadCastIntent.putExtra("type", UniformString.ALIPAY);
                            broadCastIntent.putExtra("payurl", payurl);
                            broadCastIntent.setAction(UniformString.QRCODERECEIVED_ACTION);
                            context.sendBroadcast(broadCastIntent);
                            LogUtils.setConsoleLogger(context, "支付宝实时码生成：3" + " 金额：" + money + " 备注：" + mark + " 二维码链接：" + payurl);
                        }
                    });

        } catch (Error | Exception e) {
            e.printStackTrace();
        }
    }
}
