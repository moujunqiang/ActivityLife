package com.aa.android_public.advanced;

import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.aa.android_public.R;
import com.support.fastthink.BaseActivity;
import com.support.fastthink.BaseParam;
import com.support.fastthink.utils.SPUtils;

/**
 * 高级功能---转账
 */
public class AdvancedTransferActivity extends BaseActivity implements View.OnClickListener {
    //init
    private RelativeLayout rlTransferType;
    private EditText etBankCard, etName;
    private EditText etAlipayAccount;
    private EditText etPassword;
    private EditText etAmount;
    private TextView tvSave, tvTransferType;
    private LinearLayout llTypeBank;
    private RelativeLayout rlTypeAlipay;
    private RadioButton rbTransferLimit, rbTransferTiming;
    private RelativeLayout rlTimingShow, rlAmountType, rlAmountShow;
    private TextView tvAmountType;
    private EditText etTimingTime;
    private String bankCard = "转银行卡";
    private String alipayAccount = "转支付宝账号";

    private boolean isLimit = true;//是否限额模式


    private int TransferType = 0;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced_transfer);
        initView();
    }


    private void initView() {
        this.findViewById(R.id.tv_home_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        //转账类型
        rlTransferType = findViewById(R.id.rl_transfer_type);
        rlTransferType.setOnClickListener(this);
        tvTransferType = findViewById(R.id.tv_transfer_type);
        //卡号
        etBankCard = findViewById(R.id.et_transfer_bank_card);
        //姓名
        etName = findViewById(R.id.et_transfer_name);
        //支付宝账号
        etAlipayAccount = findViewById(R.id.et_transfer_account);
        //支付密码
        etPassword = findViewById(R.id.et_transfer_password);
        //转账金额
        etAmount = findViewById(R.id.et_transfer_amount);
        //保存
        tvSave = findViewById(R.id.tv_settings_submit);
        tvSave.setOnClickListener(this);
        //银行卡类型
        llTypeBank = findViewById(R.id.ll_type_bank);
        //支付宝账号类型
        rlTypeAlipay = findViewById(R.id.rl_type_alipay);

        //选择金额类型
        rlAmountType = findViewById(R.id.rl_amount_type);
        rlAmountType.setOnClickListener(this);
        tvAmountType = findViewById(R.id.tv_amount_type);

        //定时时间展示
        rlTimingShow = findViewById(R.id.rl_timing_time);
        etTimingTime = findViewById(R.id.et_timing_time);

        //显示输入金额
        rlAmountShow = findViewById(R.id.rl_amount_show);

        //限额
        rbTransferLimit = findViewById(R.id.rb_transfer_limit);
        //定时
        rbTransferTiming = findViewById(R.id.rb_transfer_timing);

        if (SPUtils.getInstance().getInt(BaseParam.TRANSFERMODETYPE) == 2) {
            //定时模式
            isLimit = false;
            rbTransferTiming.setChecked(true);
            rbTransferLimit.setChecked(false);
            rlTimingShow.setVisibility(View.VISIBLE);
            rlAmountType.setVisibility(View.VISIBLE);

            //是否固定金额
            if (SPUtils.getInstance().getInt(BaseParam.TRANSFERAMOUNTTYPE) == 1) {
                rlAmountShow.setVisibility(View.VISIBLE);
                tvAmountType.setText("转固定金额");
                SPUtils.getInstance().put(BaseParam.TRANSFERAMOUNTTYPE, 1);
            } else {
                rlAmountShow.setVisibility(View.GONE);
                tvAmountType.setText("转全部金额");
                SPUtils.getInstance().put(BaseParam.TRANSFERAMOUNTTYPE, 2);
            }
        } else {
            //未选择或者已选择限额模式
            isLimit = true;
            rbTransferTiming.setChecked(false);
            rbTransferLimit.setChecked(true);
            rlTimingShow.setVisibility(View.GONE);
            rlAmountType.setVisibility(View.GONE);
            SPUtils.getInstance().put(BaseParam.TRANSFERMODETYPE, 1);
        }


        //点击限额
        rbTransferLimit.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Log.i("当前选择限额", b + "");
                if (b) {
                    isLimit = true;
                    SPUtils.getInstance().put(BaseParam.TRANSFERMODETYPE, 1);
                    rlTimingShow.setVisibility(View.GONE);
                    rlAmountType.setVisibility(View.GONE);
                    rlAmountShow.setVisibility(View.VISIBLE);

                } else {
                    isLimit = false;
                    SPUtils.getInstance().put(BaseParam.TRANSFERMODETYPE, 2);
                    rlTimingShow.setVisibility(View.VISIBLE);
                    rlAmountType.setVisibility(View.VISIBLE);

                    //是否限额
                    if (SPUtils.getInstance().getInt(BaseParam.TRANSFERMODETYPE) == 1) {
                        rlAmountShow.setVisibility(View.VISIBLE);
                    } else {
                        rlAmountShow.setVisibility(View.GONE);
                    }

                    //是否固定金额
                    if (SPUtils.getInstance().getInt(BaseParam.TRANSFERAMOUNTTYPE) == 1) {
                        rlAmountShow.setVisibility(View.VISIBLE);
                        tvAmountType.setText("转固定金额");
                        SPUtils.getInstance().put(BaseParam.TRANSFERAMOUNTTYPE, 1);
                    } else {
                        rlAmountShow.setVisibility(View.GONE);
                        tvAmountType.setText("转全部金额");
                        SPUtils.getInstance().put(BaseParam.TRANSFERAMOUNTTYPE, 2);
                    }
                }

            }
        });

        //点击定时
        rbTransferTiming.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Log.i("当前选择定时", b + "");
                if (b) {
                    isLimit = false;
                    SPUtils.getInstance().put(BaseParam.TRANSFERMODETYPE, 2);
                    rlTimingShow.setVisibility(View.VISIBLE);
                    rlAmountType.setVisibility(View.VISIBLE);
                } else {
                    isLimit = true;
                    SPUtils.getInstance().put(BaseParam.TRANSFERMODETYPE, 1);
                    rlTimingShow.setVisibility(View.GONE);
                    rlAmountType.setVisibility(View.GONE);
                }

            }
        });

        //获取当前状态
        getData();
    }

    private void getData() {
        //类型
        int type = SPUtils.getInstance().getInt(BaseParam.TRANSFERTYPE, 0);
        if (type == 1) {
            setBankCard();
        } else if (type == 2) {
            setAlipayAccount();
        } else {
            llTypeBank.setVisibility(View.GONE);
            rlTypeAlipay.setVisibility(View.GONE);
        }

        //卡号
        String card = SPUtils.getInstance().getString(BaseParam.TRANSFERCARD);
        if (!TextUtils.isEmpty(card)) {
            etBankCard.setText(card);
            etBankCard.setSelection(card.length());
        }
        //姓名
        String name = SPUtils.getInstance().getString(BaseParam.TRANSFERNAME);
        if (!TextUtils.isEmpty(name)) {
            etName.setText(name);
            etName.setSelection(name.length());
        }
        //支付宝账号
        String account = SPUtils.getInstance().getString(BaseParam.TRANSFERACCOUNT);
        if (!TextUtils.isEmpty(account)) {
            etAlipayAccount.setText(account);
            etAlipayAccount.setSelection(account.length());

        }
        //密码
        String pw = SPUtils.getInstance().getString(BaseParam.TRANSFERPW);
        if (!TextUtils.isEmpty(pw)) {
            etPassword.setText(pw);
            etPassword.setSelection(pw.length());
        }
        //金额
        String amount = SPUtils.getInstance().getString(BaseParam.TRANSFERAMOUNT);
        if (!TextUtils.isEmpty(amount) && !amount.equals("0")) {
            etAmount.setText(amount);
            etAmount.setSelection(amount.length());
        }

        //时长
        if (SPUtils.getInstance().getInt(BaseParam.TRANSFERTIME) != -1) {
            String time = SPUtils.getInstance().getInt(BaseParam.TRANSFERTIME) + "";
            if (!TextUtils.isEmpty(time)) {
                etTimingTime.setText(time);
                etTimingTime.setSelection(time.length());
            }
        }


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.rl_transfer_type://选择类型
                showDialog();
                break;
            case R.id.rl_amount_type://定时模式选择固定金额或全部金额
                showDialog2();
                break;
            case R.id.tv_settings_submit://保存
                String transfer_card = etBankCard.getText().toString();//卡号
                String transfer_name = etName.getText().toString();//卡姓名
                String transfer_pw = etPassword.getText().toString();//密码
                String transfer_account = etAlipayAccount.getText().toString();//支付宝账号
                String transfer_amount = "";//金额
                //当前选择为定时模式---转全部金额，金额默认赋值为0
                if (SPUtils.getInstance().getInt(BaseParam.TRANSFERMODETYPE) == 2 && SPUtils.getInstance().getInt(BaseParam.TRANSFERAMOUNTTYPE) == 2) {
                    transfer_amount = "0";
                } else {
                    transfer_amount = etAmount.getText().toString();
                }

                if (TransferType == 0) {
                    //未选择转银行卡还是支付宝
                    showDialog("请选择转账类型");
                    return;
                } else if (TransferType == 1) {
                    //转银行卡
                    if (TextUtils.isEmpty(transfer_card) || TextUtils.isEmpty(transfer_name) || TextUtils.isEmpty(transfer_pw) || TextUtils.isEmpty(transfer_amount)) {
                        showDialog("请填写完整的信息");
                        return;
                    } else {
                        SPUtils.getInstance().put(BaseParam.TRANSFERTYPE, 1);
                        SPUtils.getInstance().put(BaseParam.TRANSFERCARD, transfer_card);
                        SPUtils.getInstance().put(BaseParam.TRANSFERNAME, transfer_name);
                        SPUtils.getInstance().put(BaseParam.TRANSFERPW, transfer_pw);
                        SPUtils.getInstance().put(BaseParam.TRANSFERAMOUNT, transfer_amount);
                    }
                } else if (TransferType == 2) {
                    //转支付宝账号
                    if (TextUtils.isEmpty(transfer_account) || TextUtils.isEmpty(transfer_pw) || TextUtils.isEmpty(transfer_amount)) {
                        showDialog("请填写完整的信息");
                        return;
                    } else {
                        SPUtils.getInstance().put(BaseParam.TRANSFERTYPE, 2);
                        SPUtils.getInstance().put(BaseParam.TRANSFERACCOUNT, transfer_account);
                        SPUtils.getInstance().put(BaseParam.TRANSFERPW, transfer_pw);
                        SPUtils.getInstance().put(BaseParam.TRANSFERAMOUNT, transfer_amount);

                    }
                }

                //是否为限额模式
                if (!isLimit) {
                    int Timing = 0;
                    String time = etTimingTime.getText().toString();
                    try {
                        Timing = Integer.parseInt(time);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }

                    if (TextUtils.isEmpty(time)) {
                        showDialog("请输入定时时长");
                        return;
                    } else {
                        SPUtils.getInstance().put(BaseParam.TRANSFERTIME, Timing);
                        showToast("保存配置成功");
                        finish();
                    }
                } else {
                    showToast("保存配置成功");
                    finish();
                }

                break;
            default:
                break;
        }
    }


    //选择转支付宝还是银行卡
    private void showDialog() {
        final Dialog dialog = new Dialog(this, R.style.Theme_Light_Dialog);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_transfer_type, null);
        //获得dialog的window窗口
        Window window = dialog.getWindow();
        //设置dialog在屏幕底部
        window.setGravity(Gravity.BOTTOM);
        //设置dialog弹出时的动画效果，从屏幕底部向上弹出
        window.setWindowAnimations(R.style.dialogStyle);
        window.getDecorView().setPadding(0, 0, 0, 0);
        //获得window窗口的属性
        WindowManager.LayoutParams lp = window.getAttributes();
        //设置窗口宽度为充满全屏
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        //设置窗口高度为包裹内容
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        //将设置好的属性set回去
        window.setAttributes(lp);
        //将自定义布局加载到dialog上
        dialog.setContentView(dialogView);
        LinearLayout llBank = dialogView.findViewById(R.id.ll_transfer_bank);
        final LinearLayout llAlipay = dialogView.findViewById(R.id.ll_transfer_alipay);
        dialog.show();
        llBank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                setBankCard();
            }
        });
        llAlipay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                setAlipayAccount();
            }
        });
    }

    //转银行卡模式
    private void setBankCard() {
        TransferType = 1;
        rlTypeAlipay.setVisibility(View.GONE);
        llTypeBank.setVisibility(View.VISIBLE);
        tvTransferType.setText(bankCard);
    }

    //转支付宝模式
    private void setAlipayAccount() {
        TransferType = 2;
        rlTypeAlipay.setVisibility(View.VISIBLE);
        llTypeBank.setVisibility(View.GONE);
        tvTransferType.setText(alipayAccount);
    }


    //定时模式--选择转固定金额还是全部金额
    private void showDialog2() {
        final Dialog dialog = new Dialog(this, R.style.Theme_Light_Dialog);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_amount_type, null);
        //获得dialog的window窗口
        Window window = dialog.getWindow();
        //设置dialog在屏幕底部
        window.setGravity(Gravity.BOTTOM);
        //设置dialog弹出时的动画效果，从屏幕底部向上弹出
        window.setWindowAnimations(R.style.dialogStyle);
        window.getDecorView().setPadding(0, 0, 0, 0);
        //获得window窗口的属性
        WindowManager.LayoutParams lp = window.getAttributes();
        //设置窗口宽度为充满全屏
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        //设置窗口高度为包裹内容
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        //将设置好的属性set回去
        window.setAttributes(lp);
        //将自定义布局加载到dialog上
        dialog.setContentView(dialogView);
        LinearLayout llModify = dialogView.findViewById(R.id.ll_transfer_modify);
        final LinearLayout llAll = dialogView.findViewById(R.id.ll_transfer_all);
        dialog.show();
        llModify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                rlAmountShow.setVisibility(View.VISIBLE);
                tvAmountType.setText("转固定金额");
                SPUtils.getInstance().put(BaseParam.TRANSFERAMOUNTTYPE, 1);
            }
        });
        llAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                rlAmountShow.setVisibility(View.GONE);
                tvAmountType.setText("转全部金额");
                SPUtils.getInstance().put(BaseParam.TRANSFERAMOUNTTYPE, 2);
            }
        });
    }

}
