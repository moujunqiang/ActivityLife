package com.aa.android_public.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.support.fastthink.utils.LogUtils;

import de.robv.android.xposed.XposedHelpers;

public class StartWechatReceived extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            if (intent.getStringExtra("type").equals("qrset")) {
                Intent intent2 = new Intent(context, XposedHelpers.findClass("com.tencent.mm.plugin.collect.ui.CollectCreateQRCodeUI", context.getClassLoader()));
                intent2.putExtra("mark", intent.getStringExtra("mark"));
                intent2.putExtra("money", intent.getStringExtra("money"));
                intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent2);
                LogUtils.setConsoleLogger(context, "微信实时码生成：2");
            } else if (intent.getStringExtra("type").equals("live")) {
                //保活
                Intent intent2 = new Intent(context, XposedHelpers.findClass("com.tencent.mm.plugin.setting.ui.setting.SettingsAboutMicroMsgUI", context.getClassLoader()));
                intent2.putExtra("isrun", intent.getStringExtra("isrun"));
                intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent2);
            }
        } catch (Exception e) {
            LogUtils.setConsoleLogger(context, "微信实时码生成：2 " + e.getMessage());
        }
    }
}