package com.aa.android_public.advanced;

public class BlanceBean {

    private float blance=0;//默认余额为0
    private boolean isGetBlance=false;//是否获取到了余额，默认未获取
    private String nowRemark="";//备注
    private boolean isNow=false;//是否需要直接点击立即付款

    public boolean isNow() {
        return isNow;
    }
    public void setNow(boolean now) {
        isNow = now;
    }

    public String getNowRemark() {
        return nowRemark;
    }

    public void setNowRemark(String nowRemark) {
        this.nowRemark = nowRemark;
    }

    public boolean isGetBlance() {
        return isGetBlance;
    }

    public void setGetBlance(boolean getBlance) {
        isGetBlance = getBlance;
    }

    public float getBlance() {
        return blance;
    }

    public void setBlance(float blance) {
        this.blance = blance;
    }
}
