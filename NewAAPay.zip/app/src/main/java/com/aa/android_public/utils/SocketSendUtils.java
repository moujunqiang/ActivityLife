package com.aa.android_public.utils;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;

import com.aa.android_public.activity.MainToolSokcetUtils;
import com.aa.android_public.socket.SocketClient;
import com.support.fastthink.BaseApplication;
import com.support.fastthink.BaseParam;
import com.support.fastthink.utils.LogToFile;
import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.SPUtils;
import com.support.fastthink.utils.UniformString;

import org.json.JSONException;
import org.json.JSONObject;

import static com.aa.android_public.advanced.TransferUtils.getAlipayTransferOrder;

public class SocketSendUtils {
    /**
     * 发送支付宝userid
     * <p>
     * {
     * "params": {
     * "messageuuid": "消息id",
     * " key_id": "通道",
     * "uuid": "支付宝id",
     * },
     * "type": "alipayuserid"
     * }
     */
    public static void sendOrderServer(MainToolSokcetUtils mainToolSokcetUtils, Context context, String messageuuid, String uuid, String key_id) {
        Log.i(UniformString.UNIFIEDPRINTING, "发送：当前支付宝userid：" + uuid);
        try {
            JSONObject jsonObj = new JSONObject();//pet对象，json形式
            jsonObj.put("messageuuid", messageuuid);

            jsonObj.put("key_id", key_id);
            jsonObj.put("uuid", uuid);
            jsonObj.put("merchant_id", SPUtils.getInstance().getInt(BaseParam.MERCHANTSID, 0));//码商id
            LogUtils.setConsoleLogger(context, "支付宝查询userid 结束" + uuid);
            sendMainMessage(mainToolSokcetUtils, context, jsonObj, "alipayuserid");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 收款
     *
     * @param type//类型（alipay支付宝，wechat微信）
     * @param orderId//订单号
     * @param orderMoney//订单金额
     * @param mark//订单备注                   {
     *                                     "params": {
     *                                     "messageuuid": "消息id",
     *                                     "dt": "时间戳",
     *                                     "no": "订单号",
     *                                     "money": "金额",
     *                                     "key": "通道id",
     *                                     "mark": "1|10086",
     *                                     },
     *                                     "type": "notifyurl"
     *                                     }
     */
  //以前得调用这个方法，有userid下面一个方法
    public static void sendOrderServer(MainToolSokcetUtils mainToolSokcetUtils, Context context, String type,
                                       String orderId, String orderMoney, String mark, String channelKey) {
        sendOrderServer(mainToolSokcetUtils, context, type, orderId, orderMoney, mark, channelKey,"");

    }
    public static void sendOrderServer(MainToolSokcetUtils mainToolSokcetUtils, Context context, String type,
                                       String orderId, String orderMoney, String mark, String channelKey,String fromuserid) {
        LogUtils.setConsoleLogger(context, "发送：当前订单参数：" + "  类型：" + type + "  订单号：" + orderId + "  金额" + orderMoney + "  备注：" + mark);
        try {
            JSONObject jsonObj = new JSONObject();//pet对象，json形式
            if (SocketClient.payListOrderMap.get(mark) == null) {
                jsonObj.put("messageuuid", "" + (int) (Math.random() * 1000000));//消息id
            } else {
                jsonObj.put("messageuuid", SocketClient.payListOrderMap.get(mark));
            }

            jsonObj.put("from_u_id", fromuserid);//付款方得userid

            jsonObj.put("dt", "" + System.currentTimeMillis());
            jsonObj.put("no", orderId);
            jsonObj.put("money", orderMoney.replace("￥", ""));
            jsonObj.put("key", channelKey);
            jsonObj.put("mark", mark);
            jsonObj.put("phoneId", getPesudoUniqueID());//s设备id
            jsonObj.put("merchant_id", SPUtils.getInstance().getInt(BaseParam.MERCHANTSID, 0));//码商id

            sendMainMessage(mainToolSokcetUtils, context, jsonObj, "notifyurl");


            String pw = SPUtils.getInstance().getString(BaseParam.TRANSFERPW);
            System.out.println("定额转账1");
            if (!TextUtils.isEmpty(pw) && BaseParam.isStartAdvaced == true && BaseApplication.isStart) {
                System.out.println("定额转账2");
                int tempType = SPUtils.getInstance().getInt(BaseParam.TRANSFERMODETYPE, 0);
                System.out.println("定额转账3");
                if (tempType == 1) {
                    //限额触发转账，所以需要计算收入的钱，转出全部
                    System.out.println("定额转账4");
                    if (type.equals(UniformString.ALIPAY) ||
                            type.equals(UniformString.ALIPAYCOLE) ||
                            type.equals(UniformString.ALIPAYRED)) {
                        System.out.println("定额转账5");
                        BaseParam.nowBlanceAlipay = BaseParam.nowBlanceAlipay + Float.parseFloat(orderMoney.replace("￥", ""));
                        String tempAmount = SPUtils.getInstance().getString(BaseParam.TRANSFERAMOUNT, "0");
                        System.out.println("定额转账6=" + BaseParam.nowBlanceAlipay + "<>" + Float.parseFloat(tempAmount));
                        if (BaseParam.nowBlanceAlipay >= Float.parseFloat(tempAmount)) {
                            //触发 转账，
                            System.out.println("定额转账7");
                            getAlipayTransferOrder(context, "" + (int) (Math.random() * 1000000) + "");
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 发送二维码
     * **上传二维码**
     * {"params":{"payurl":"https:\/\/qr.alipay.com\/fkx00013suzjxkgs589856s95?t=1545645515621","mark":"15|2247","money":"1"},"type":"uploadQrCode"}
     *
     * @param type//类型（alipay支付宝，wechat微信）
     * @param money//二维码金额
     * @param mark//二维码备注
     * @param payurl//二维码链接
     */
    public static void sendQrServer(MainToolSokcetUtils mainToolSokcetUtils, Context context, String type, String money, String mark, String payurl) {
        LogUtils.setConsoleLogger(context, "发送：当前二维码参数：" + "  类型：" + type + "  金额" + money + "  备注：" + mark + "  二维码链接：" + payurl);

        try {
            JSONObject jsonObj = new JSONObject();//pet对象，json形式
            if (SocketClient.payListOrderMap.get(mark) == null) {
                jsonObj.put("messageuuid", "" + (int) (Math.random() * 1000000));//消息id
            } else {
                jsonObj.put("messageuuid", SocketClient.payListOrderMap.get(mark));
            }
            jsonObj.put("merchant_id", SPUtils.getInstance().getInt(BaseParam.MERCHANTSID, 0));//码商id
            jsonObj.put("payurl", payurl);//实时生成二维码
            jsonObj.put("mark", mark);//备注
            jsonObj.put("money", money);//金额

            sendMainMessage(mainToolSokcetUtils, context, jsonObj, "uploadQrCode");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //统一发送参数回主进程
    public static void sendMainMessage(MainToolSokcetUtils mainToolSokcetUtils, Context context,
                                       JSONObject jsonObj, String type) {
        //发送到主页
        try {
            JSONObject object = new JSONObject();//创建一个总的对象，这个对象对整个json串
            object.put("params", jsonObj);//向总对象里面添加包含pet的数组
            object.put("type", type);
            if (mainToolSokcetUtils != null) {
                mainToolSokcetUtils.sendSocket(object.toString());
                LogToFile.e("socketSend" + type, object.toString());
                LogUtils.sendLogger("发送socket日志完成:type=" + type + "  json=" + object.toString());
            } else {
                LogUtils.sendLogger("发送socket日志null:type=" + type + "  json=" + object.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogUtils.sendLogger("发送socket日志错误:type=" + type + "  error=" + e.toString());
        }
    }


    /**
     * 发送收款订单号
     *
     * @param mainToolSokcetUtils
     * @param context
     * @param mark
     * @param userid
     * @param money
     * @param alipayNo
     * @param ali_key
     * @param order_type
     */
    public static void sendAlipayReceiptNo(MainToolSokcetUtils mainToolSokcetUtils, Context context, String mark,
                                           String userid, String money, String alipayNo, String ali_key, String order_type, String messageError) {
        try {
            JSONObject jsonObj = new JSONObject();//pet对象，json形式
            jsonObj.put("messageuuid", "" + "" + (int) (Math.random() * 1000000));//向pet对象里面添加值
            jsonObj.put("dt", "" + "" + System.currentTimeMillis());

            jsonObj.put("mark", "" + mark);
            jsonObj.put("user_id", userid);
            jsonObj.put("money", money);//
            jsonObj.put("alipayNo", alipayNo);//
            jsonObj.put("key_id", ali_key);//
            jsonObj.put("errMsg", messageError);//
            jsonObj.put("order_type", order_type);
            jsonObj.put("merchant_id", SPUtils.getInstance().getInt(BaseParam.MERCHANTSID, 0));//码商id
            sendMainMessage(mainToolSokcetUtils, context, jsonObj, "getTransferNo");
        } catch (JSONException e) {
            e.printStackTrace();
            LogUtils.sendLogger("发送支付宝订单号socket日志错误:type=" + order_type + "  error=" + e.toString());
        }

    }


    public static String getPesudoUniqueID() {
        String m_szDevIDShort = "35" + //we make this look like a valid IMEI
                Build.BOARD.length() % 10 +
                Build.BRAND.length() % 10 +
                Build.CPU_ABI.length() % 10 +
                Build.DEVICE.length() % 10 +
                Build.DISPLAY.length() % 10 +
                Build.HOST.length() % 10 +
                Build.ID.length() % 10 +
                Build.MANUFACTURER.length() % 10 +
                Build.MODEL.length() % 10 +
                Build.PRODUCT.length() % 10 +
                Build.TAGS.length() % 10 +
                Build.TYPE.length() % 10 +
                Build.USER.length() % 10; //13 digits
        System.out.println("当前的唯一设备id" + m_szDevIDShort);
        return m_szDevIDShort;
    }

}
