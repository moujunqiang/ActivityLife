package com.aa.android_public.hook;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.UniformString;

import org.json.JSONObject;

import java.lang.reflect.Field;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;

/**
 * 支付宝查余额和查UserId和保活Hook
 */
public class AlipayBalanceLiveIdHook {

    private static XC_MethodHook.MethodHookParam param1 = null;
    private boolean isGetBanlance = true;
    private boolean isSetMoney = false;
    private float dmoney = 0;
    public static String type = "";
    public static String remark = "";

    private boolean isRegistered = false;

//    private boolean isRegisteredYue = false;
    public AlipayBalanceLiveIdHook() {
        isRegistered = false;
//        isRegisteredYue = false;
    }

    public void hookActivityCreateFinish(final ClassLoader classLoader, final Context context) {
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(final MethodHookParam param1) throws Throwable {
                    super.afterHookedMethod(param1);
                    if (isRegistered == false) {
                        isRegistered = true;
                        setRegistered(classLoader, context);
                    }
                }
            });

        } catch (Error | Exception e) {
            Log.e("test临时", "hookTFAccount error:" + e.getMessage());
        }
    }


    public void setRegistered(final ClassLoader classLoader, final Context context) {
        //保活com.alipay.mobile.about.ui.AboutMainActivity_
        XposedHelpers.findAndHookMethod("com.alipay.mobile.about.ui.AboutMainActivity_", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                LogUtils.setConsoleLogger(context, "支付宝保活---2finish");
                Intent intent = ((Activity) param.thisObject).getIntent();
                String isrun = intent.getStringExtra("isrun");
                if (isrun == null) {

                } else {
                    Intent broadCastIntent = new Intent();
                    broadCastIntent.setAction(UniformString.LIVE_HOME_ACTION_START);
                    context.sendBroadcast(broadCastIntent);
                    XposedHelpers.callMethod(param.thisObject, "finish", new Object[0]);
                }

            }
        });
        //com.alipay.mobile.payee.ui=======PayeeQRActivity
//            //查询当前支付宝UserIdcom.alipay.mobile.payee.ui.PayeeQRActivity
        XposedHelpers.findAndHookMethod("com.alipay.mobile.payee.ui.PayeeQRActivity", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                Intent intent = ((Activity) param.thisObject).getIntent();
                String isrun = intent.getStringExtra("isrun");
                String messageuuid = intent.getStringExtra("messageuuid");
                if (isrun == null) {
                } else {
                    System.out.println("开始进入userid");
                    Field moneyField = XposedHelpers.findField(param.thisObject.getClass(), "f");
                    String userid = (String) moneyField.get(param.thisObject);

                    if (userid == null) {
                        userid = "";
                    }
                    System.out.println("开始进入userid" + userid);
                    LogUtils.setConsoleLogger(context, "支付宝查询UserId---2当前UserId:" + userid);
                    Intent broadCastIntent = new Intent();
                    broadCastIntent.putExtra("userid", userid);
                    broadCastIntent.putExtra("messageuuid", messageuuid);
                    broadCastIntent.setAction(UniformString.CHECK_HOME_ACTION_USERID);
                    context.sendBroadcast(broadCastIntent);

                    XposedHelpers.callMethod(param.thisObject, "finish", new Object[0]);
                }
            }
        });
////
////            //查询余额com.alipay.mobile.withdraw.ui.WithdrawActivity_
//            XposedHelpers.findAndHookMethod("com.alipay.mobile.withdraw.ui.WithdrawActivity_", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
//                @Override
//                protected void afterHookedMethod(final MethodHookParam param) throws Throwable {
//                    LogUtils.setConsoleLogger(context, "余额查询---2");
//                    param1 = param;
//                    Intent intent = ((Activity) param.thisObject).getIntent();
//                    String isrun = intent.getStringExtra("isrun");
//                    final String remark = intent.getStringExtra("remark");
//                    if (isrun == null) {
//
//                    } else {
//
//                        isGetBanlance = false;
//                        XposedHelpers.findAndHookMethod(TextView.class, "setText", CharSequence.class, TextView.BufferType.class, boolean.class, int.class, new XC_MethodHook() {
//                            @Override
//                            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
//                            }
//
//
//                            @Override
//                            protected void afterHookedMethod(MethodHookParam param) {
//
//                                LogUtils.sendLogger("余额查询：" + "获得数据" + param.args[0] + "" + param.thisObject.getClass().getSimpleName());
//
//                                String temp = param.args[0] + param.thisObject.getClass().getSimpleName() + "";
//
//                                if (temp.contains("可用余额") && temp.contains("元APTextView") && isGetBanlance == false) {
//                                    //取出字符串中的钱
//                                    isGetBanlance = true;
//                                    isSetMoney = true;
//                                    dmoney = StringUtils.getDoubleValue(temp);
//                                    LogUtils.setConsoleLogger(context, "余额查询---3：" + "获取到查询类型" + type);
//                                    if (type == null) {
//                                        //啥也不干
//                                    } else if (type.equals("balance")) {
//                                        //取出字符串中的钱。/并返回客户端界面
//                                        float d = StringUtils.getDoubleValue(temp);
//                                        LogUtils.setConsoleLogger(context, "余额查询---4：" + "获取到支付宝余额" + d);
//                                        Intent broadCastIntent = new Intent();
//                                        broadCastIntent.putExtra("balance", d + "");
//                                        broadCastIntent.putExtra("type", UniformString.ALIPAY);
//                                        broadCastIntent.putExtra("remark", remark);
//                                        broadCastIntent.setAction(UniformString.BALANCERECEIVED_ACTION);
//                                        context.sendBroadcast(broadCastIntent);
//                                        XposedHelpers.callMethod(param1.thisObject, "finish", new Object[0]);
//                                    }
//                                }
//                            }
//
//                        });
//                    }
//
//                }
//            });
//        com.alipay.android.app.birdnest.ui=======BNTplActivity
        //这里查余额38版本废弃
//        XposedHelpers.findAndHookMethod("com.alipay.android.app.birdnest.ui.BNTplActivity", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                param1 = param;
//                if (isRegisteredYue == false) {
//                    isRegisteredYue = true;
//                    setBntplActivityValue(classLoader,context);
//                }
//            }
//        });



    }
//    public void setBntplActivityValue(final ClassLoader classLoader, final Context context){
//        XposedHelpers.findAndHookMethod("com.flybird.FBDocument", classLoader, "setProp", String.class, String.class, new XC_MethodHook() {
//            @Override
//            protected void afterHookedMethod(final MethodHookParam param) throws Throwable {
//                LogUtils.setConsoleLogger(context, "余额查询---3");
//                if (type.equals("balance")) {
//                    type = "";
//                    if ((param.args[0].toString().equals("userPreferences")) && (Integer.parseInt(param.getResult().toString()) == 1)) {
//                        Object localObject = param.args[1].toString();
//                        localObject = new JSONObject((String) localObject).get("data");
//                        if (localObject != null) {
//                            float f1 = Float.parseFloat(new JSONObject(localObject.toString()).getString("availableAmount"));
//                            System.out.println("当前余额是" + f1);
//                            //取出字符串中的钱。/并返回客户端界面
//                            float d = f1;
//                            LogUtils.setConsoleLogger(context, "余额查询---4：" + "获取到支付宝余额" + d);
//                            Intent broadCastIntent = new Intent();
//                            broadCastIntent.putExtra("balance", d + "");
//                            broadCastIntent.putExtra("type", UniformString.ALIPAY);
//                            broadCastIntent.putExtra("remark", remark);
//                            broadCastIntent.setAction(UniformString.BALANCERECEIVED_ACTION);
//                            context.sendBroadcast(broadCastIntent);
//                            XposedHelpers.callMethod(param1.thisObject, "finish", new Object[0]);
//                        }
//                    }
//                } else {
//                    //啥也不干
//                }
//            }
//        });
//    }
}
