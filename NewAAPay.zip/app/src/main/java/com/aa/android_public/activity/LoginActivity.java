package com.aa.android_public.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.aa.android_public.BuildConfig;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.aa.android_public.R;
import com.support.fastthink.BaseActivity;
import com.support.fastthink.BaseParam;
import com.support.fastthink.entity.LoginBean;
import com.support.fastthink.network.OkHttpManager;
import com.support.fastthink.network.Param;
import com.support.fastthink.network.PathConstant;
import com.support.fastthink.utils.SPUtils;
import com.support.fastthink.utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends BaseActivity implements View.OnClickListener {
    private EditText etAccount;
    private EditText etPassword;
    private TextView tvSubmit;
    private String account, password;

    private LinearLayout llMerchant,llAuthorization;
    private EditText etAuthorization;
    private TextView tvauthorization,tvMerchant;
    private String authorizationCode;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        if (SPUtils.getInstance().getInt(BaseParam.LOGINTYPE)==-1){
            SPUtils.getInstance().put(BaseParam.LOGINTYPE, 1);//默认码商
        }
        initView();
    }

    private void initView() {
        Utils.transparentBar(this);
        etAccount = findViewById(R.id.et_login_account);
        etPassword = findViewById(R.id.et_login_password);
        tvSubmit = findViewById(R.id.tv_login_submit);
        tvSubmit.setOnClickListener(this);

        llAuthorization=findViewById(R.id.ll_authorization_login);
        llMerchant=findViewById(R.id.ll_merchant_login);
        etAuthorization=findViewById(R.id.et_login_authorization);
        tvauthorization=findViewById(R.id.tv_change_authorization);
        tvauthorization.setOnClickListener(this);
        tvMerchant=findViewById(R.id.tv_change_merchant);
        tvMerchant.setOnClickListener(this);


        int login_type=SPUtils.getInstance().getInt(BaseParam.LOGINTYPE);

        if (login_type==2){//授权码
            llMerchant.setVisibility(View.GONE);
            llAuthorization.setVisibility(View.VISIBLE);
        }else {
            //码商
            llMerchant.setVisibility(View.VISIBLE);
            llAuthorization.setVisibility(View.GONE);
        }
    }

    private void getText() {
        account = etAccount.getText().toString();
        password = etPassword.getText().toString();
        authorizationCode=etAuthorization.getText().toString();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_login_submit:
                getText();
                int submit_type=SPUtils.getInstance().getInt(BaseParam.LOGINTYPE);
                if (submit_type==2){
                    if (!TextUtils.isEmpty(authorizationCode)){
                        submitLogin(submit_type,"", "",authorizationCode);
                    } else {
                        showToast("请输入授权码！");
                    }
                }else {
                    if (!TextUtils.isEmpty(account) && !TextUtils.isEmpty(password)) {
                        submitLogin(submit_type,account, password,"");
                    } else {
                        showToast("请输入账号或密码！");
                    }
                }
                break;
            case R.id.tv_change_authorization://切换至授权码方式
                SPUtils.getInstance().put(BaseParam.LOGINTYPE, 2);//授权码
                llMerchant.setVisibility(View.GONE);
                llAuthorization.setVisibility(View.VISIBLE);
                break;
            case R.id.tv_change_merchant://切换至码商登录方式
                SPUtils.getInstance().put(BaseParam.LOGINTYPE, 1);//码商
                llMerchant.setVisibility(View.VISIBLE);
                llAuthorization.setVisibility(View.GONE);
                break;
            default:
                break;
        }
    }

    public void submitLogin(int submit_type,String member_id, String pwd,String authorization_code) {
        String submit_url="";
        showProgress("正在登录");

        if (submit_type==2){
            submit_url=PathConstant.URL_AUTHOR;
        }else {
            submit_url=PathConstant.URL_LOGIN;
        }

        List<Param> params = new ArrayList<Param>();

        if (submit_type==2){
            params.add(new Param("value", authorization_code));
        }else {
            params.add(new Param("name", member_id));
            params.add(new Param("pass", pwd));
        }

        OkHttpManager.getInstance().post(params, submit_url, new OkHttpManager.HttpCallBack() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                dismissProgress();
//                {"code":1,"msg":"登录成功","data":{"id":1,"name":"admin","phone":"15626277799","version":"1.1.1","money":"8614.170"}}
                LoginBean loginEntity = null;
                try {
                    loginEntity = JSON.parseObject(jsonObject.toString(), LoginBean.class);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (loginEntity!=null&&loginEntity.getCode() == 1) {
                    SPUtils.getInstance().put(BaseParam.MERCHANTSID, loginEntity.getData().getId());
                    SPUtils.getInstance().put(BaseParam.NOWACCOUNT, loginEntity.getData().getName());
                    SPUtils.getInstance().put(BaseParam.MERCHANTSVERSION, loginEntity.getData().getVersion());
                    SPUtils.getInstance().put(BaseParam.NOWAMOUNT, loginEntity.getData().getMoney());
                    SPUtils.getInstance().put(BaseParam.LOGINIP, loginEntity.getData().getIp()+"");
                    SPUtils.getInstance().put(BaseParam.CHANNELSID, loginEntity.getData().getChannels_id()+"");
                    SPUtils.getInstance().put(BaseParam.CHANNELSKEY, loginEntity.getData().getKey()+"");
                    showToast("登录成功！！！");
                    startIntent(MainActivity.class);
                    finish();
                } else {
                    if (loginEntity != null && loginEntity.getMsg() != null) {
                        showDialog(loginEntity.getMsg());
                    } else if (loginEntity != null) {
                        showDialog(loginEntity.getCode() + "");
                    } else {
                        showDialog("登录失败");
                    }
                }
            }

            @Override
            public void onFailure(String errorMsg) {
                dismissProgress();
                showDialog(errorMsg);
            }
        });
    }
}
