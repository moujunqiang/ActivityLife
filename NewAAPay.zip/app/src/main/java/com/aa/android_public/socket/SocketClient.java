package com.aa.android_public.socket;

import com.support.fastthink.BaseParam;
import com.support.fastthink.utils.LogToFile;
import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.SPUtils;
import com.support.fastthink.utils.Utils;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

public class SocketClient extends WebSocketClient {

    //用于过滤多余的请求，同一个请求id只接收一次，多余的过滤
    //请求生成二维码
    private static Vector<String> payListOrder = new Vector<String>();
    public static Map<String, String> payListOrderMap = new HashMap<>();
    //下发指令获取支付宝userid
    private static Vector<String> payListUseridAlipay = new Vector<String>();
    //监听
    private SocketListener socketListener;

    //main函数连接测试
    public static void main(String[] args) throws URISyntaxException, JSONException {
//        WebSocketClient client = new SocketClient(new URI(BaseParam.base_socketurl));
//        client.connect();
//        DecimalFormat df3 = new DecimalFormat("###0.00");
//
//        System.out.println(df3.format(Float.parseFloat("100")));
        ;
        JSONObject jsonObj = new JSONObject("{\"mark\":\"1|111dd\",\"money\":\"0.01\",\"key_id\":\"2088332230634660\",\"type\":\"paytype\"，“messageuuid”，“123456”，\"channle_type\":\"alipay\"}");
    }

    //构造函数，
    public SocketClient(URI serverUri) {
        super(serverUri);
        payListOrder.clear();
        payListOrderMap.clear();
        payListUseridAlipay.clear();
        System.out.println("初始化通道地址：" + serverUri.toString());
    }

    //----------------------------------------------基础参数设置---------------------------------
    //设置监听
    public void setSocketListener(SocketListener socketListener) {
        this.socketListener = socketListener;
    }
    //----------------------------------------------socket框架生命周期---------------------------------

    @Override
    public void onOpen(ServerHandshake handshakedata) {
        System.out.println("通道已打开");
        if (socketListener != null) {
            socketListener.onOpen();
        }
    }

    @Override
    public void onMessage(String message) {
        try {
            System.out.println("当前接收消息message1= " + Utils.isJson(message) + "   " + message);


            //解析指令，然后请求http
            if (Utils.isJson(message)) {
                //解析type
                JSONObject jsonObj = new JSONObject(message);
                String type = jsonObj.optString("type", "");


                if (type.equals("login")) {
                    //心跳不记录，
                } else {
                    //记录除心跳的所有日志
                    LogToFile.e("socketAllMessage", message);
                }

                if (type.equals("paytype")) {
                    //请求生成二维码
                    //先去重
                   /*{"mark":"1|111dd","money":"0.01","key_id":"2088332230634660","type":"paytype"，“messageuuid”，“123456”，"channle_type":"alipay"}
                         "channle_type":"wechat"         "channle_type":"dingding"*/
                    String key_id = jsonObj.optString("key_id", "");
                    String mark = jsonObj.optString("mark", "");
                    String money = jsonObj.optString("money", "");
                    String messageid = jsonObj.optString("messageuuid", "");
                    String channle_type = jsonObj.optString("paytype", "");
                    if (payListOrder.contains(mark)) {
                        return;
                    } else {
                        LogToFile.e("socketPayTypeMessage", message);
                        payListOrder.add(mark);
                        System.out.println("请求生成二维码 " + key_id + "    " + mark + "   " + money);
                        if (socketListener != null) {
                            payListOrderMap.put(mark, messageid);
                            socketListener.getQrPayurl(channle_type,key_id, messageid, money, mark);
                        }
                    }
                } else if (type.equals("alipayuserid")) {
                    //下发获取userid

                    //{type: "alipayuserid", messageuuid: 18, key_id: "520078259@qq.com"}
                    String key_id = jsonObj.optString("key_id", "");
                    String messageid = jsonObj.optString("messageuuid", "");
                    if (payListUseridAlipay.contains(messageid)) {
                        return;
                    } else {
                        LogToFile.e("socketUseridMessage", message);
                        payListUseridAlipay.add(messageid);
                        if (socketListener != null) {
                            System.out.println("请求获取支付宝userid " + key_id + "    " + messageid);
                            socketListener.getAlipayUUid(key_id, messageid);
                        }
                    }
                } else if (type.equals("gatewaystatus")) {
                    //下发关闭通道，如果两个通道都关闭了，关闭socket,
//                    {type: "gatewaystatus", messageuuid: 388588956, key_id: "567saaa", status: 1}
                    String key_id = jsonObj.optString("key_id", "");
                    LogToFile.e("socketGateWayMessage", message);
                    //关闭这个设备，
                    if (socketListener != null) {
                        System.out.println("进入执行1=" + key_id);
                        socketListener.onCloseChannel(key_id);
                    }
                } else if (type.equals("accountorderdata")) {
                    /*{"type":"accountorderdata","messageuuid":665121027,"key_id":"121aa1","paytype":"alipay","nowAllMoney":0,"nowAllMenber":0,"quota":0}
                     * /**{"type":"accountorderdata","messageuuid":253976456,"key_id":"wwwwww","paytype":"alipay","nowAllMoney":100,"nowAllMenber":200,"quota":"5000.000"}
                     * 下发当前通道的订单状态
                     * @param $type               下发当前通道类型订单数量
                     * @param $key_id             通道的唯一字符串
                     * @param string $paytype     通道类型
                     * @param int $nowAllMoney    今日通道订单总额
                     * @param int $nowAllMenber   今日通道订单总笔数
                     * @param int $quota          通道限额
                     */
                    //下发当前通道信息，
                    LogToFile.e("socketAccountDataMessage", message);
                    DecimalFormat df3 = new DecimalFormat("###0.00");
                    String liushui = jsonObj.optString("nowAllMoney", "0");//
                    String bishu = jsonObj.optString("nowAllMenber", "0");
                    String xiane = jsonObj.optString("quota", "0");//
                    String key_id = jsonObj.optString("key_id", "0");
                    if (socketListener != null) {
                        socketListener.onMessageToMain(df3.format(Float.parseFloat(liushui)),
                                bishu,
                                df3.format(Float.parseFloat(xiane)),
                                key_id);
                    }
                } else if (type.equals("merchantsmoney")) {
                    //下发 当前的余额  {"type":"merchantsmoney","messageuuid":279246274,"money":100}
                    //{"type":"merchantsmoney","messageuuid":942052206,"money":"11111"}
                    String money = jsonObj.optString("money", "0");
                    DecimalFormat df3 = new DecimalFormat("###0.00");
                    LogToFile.e("socketAccountMoneyMessage", message);
                    if (socketListener != null) {
                        socketListener.onMessageToBlance(df3.format(Float.parseFloat(money)) + "");
                    }
                } else if (type.equals("login")) {
                    int code = jsonObj.optInt("code", 0);
                    if (code == 200) {
                        //查询网关，并显示
                        //支付宝类型， redstatus  红包  recstatus 主动收款 trastatus 个人转账
                        int alipaystatus = jsonObj.optInt("alipaystatus", 2);//实时码默认
                        int AlipayType = SPUtils.getInstance().getInt(BaseParam.NOWALIPAYMODE);
                        String loginIp = jsonObj.optString("ip");;//默认1.1.1.1

                            System.out.println("ip能匹配上");

                            LogUtils.sendLogger("当前APP支付宝类型" + AlipayType);

                            if (AlipayType == 1) {
                                alipaystatus = jsonObj.optInt("alipaystatus", 2);
                                LogUtils.sendLogger("1当前支付宝类型" + AlipayType);
                            } else if (AlipayType == 2) {
                                alipaystatus = jsonObj.optInt("redstatus", 2);
                                LogUtils.sendLogger("2当前支付宝类型" + AlipayType);
                            } else if (AlipayType == 3) {
                                alipaystatus = jsonObj.optInt("recstatus", 2);
                                LogUtils.sendLogger("3当前支付宝类型" + AlipayType);
                            } else if (AlipayType == 4) {
                                alipaystatus = jsonObj.optInt("trastatus", 2);
                                LogUtils.sendLogger("4当前支付宝类型" + AlipayType);
                            }

                            LogUtils.sendLogger("最终后台返回的支付宝类型" + alipaystatus);

                            //微信类型
                            int wuchatstatus = jsonObj.optInt("wuchatstatus", 2);
                            //隐藏错误信息
                            if (socketListener != null) {
                                System.out.println("进入执行1=" + alipaystatus + wuchatstatus);
                                socketListener.onMessageGetWay(alipaystatus, wuchatstatus);
                                socketListener.onMessageError("", false);
                                System.out.println("回调ip=");
                                socketListener.onMessageIp(loginIp);
                            }

                    } else if (code == 403) {
                        //显示错误信息
                        String msg = jsonObj.optString("msg", "");
                        if (socketListener != null) {
                            System.out.println("进入执行2=" + msg);
                            socketListener.onMessageError(msg, true);
                        }
                    }else if (code == 5000) {
                        //显示ip错误信息
                        String msg = jsonObj.optString("msg", "");
                        if (socketListener != null) {
                            System.out.println("显示错误信息");
                            socketListener.onMessageIpError(msg);
                        }
                    } else {
                        socketListener.onMessageError(message, true);
                        socketListener.onMessageLoginError(message, true);

                    }
                } else if (type.equals("getTransferNo")) {
                    LogToFile.e("socketGetNoMessage", message);
//                        下发获取订单
//                        {"type":"getTransferNo","mark":12,"user_id":"","money":1,"paytype":"",key_id,"}
                    String mark = jsonObj.optString("mark", "").trim();
                    String user_id = jsonObj.optString("user_id", "").trim();
                    String money = jsonObj.optString("money", "").trim();
                    String key_id = jsonObj.optString("key_id", "").trim();
                    if (user_id.equals("null") || mark.equals("null")
                            || money.equals("null") || key_id.equals("null")) {
                        LogUtils.sendLogger("获取订单下发指令：" + "\n mark:" + mark + "  \n user_id:" + user_id + " \n money：" + money + "  \n key_id：" + key_id);
                    }

                    System.out.println("1当前通道的指令" + "mark:" + mark + "  user_id:" + user_id + "  money：" + money + "  key_id：" + key_id);
                    if (payListOrder.contains(mark)) {
                        return;
                    } else {

                        payListOrder.add(mark);
                        if (socketListener != null) {
                            socketListener.onMainAlipayReceived(mark, user_id, money, key_id);
                        }
                    }


                }

                //心跳返回值，网关和是否占用显示出来
                //            {"type":"login","code":200,"msg":"\u767b\u9646\u6210\u529f","alipaystatus":2,"wuchatstatus":2}
//            {"type":"login","code":403,"msg":"\u8be5\u652f\u4ed8\u5b9d\u5df2\u5728\u7ebf\uff0c\u8bf7\u6362\u5176\u4ed6\u901a\u9053"}
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("当前接收消息出错= " + e.toString());
        }
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        if (socketListener != null) {
            socketListener.onClose();
        }
        System.out.println("Connection closed by " + (remote ? "remote peer" : "us"));
        System.out.println("picher_log" + "通道关闭");

    }

    @Override
    public void onError(Exception ex) {
        ex.printStackTrace();
        if (socketListener != null) {
            socketListener.onError(ex);
        }
        System.out.println("连接错误");

    }
}
