package com.support.fastthink;

import android.app.Application;
import android.content.Context;

import com.support.fastthink.network.OkHttpManager;
import com.support.fastthink.ui.PercentageScreenHelper;
import com.support.fastthink.utils.LogToFile;
import com.support.fastthink.utils.Utils;
import com.tencent.bugly.crashreport.CrashReport;

public class BaseApplication extends Application {

    public static boolean isStart = false;//是否已经启动，状态，默认未启动

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        new PercentageScreenHelper(this, 375).activate();//屏幕适配
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Utils.init(this);
        LogToFile.init(this);//日志
        OkHttpManager.init(getApplicationContext());
        CrashReport.initCrashReport(getApplicationContext(), "ca5588faae", false);//bugly
    }
}
