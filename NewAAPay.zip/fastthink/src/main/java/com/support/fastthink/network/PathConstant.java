package com.support.fastthink.network;

import com.support.fastthink.BaseParam;

public class PathConstant {
    public static final String HOST = BaseParam.base_url;//域名/ip
    public static final String URL_LOGIN = HOST + BaseParam.login_url;//，码商登录
    public static final String URL_AUTHOR = HOST + BaseParam.authorization_url;//授权登录
    public static final String URL_ACCOUNT = HOST + BaseParam.account_url;//获取账号列表
    public static final String URL_BALANCE = HOST + BaseParam.balance_url;//获取余额列表
    public static final String URL_GETAWAY = HOST + BaseParam.startNet;//打开关闭网络通道
}
