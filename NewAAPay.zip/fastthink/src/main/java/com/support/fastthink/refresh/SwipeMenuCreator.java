package com.support.fastthink.refresh;

public interface SwipeMenuCreator {

    void create(SwipeMenu menu);
}
