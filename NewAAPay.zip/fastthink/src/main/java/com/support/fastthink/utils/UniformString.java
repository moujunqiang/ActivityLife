package com.support.fastthink.utils;

/**
 * 通用字段
 */
public class UniformString {

    public static String WECHAT = "wechat";
    public static String ALIPAY = "alipay";
    public static String ALIPAYRED = "alipayred";
    public static String ALIPAYCOLE = "alipaycole";

    public static int INTENTTWECHAT = 10001;
    public static int INTENTTALIPAY = 10002;
    /**
     * 日志
     */
    //日志控制台
    public static String MAINMSGTAG = "main_msg";
    public static String LOGGERTYPE = "logger_type";
    public static String LOGGERCOLLECION = "logger_type_collection";
    public static String LOGGERPROGRAM = "logger_type_program";
    public static String MAINMSGRECEIVER = "com.support.main.msgReceiver";
    //日志打印筛选字段
    public static String UNIFIEDPRINTING = "统一日志";


    /**
     * 微信支付宝开始调用
     */
    //微信
    public static String WECHATSTART_ACTION = "com.support.wechat.start";
    //支付宝
    public static String ALIPAYSTART_ACTION = "com.support.alipay.start";


    /**
     * 当前订单查询
     */
    //微信/支付宝个人收款订单
    public static String BILLRECEIVED_ACTION = "com.support.main.billreceived";
    //支付宝商家收款订单
    public static String TRADENORECEIVED_ACTION = "com.support.alipay.tradenoreceived";


    /**
     * 固码设置二维码
     */
    public static String QRCODERECEIVED_ACTION = "com.support.alipay.qrcodereceived";


    /**
     * 保活和查余额
     */
    //支付宝，微信保活
    public static String LIVE_HOME_ACTION_START = "com.support.alipay.liveapp";
    //支付宝查余额。38版本暂时废弃，如果需要查余额再使用
    public static String BALANCERECEIVED_ACTION = "com.support.alipay.balacnereceived";
    //查询支付宝userid
    public static String CHECK_HOME_ACTION_USERID = "com.support.alipay.checkuserid";
    //支付宝转账
    public static String ALIPAY_TRANFER = "com.support.alipay.alipaytranfer";
    //支付宝转账
    public static String ALIPAY_GET_TRANFER = "com.support.alipay.alipaygettranfer";
    //支付宝转账消息页返回
    public static String ALIPAY_BACK_TRANFER = "com.support.alipay.alipaygettranferback";
    public static String ALIPAY_BACK_TRANFER1 = "com.support.alipay.alipaygettranferback1";

    /**
     * 活跃状态
     */
    //类型
    public static String ACTIVETYPE = "active_type";
    //活跃检测
    public static String ACTIVE_HOME_ACTION = "active.home.action.check";
    //活跃检测的类型，app包括支付宝微信）
    public static String ACTIVEALL = "alipay_wechat_activity_check";
    //活跃检测的类型，socket在线检测
    public static String ACTIVESOCKET = "active_socket";
    //活跃检测的类型，socket心跳发送
    public static String ACTIVESOCKETHEART = "active_socket_heart";
    //活跃检测的类型，socket心跳发送
    public static String ACTIVEHTTPHEART = "active_http_heart";
    //支付宝保活
    public static String ACTIVEALIPAYISRUN = "active_alipay_isrun";
    //支付宝异常的时候关闭
    public static String ACTIVEALIPAYERRORCLOSE = "active_alipay_error_close";


    /**
     * 支付宝新模式
     */
    //红包模式
    public static String ALIPAYUID_ACTION = "com.support.alipay.useridadd";
    //红包模式
    public static String REDENVELOPE_ACTION = "com.support.alipay.envelope";
    //收款模式
    public static String ALIPAYRECEIPT_ACTION = "com.support.alipay.receipt";
    //收款模式类型
    public static String RECEIPTTYPE = "receipt_type";
    //支付宝收款订单
    public static String RECEIPT_ORDER = "com.support.receipt.order";
    //删除支付宝好友
    public static String DELETEALIPAYUID = "deleteUid";



    //收款模式,支付宝转账个人，已经修改为可以抓取uid,广播，
    public static String ZHUANZHANG_UID = "zhuanzhang_type_uid";

}
