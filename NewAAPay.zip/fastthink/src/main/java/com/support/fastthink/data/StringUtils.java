package com.support.fastthink.data;

public class StringUtils {

    /**
     * 拆解字符串
     *
     * @param text
     * @param begin
     * @param end
     * @return
     */
    public static String getTextCenter(String text, String begin, String end) {
        try {
            int b = text.indexOf(begin) + begin.length();
            int e = text.indexOf(end, b);
            return text.substring(b, e);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return "error";
        }
    }

    /**
     * 解析字符串获得双精度型数值，
     *
     * @param str
     * @return
     */
    public static float getDoubleValue(String str) {
        float d = 0;

        if (str != null && str.length() != 0) {
            StringBuffer bf = new StringBuffer();

            char[] chars = str.toCharArray();
            for (int i = 0; i < chars.length; i++) {
                char c = chars[i];
                if (c >= '0' && c <= '9') {
                    bf.append(c);
                } else if (c == '.') {
                    if (bf.length() == 0) {
                        continue;
                    } else if (bf.indexOf(".") != -1) {
                        break;
                    } else {
                        bf.append(c);
                    }
                } else {
                    if (bf.length() != 0) {
                        break;
                    }
                }
            }
            try {
                d = Float.parseFloat(bf.toString());
            } catch (Exception e) {
            }
        }

        return d;
    }

}