package com.support.fastthink.utils;

import android.content.Context;
import android.content.Intent;

import de.robv.android.xposed.XposedBridge;

public class LogUtils {

    //收款日志---打印到主页控制台
    public static void setConsoleCollection(Context context, String Msg) {
        //编辑器日志
        //Log.i(UniformString.UNIFIEDPRINTING, Msg);
        //XP日志
        //XposedBridge.log(UniformString.UNIFIEDPRINTING+"："+Msg);

        //发送到主页
        Intent broadCastIntent = new Intent();
        broadCastIntent.putExtra(UniformString.MAINMSGTAG, Msg);
        broadCastIntent.putExtra(UniformString.LOGGERTYPE, UniformString.LOGGERCOLLECION);
        broadCastIntent.setAction(UniformString.MAINMSGRECEIVER);
        context.sendBroadcast(broadCastIntent);
    }

    //程序日志---打印到主页控制台
    public static void sendConsole(Context context, String Msg) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.putExtra(UniformString.MAINMSGTAG, Msg);
        broadCastIntent.putExtra(UniformString.LOGGERTYPE, UniformString.LOGGERPROGRAM);
        broadCastIntent.setAction(UniformString.MAINMSGRECEIVER);
        context.sendBroadcast(broadCastIntent);
    }


    //程序日志---打印到主页控制台和编辑器Logcat
    public static void setConsoleLogger(Context context, String Msg) {
        //编辑器日志
        //Log.i(UniformString.UNIFIEDPRINTING, Msg);
        //XP日志
        XposedBridge.log(UniformString.UNIFIEDPRINTING + "：" + Msg);
        //发送到主页
        Intent broadCastIntent = new Intent();
        broadCastIntent.putExtra(UniformString.MAINMSGTAG, Msg);
        broadCastIntent.putExtra(UniformString.LOGGERTYPE, UniformString.LOGGERPROGRAM);
        broadCastIntent.setAction(UniformString.MAINMSGRECEIVER);
        context.sendBroadcast(broadCastIntent);
    }


    //打印到编辑器Logcat
    public static void sendLogger(String Msg) {
        //编辑器日志
        //Log.i(UniformString.UNIFIEDPRINTING, Msg);
        //XP日志
        XposedBridge.log(UniformString.UNIFIEDPRINTING + "：" + Msg);
    }

}
