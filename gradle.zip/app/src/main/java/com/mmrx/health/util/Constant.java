package com.mmrx.health.util;

/**
 * Created by mmrx on 2015/4/29.
 */
public class Constant {

    public static final String FRAGMENT_TAG = "fragmentTag";
    public static final String FRAGMENT_TAG_EAT = "toEat";
    public static final String FRAGMENT_TAG_SLEEP= "toSleep";
    public static final String FRAGMENT_TAG_DRUG = "toDrug";
    public static final String FRAGMENT_TAG_BUILD = "toBuild";

    public static final String BODY_BUILDING_BEAN_ID = "bodyBuildingBeanId";

    public static final int MESSAGE_UPDATE_BODY_FRAGMENT = 0x123456;
}
