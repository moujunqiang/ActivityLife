package com.tools.getway;

import java.util.List;

import com.tools.getway.utils.DBManager;
import com.tools.getway.utils.OrderBean;
import com.tools.getway.utils.PayHelperUtils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;


public class AlarmReceiver extends BroadcastReceiver{

	@Override
	public void onReceive(Context context, Intent intent) {
		try {
			DBManager dbManager=new DBManager(context);
			List<OrderBean> orderBeans=dbManager.FindAllOrders();
			for (OrderBean orderBean : orderBeans) {
				PayHelperUtils.notify(context, orderBean.getType(), orderBean.getNo(), orderBean.getMoney(), orderBean.getMark(), orderBean.getDt());
			}
			long currentTimeMillis=System.currentTimeMillis()/1000;
			long currentTimeMillis2=Long.parseLong(PayHelperUtils.getcurrentTimeMillis(context));
			long currentTimeMillis3=currentTimeMillis-currentTimeMillis2;
			if(currentTimeMillis3>60 && currentTimeMillis2!=0){
				PayHelperUtils.sendmsg(context, "轮询任务出现异常,重启中...");
				PayHelperUtils.startAlipayMonitor(context);
				PayHelperUtils.sendmsg(context, "轮询任务重启成功");
			}
		} catch (Exception e) {
			PayHelperUtils.sendmsg(context, "AlarmReceiver异常->>"+e.getMessage());
		}
	}

}
