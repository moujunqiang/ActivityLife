package com.tools.getway;

public interface WebsocketListener {
    public void onSuccessful();
    public void onFailure();

}
