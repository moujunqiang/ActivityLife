package com.example.newstest.Adapter;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.os.Handler;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.newstest.Beans.News;
import com.example.newstest.NewsContentActivity;
import com.example.newstest.R;
import com.example.newstest.Tasks.DownloadPicTask;

import java.util.HashMap;
import java.util.List;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.ViewHolder> {

    private List<News> mNewsList;
    private static final String TAG = "NewsAdapter";
    private onItemClick mOnItemClick;
    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            HashMap<String, Object> hashMap = (HashMap<String, Object>) msg.obj;
            ImageView imageView = (ImageView) hashMap.get("imageview");
            Drawable drawable = (Drawable) hashMap.get("drawable");
            imageView.setImageDrawable(drawable);
        }
    };

    public NewsAdapter(List<News> newsList) { mNewsList = newsList; }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull final ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_item, parent, false);
        final ViewHolder holder = new ViewHolder(view);
        holder.newsView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int position = holder.getAdapterPosition();
                News news = mNewsList.get(position);
                Log.d(TAG, "Date=" + news.getTime());
                Toast.makeText(view.getContext(), news.getTitle(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(parent.getContext(), NewsContentActivity.class);
                Bundle bundle = new Bundle();
                bundle.putParcelable("news", news);
                intent.putExtras(bundle);
                parent.getContext().startActivity(intent);
            }
        });
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        final News news = mNewsList.get(position);
        holder.newsTitle.setText(news.getTitle());
        ImageView imageView = holder.newsImage;
        DownloadPicTask task = new DownloadPicTask(imageView, handler);
        task.execute(news.getPic());
        //holder.newsImage.setImageDrawable(loadImageFromNetwork(news.getPic()));
        holder.item.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                mOnItemClick.onclick(position);

                return true;
            }
        });
    }

    @Override
    public int getItemCount() {
        return mNewsList.size();
    }

//    private Drawable loadImageFromNetwork(final String imageUrl) {
//        final Drawable[] drawable = {null};
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    // 可以在这里通过文件名来判断，是否本地有此图片
//                    Log.d(TAG, imageUrl);
//                    Log.d(TAG, "run in thread " + this.toString());
//                    drawable[0] = Drawable.createFromStream(new URL(imageUrl).openStream(), "image.jpg");
//                } catch (IOException e) {
//                    Log.d("test", e.getMessage());
//                }
//                if (drawable[0] == null) {
//                    Log.d(TAG, "null drawable");
//                } else {
//                    Log.d(TAG, "not null drawable");
//                }
//            }
//        }).start();
//        return drawable[0];
//    }

    public interface onItemClick {
        void onclick(int p);
    }

    public void setOnclick(onItemClick onItemClick) {
        this.mOnItemClick = onItemClick;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        View newsView;
        ImageView newsImage;
        TextView newsTitle;
        LinearLayout item;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            newsView = itemView;
            newsImage = itemView.findViewById(R.id.newsImage);
            newsTitle = itemView.findViewById(R.id.newsTitle);
            item = itemView.findViewById(R.id.item);
        }
    }
}
