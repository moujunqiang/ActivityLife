package com.example.newstest.Tasks;

import android.os.AsyncTask;

import com.example.newstest.Utils.HttpUtil;

public class GetNewsTask extends AsyncTask<String, Void, String> {

    @Override
    protected String doInBackground(String... strings) {
        return HttpUtil.HttpGet(strings[0]);
    }

    @Override
    protected void onPostExecute(String s) {
        listener.onFinish(s);
    }

    private GetNewListener listener;

    public void setListener(GetNewListener listener) {
        this.listener = listener;
    }

    public interface GetNewListener {
        void onFinish(String result);
    }


}
