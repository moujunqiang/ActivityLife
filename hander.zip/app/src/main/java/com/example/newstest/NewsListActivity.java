package com.example.newstest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.newstest.Adapter.NewsAdapter;
import com.example.newstest.Beans.News;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class NewsListActivity extends AppCompatActivity {

    private static final String TAG = "NewsListActivity";
    private List<News> newsList = new ArrayList<>();
    UserOpenHelper helper;
    SharedPreferences sp;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_list);
        helper = new UserOpenHelper(this);
        db = helper.getWritableDatabase();
        sp = getSharedPreferences("data", MODE_PRIVATE);

//        String sql = String.format("select _DATE,_HEAD,_MSG,_TITLE from res where _ID=%d;", sp.getInt("id", 0));
//        Cursor cursor = db.rawQuery(sql, null);
//        if (cursor != null && cursor.getCount() > 0) {
//            News a = new News();
//            while (cursor.moveToNext()){
//                a.setTime(new Date(cursor.getString(0)));
//                a.setContent(cursor.getString(1));
//                a.setPic(cursor.getString(2));
//                a.setTitle(cursor.getString(3));
//                newsList.add(a);
//            }
//
//        } else {
        initNewsList();
//        }

        RecyclerView recyclerView = findViewById(R.id.news_list_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        NewsAdapter adapter = new NewsAdapter(newsList);
        recyclerView.setAdapter(adapter);
        adapter.setOnclick(new NewsAdapter.onItemClick() {
            @Override
            public void onclick(int p) {
             /*   ContentValues values = new ContentValues();
                values.put("_HEAD", newsList.get(p).getContent());
                values.put("_MSG", newsList.get(p).getPic());
                values.put("_TITLE", newsList.get(p).getTitle());
                values.put("_UID", sp.getInt("id",-1));

                db.insert("res", null, values);
                Toast.makeText(NewsListActivity.this, "success", Toast.LENGTH_SHORT)
                        .show();*/

            }
        });
    }

    private void initNewsList() {
        Intent intent = getIntent();
        newsList = intent.getParcelableArrayListExtra("newsList");
        for (News news : newsList) {
            if (news.getTime() == null) {
                Log.d(TAG, "Null Date");
            } else {
                Log.d(TAG, "Date");
            }
        }
    }

}