package com.tools.getway;


import com.tools.getway.utils.CrashHandler;
import com.tools.getway.utils.LogToFile;

import android.app.Application;
import android.content.Context;


public class CustomApplcation extends Application {

	public static CustomApplcation mInstance;
	private static Context context;

	public static String  socketLoginIp="0.0.0.0";//默认是 0.0.0.0

	public static boolean isSaveLogTofile = true;
	public static String dingdingMiantatusId = "1";
	public static boolean isCanOpenRedPack = true;//当前账号是否可以领取,默认可以领取

	//AA
//	public static String base_url = "http://112.74.182.203:8081/";
//	public static String base_socketurl = "ws://112.74.182.203:9092/";
//	public static String base_common = "socket/";



		public static String base_url = "http://socket.flbhkcb.com/";
	public static String base_socketurl = "ws://socket.flbhkcb.com:9092";
	public static String base_common = "";




	public static String login_url = base_common + "api/login";

	public static String authorization_url = base_common + "api/authorization";

	public static boolean isStart = false;
	public static int nowState = 0;//关闭，1，进行中，2开启了

	@Override
	public void onCreate() {
		super.onCreate();
		// 崩溃记录
		context = getApplicationContext();
		CrashHandler crashHandler = CrashHandler.getInstance();
		crashHandler.init(context);
		LogToFile.init(context);
		mInstance = this;
	}

	public static CustomApplcation getInstance() {
		return mInstance;
	}

	public static Context getContext() {
		return context;
	}
}
