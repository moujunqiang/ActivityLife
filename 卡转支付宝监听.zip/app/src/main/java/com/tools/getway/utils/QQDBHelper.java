package com.tools.getway.utils;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class QQDBHelper extends SQLiteOpenHelper{
	public QQDBHelper(Context context) {  
        super(context, "mark.db", null, 1);  
    }

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL("CREATE TABLE IF NOT EXISTS mark" + 
				"(_id INTEGER PRIMARY KEY AUTOINCREMENT, money varchar, mark varchar, status varchar, dt varchar)");
	}
 
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
	}  
}
