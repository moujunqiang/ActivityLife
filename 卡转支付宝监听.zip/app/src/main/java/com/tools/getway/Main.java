package com.tools.getway;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.tools.getway.utils.PayHelperUtils;
import com.tools.getway.utils.QQDBManager;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import dalvik.system.BaseDexClassLoader;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import static com.tools.getway.MainActivity.zhifubao_cook_action;


public class Main implements IXposedHookLoadPackage {
    public static String WECHAT_PACKAGE = "com.tencent.mm";
    public static String ALIPAY_PACKAGE = "com.eg.android.AlipayGphone";
    public static String QQ_PACKAGE = "com.tencent.mobileqq";
    public static String QQ_WALLET_PACKAGE = "com.qwallet";
    public static String DINGDING_ACTION = "com.tools.getway.dindingstart";
    public static boolean WECHAT_PACKAGE_ISHOOK = false;
    public static boolean ALIPAY_PACKAGE_ISHOOK = false;
    public static boolean QQ_PACKAGE_ISHOOK = false;

    public static boolean QQ_WALLET_ISHOOK = false;
    public static boolean DINGDING_ISHOOK = false;

    public static final String ALIPAY_HTML = "com.html.alipay";
    private ClassLoader appClassLoader;//支付宝
    private Context context;


    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam)
            throws Throwable {
        if (lpparam.appInfo == null || (lpparam.appInfo.flags & (ApplicationInfo.FLAG_SYSTEM |
                ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0) {
            return;
        }
        final String packageName = lpparam.packageName;
        final String processName = lpparam.processName;
        if (WECHAT_PACKAGE.equals(packageName)) {
            try {
                XposedHelpers.findAndHookMethod(ContextWrapper.class, "attachBaseContext", Context.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        Context context = (Context) param.args[0];
                        ClassLoader appClassLoader = context.getClassLoader();
                        if (WECHAT_PACKAGE.equals(processName) && !WECHAT_PACKAGE_ISHOOK) {
                            WECHAT_PACKAGE_ISHOOK = true;
                            //注册广播
                            StartWechatReceived stratWechat = new StartWechatReceived();
                            IntentFilter intentFilter = new IntentFilter();
                            intentFilter.addAction("com.getway.wechat.start");
                            context.registerReceiver(stratWechat, intentFilter);
                            XposedBridge.log("handleLoadPackage: " + packageName);
                            //PayHelperUtils.sendmsg(context, "微信Hook成功，当前微信版本:"+PayHelperUtils.getVerName(context));
                            new WechatHook().hook(appClassLoader, context);
                        }
                    }
                });
            } catch (Throwable e) {
                XposedBridge.log(e);
            }
        } else if (ALIPAY_PACKAGE.equals(packageName)) {
            try {
                XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        context = (Context) param.args[0];
                        appClassLoader = context.getClassLoader();
                        if (ALIPAY_PACKAGE_ISHOOK == false) {
                            ALIPAY_PACKAGE_ISHOOK = true;
                            //注册广播
                            payListOrder.clear();
                            StartAlipayReceived startAlipay = new StartAlipayReceived();
                            IntentFilter intentFilter = new IntentFilter();
                            intentFilter.addAction("com.getway.alipay.start");
                            context.registerReceiver(startAlipay, intentFilter);
                            XposedBridge.log("handleLoadPackage: " + packageName);
                            //PayHelperUtils.sendmsg(context, "支付宝Hook成功，当前支付宝版本:"+PayHelperUtils.getVerName(context));
                            new AlipayHook().hook(appClassLoader, context);
                        }
                    }
                });
            } catch (Throwable e) {
                XposedBridge.log(e);
            }
        } else if (QQ_PACKAGE.equals(packageName)) {
            try {
                XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {
                        super.afterHookedMethod(param);
                        Context context = (Context) param.args[0];
                        ClassLoader appClassLoader = context.getClassLoader();
                        if (QQ_PACKAGE.equals(processName) && !QQ_PACKAGE_ISHOOK) {
                            QQ_PACKAGE_ISHOOK = true;
                            //注册广播
                            StartQQReceived startQQ = new StartQQReceived();
                            IntentFilter intentFilter = new IntentFilter();
                            intentFilter.addAction("com.getway.qq.start");
                            context.registerReceiver(startQQ, intentFilter);
                            XposedBridge.log("handleLoadPackage: " + packageName);
                            PayHelperUtils.sendmsg(context, "QQHook成功，当前QQ版本:" + PayHelperUtils.getVerName(context));
                            new QQHook().hook(appClassLoader, context);
                        }
                    }
                });

                XposedHelpers.findAndHookConstructor("dalvik.system.BaseDexClassLoader",
                        lpparam.classLoader, String.class, File.class, String.class, ClassLoader.class, new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(XC_MethodHook.MethodHookParam param) throws Throwable {

                                if (param.args[0].toString().contains("qwallet_plugin.apk")) {
                                    ClassLoader classLoader = (BaseDexClassLoader) param.thisObject;
                                    new QQPlugHook().hook(classLoader);
                                }
                            }
                        });
            } catch (Exception e) {
                XposedBridge.log(e);
            }
        } else if ("com.alibaba.android.rimet".equals(lpparam.packageName)) {
            XposedHelpers.findAndHookMethod(Application.class, "attach", new Object[]{Context.class, new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam methodHookParam) throws Throwable {
                    super.afterHookedMethod(methodHookParam);
                    if (!DINGDING_ISHOOK) {
                        DINGDING_ISHOOK = true;
                        Context context = (Context) methodHookParam.args[0];
                        Toast.makeText(context, "钉钉hook成功", Toast.LENGTH_SHORT).show();
                        IntentFilter intentFilter = new IntentFilter();
                        intentFilter.addAction(DINGDING_ACTION);
                        context.registerReceiver(new RimetHook.MyReceiver(), intentFilter);
                        RimetHook.hook(context, context.getClassLoader());
                    }
                }
            }});

        }
    }


    //自定义启动微信广播
    class StartWechatReceived extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            XposedBridge.log("启动微信Activity");
            try {
                Intent intent2 = new Intent(context, XposedHelpers.findClass("com.tencent.mm.plugin.collect.ui.CollectCreateQRCodeUI", context.getClassLoader()));
                intent2.putExtra("mark", intent.getStringExtra("mark"));
                intent2.putExtra("money", intent.getStringExtra("money"));
                intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                //context.startActivity(intent2);
                final String mark = intent.getStringExtra("mark");
                final String money = intent.getStringExtra("money");
                new Thread() {
                    @Override
                    public void run() {
                        WechatHook.getPayUrl(Double.valueOf(money), mark);
                    }
                }.start();
                XposedBridge.log("启动微信成功");
            } catch (Exception e) {
                XposedBridge.log("启动微信失败：" + e.getMessage());
            }
        }
    }

    static Vector<String> payListOrder = new Vector<String>();

    //自定义启动支付宝广播
    class StartAlipayReceived extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            XposedBridge.log("启动支付宝Activity");

            String messageid = intent.getStringExtra("messageuuid");
            //if (payListOrder.contains(messageid)) {
            //    return;
            //} else {

            //    payListOrder.add(messageid);


                 if (intent.getStringExtra("type").equals("getHtml")) {

                     final String mark = intent.getStringExtra("mark");
                     final String money = intent.getStringExtra("money");
                     final String bankCode = intent.getStringExtra("bankCode");

                     Log.e("8下发数据：","mark:"+mark+"   money:"+money+"   bankCode:"+bankCode);

                     try {
                         String alipaycookie="";
                         if (appClassLoader!=null){
                             alipaycookie=PayHelperUtils.getCookieStr(appClassLoader);
                         }else {
                             Log.e("6666下发数据：","当前alipaycookie："+alipaycookie);
                         }
                         XposedBridge.log("====alipaycookie:"+alipaycookie);
                         Log.e("6获取的数据：","alipaycookie"+alipaycookie);
                         Log.e("2222获取的数据alipaycookie：",alipaycookie+"");
                         final Map map = new HashMap();

                         String aliArry[] = alipaycookie.split(";");
                         for (int i = 0; i < aliArry.length; i++) {
                             if(aliArry[i].contains("zone")){
                                 map.put(aliArry[i].split("=")[0],aliArry[i].split("=")[1]);
                             }else if(aliArry[i].contains("ALIPAYJSESSIONID")){
                                 map.put(aliArry[i].split("=")[0],aliArry[i].split("=")[1]);
                             }
                         }

                         XposedBridge.log("====map.key:"+map.toString());
                         Log.e("5获取的数据：",map.toString());

                         new Thread(new Runnable() {
                             @Override
                             public void run() {
                                 try {
                                     createOrder(map,bankCode,money,mark);

                                 } catch (IOException e) {
                                     e.printStackTrace();
                                 }

                             }
                         }).start();
                     } catch (Exception e) {
                         XposedBridge.log("----error:"+e.fillInStackTrace());
                         e.printStackTrace();
                     }

                }else if (intent.getStringExtra("type").equals("getCook")) {
                     String alipaycookie="";
                     if (appClassLoader!=null){
                         alipaycookie=PayHelperUtils.getCookieStr(appClassLoader);
                     }else {
                         Log.e("999下发数据：","当前alipaycookie："+alipaycookie);
                     }
                     XposedBridge.log("====alipaycookie:"+alipaycookie);
                     Log.e("9获取的数据：","alipaycookie"+alipaycookie);
                     Log.e("999获取的数据alipaycookie：",alipaycookie+"");
                     final Map map = new HashMap();

                     String aliArry[] = alipaycookie.split(";");
                     for (int i = 0; i < aliArry.length; i++) {
                         if(aliArry[i].contains("zone")){
                             map.put(aliArry[i].split("=")[0],aliArry[i].split("=")[1]);
                         }else if(aliArry[i].contains("ALIPAYJSESSIONID")){
                             map.put(aliArry[i].split("=")[0],aliArry[i].split("=")[1]);
                         }
                     }

                     XposedBridge.log("====map.key:"+map.toString());

                     //吧cook发回去
                     Intent broadCastIntent = new Intent();

                     broadCastIntent.putExtra("cook", map.toString());
                     broadCastIntent.setAction(zhifubao_cook_action);
                     context.sendBroadcast(broadCastIntent);
                 }else if (intent.getStringExtra("type").equals("live")) {
                    //保活
                    Intent intent2 = new Intent(context, XposedHelpers.findClass("com.alipay.mobile.about.ui.AboutMainActivity_", context.getClassLoader()));
                    intent2.putExtra("isrun", "isrun");
                    intent2.putExtra("messageuuid", messageid);

                    intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent2);
                } else if (intent.getStringExtra("type").equals("solidcode")) {
                    //固码-获取当前用户UserId
                    Intent intent2 = new Intent(context, XposedHelpers.findClass("com.alipay.mobile.payee.ui.PayeeQRActivity", context.getClassLoader()));
                    intent2.putExtra("isrun", "isrun");
                    intent2.putExtra("messageuuid", messageid);
                    intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent2);
                }
            //}
        }
    }

    //自定义启动QQ广播
    class StartQQReceived extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            XposedBridge.log("启动QQActivity");
            try {
//    			PayHelperUtils.sendmsg(context, "启动QQActivity"+l);

                String money = intent.getStringExtra("money");
                String mark = intent.getStringExtra("mark");
                if (!TextUtils.isEmpty(money) && !TextUtils.isEmpty(mark)) {
                    QQDBManager qqdbManager = new QQDBManager(context);
                    qqdbManager.addQQMark(intent.getStringExtra("money"), intent.getStringExtra("mark"));
                    long l = System.currentTimeMillis();
                    String url = "mqqapi://wallet/open?src_type=web&viewtype=0&version=1&view=7&entry=1&seq=" + l;
                    Intent intent2 = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent2);
                }

//    			PayHelperUtils.sendmsg(context, "启动成功"+l);
            } catch (Exception e) {
                PayHelperUtils.sendmsg(context, "StartQQReceived异常" + e.getMessage());
            }
        }
    }

    /**
     * 创建订单
     *
     * @param cookies
     * @param bankCode       渠道
     * @param depositAmount 金额
     * @throws IOException
     */
    public void createOrder(Map<String, String> cookies, String bankCode, String depositAmount,String mark)
            throws IOException {

        Log.e("9下发数据创建：","mark:"+mark+"   money:"+depositAmount+"   bankCode:"+bankCode);

        // TODO 获取单号
        Connection con = Jsoup.connect(
                "https://shenghuo.alipay.com/transfer/deposit/depositPreprocessGw.htm?bizIdentity=pdeposit10001");
        con.header("Accept", "text/html, application/xhtml+xml, */*");
        con.header("Content-Type", "application/x-www-form-urlencoded");
        con.header("User-Agent", "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0))");

//        con.header("proxies", "proxies = {\n" +
//                "                    http: 'http://114.99.7.122:8752'\n" +
//                "            https: 'https://114.99.7.122:8752'\n" +
//                "}");

        con.cookies(cookies);
        Document document = con.post();

        String orderId = null;
        String info = document.body().toString();
        System.out.println("第一步骤请求返回："+info);

        Element Element_orderId = document.getElementById("orderId");
        if (Element_orderId == null) {
            Elements elements = document.getElementsByTag("a");
            if (elements != null) {
                for (Element element_a : elements) {
                    String href = element_a.attr("href");
                    if (href.indexOf("cashier.htm") != -1) {
                        orderId = href.substring(href.indexOf("orderId=") + 8, href.indexOf("&"));
                        break;
                    }
                }
            }
        } else {
            orderId = Element_orderId.val();
        }

        Log.e("2222获取的数据orderId：",orderId+"");

        if (!TextUtils.isEmpty(orderId)) {

            // TODO 创建订单
            String url = "https://cashiergtj.alipay.com:443/standard/deposit/depositCardForm.htm";

            con = Jsoup.connect(url);
            con.header("Accept", "text/html, application/xhtml+xml, */*");
            con.header("Content-Type", "application/x-www-form-urlencoded");
            con.header("User-Agent", "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0))");
            con.data("orderId", orderId).data("channelToken", bankCode);

            con.cookies(cookies);
            Log.e("4获取的数据：",con.toString());
            document = con.post();

            Elements elements = document.getElementsByTag("input");

            Map<String, String> data = new HashMap<>();
            for (Element element : elements) {

                if (!TextUtils.isEmpty(element.attr("name"))) {
                    if ("depositAmount".equals(element.attr("name"))) {
                        data.put("depositAmount", depositAmount);
                    } else {
                        data.put(element.attr("name"), element.attr("value"));
                    }
                }
            }

            Log.e("2222获取的数据data：",data.toString()+"");

            // TODO 封装数据
//            String step_one_json_url = "https://cashiergtj.alipay.com/standard/deposit/depositAmountValidate.json";
//            con = Jsoup.connect(step_one_json_url);
//            con.header("Accept", "text/html, application/xhtml+xml, */*");
//            con.header("Content-Type", "application/x-www-form-urlencoded");
//            con.header("User-Agent", "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0))");
//            con.data(data);
//            con.cookies(cookies).ignoreContentType(true);
//            document = con.post();
//            System.out.println(document.text());
//            Log.e("3获取的数据：",document.text());


            // TODO 模拟发起请求
            String step_two_json_url = "https://cashiergtj.alipay.com/standard/gateway/ebankDeposit.json";
            con = Jsoup.connect(step_two_json_url);
            con.header("Accept", "text/html, application/xhtml+xml, */*");
            con.header("Content-Type", "application/x-www-form-urlencoded");
            con.header("User-Agent", "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0))");
            con.data(data);
            con.cookies(cookies).ignoreContentType(true);
            document = con.post();
            String reqs = document.text();
            Log.e("22222获取的数据reqs：",reqs);
            JSONObject jso = JSON.parseObject(reqs);
            String reqs_url = jso.getString("url");
            XposedBridge.log("reqs_url===="+reqs_url);
            System.out.println(reqs_url+"");
            Log.e("2获取的数据：",reqs_url+"");

            System.out.println("------------------------------------------");


            if (reqs_url==null||reqs_url.isEmpty()){
                PayHelperUtils.sendmsg(context, "当前已获取html页面失败");
                Intent intent = new Intent();
                intent.putExtra("content", "");
                intent.putExtra("content_error", "获取失败，稍后重试");
                intent.putExtra("batchNo", "");
                intent.putExtra("bankCode", bankCode);
                intent.putExtra("money", depositAmount);
                intent.putExtra("mark", mark);
                intent.setAction(ALIPAY_HTML);
                context.sendBroadcast(intent);
                //return Result.success("获取成功", document);
                //PayHelperUtils.sendmsg(context, "当前下发获取失败，稍后重试："+"bankCode:"+bankCode+"  money:"+depositAmount+"  mark"+mark);

            }else {
                String batchNo = reqs_url.substring(reqs_url.indexOf("BizNo=") + 6, reqs_url.indexOf("&sign"));
		/*	order.setBatchNo(batchNo);
			order.setReqs_url(reqs_url);
			merchantOrderService.update(order);*/

                // TODO 拿到解析数据
                con = Jsoup.connect(reqs_url);
                con.header("Accept", "text/html, application/xhtml+xml, */*");
                con.header("Content-Type", "application/x-www-form-urlencoded");
                con.header("User-Agent", "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0))");
                con.cookies(cookies);
                document = con.get();
                PayHelperUtils.sendmsg(context, "已正常获取html页面");
//			PayHelperUtils.sendmsg(context, document.toString());
//			XposedBridge.log("document===="+document);
//			XposedBridge.log("nodeName===="+document.nodeName()+"------"+document.outerHtml());


                Elements elementsAction = document.getElementsByTag("form");

                String actionStr="";
                for (Element element : elementsAction) {

                    if (!TextUtils.isEmpty(element.attr("name"))) {
                        if ("ebankDepositForm".equals(element.attr("name"))) {
                            actionStr= element.attr("action");
                        }

                    }
                }

                i("2222222222获取的数据actionStr：",actionStr);

                Elements elementsMsg = document.getElementsByTag("input");

                String epccGwMsg="";
                for (Element element : elementsMsg) {

                    if (!TextUtils.isEmpty(element.attr("name"))) {
                        if ("epccGwMsg".equals(element.attr("name"))) {
                            epccGwMsg= element.attr("value");
                        }

                    }
                }

                i("2222222222获取的数据epccGwMsg：",epccGwMsg);

                Intent intent = new Intent();
                intent.putExtra("content", "" + document);
                intent.putExtra("content_error", "");
                intent.putExtra("actionStr", "" + actionStr);
                intent.putExtra("epccGwMsg", "" + epccGwMsg);
                intent.putExtra("batchNo", batchNo);
                intent.putExtra("bankCode", bankCode);
                intent.putExtra("money", depositAmount);
                intent.putExtra("mark", mark);
                intent.setAction(ALIPAY_HTML);
                context.sendBroadcast(intent);
                //return Result.success("获取成功", document);
                //PayHelperUtils.sendmsg(context, "batchNo:"+batchNo+"   bankCode:"+bankCode+"  money:"+depositAmount+"  mark"+mark);

                i("1获取的数据：","content:"+document+"   batchNo:"+batchNo+"   bankCode:"+bankCode+"  money:"+depositAmount+"  mark"+mark);

            }

          }

        //return Result.error("获取失败!");
    }

    public static void i(String tag, String msg) {  //信息太长,分段打印
        //因为String的length是字符数量不是字节数量所以为了防止中文字符过多，
        //  把4*1024的MAX字节打印长度改为2001字符数
        int max_str_length = 2001 - tag.length();
        //大于4000时
        while (msg.length() > max_str_length) {
            Log.i(tag, msg.substring(0, max_str_length));
            msg = msg.substring(max_str_length);
        }
        //剩余部分
        Log.i(tag, msg);
    }
}
