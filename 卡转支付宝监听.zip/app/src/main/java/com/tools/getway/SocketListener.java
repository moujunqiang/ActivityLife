package com.tools.getway;

public interface SocketListener {

    public void onOpen();
    public void closed();
    public void onError();

    public void tostToMain(String message);
    public void getDingQrPayurl(String keyid,String messageuuid,String money,String mark);//服务端下发获取通道生成二维码

    public void getToAlipayHtml(String keyid,String messageuuid,String money,String mark,String bankCode);//服务端下发获取通道生成二维码

    public void tostToOpenRedpack(String ddsenter,String ddno,String keyid);//下发拆开红包指令

    public void onMessageIp(String msg);//ip信息
    public void onMessageIpError(String msg);//ip错误，弹框提示
}
