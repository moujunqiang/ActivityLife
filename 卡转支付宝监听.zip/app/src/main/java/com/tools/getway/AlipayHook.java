package com.tools.getway;


import java.lang.reflect.Field;
import java.util.ArrayList;

import android.util.Base64;

import com.tools.getway.utils.PayHelperUtils;
import com.tools.getway.utils.StringUtils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public class AlipayHook {

    public static String BILLRECEIVED_ACTION = "com.tools.getway.billreceived";
    public static String QRCODERECEIVED_ACTION = "com.tools.getway.qrcodereceived";
    public static String SAVEALIPAYCOOKIE_ACTION = "com.tools.getway.savealipaycookie";
    public static String baohuo_action = "com.tools.getway.live";
    public static String zhifubao_uid_action = "com.tools.getway.uid";

    public void hook(final ClassLoader classLoader, final Context context) {
        securityCheckHook(classLoader);
        try {


            XposedHelpers.findAndHookMethod("com.alipay.mobile.payee.ui.PayeeQRActivity", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    Intent intent = ((Activity) param.thisObject).getIntent();
                    String isrun = intent.getStringExtra("isrun");

                    String messageuuid = intent.getStringExtra("messageuuid");
                    if (isrun == null) {
                    } else {
                        System.out.println("开始进入userid");
                        Field moneyField = XposedHelpers.findField(param.thisObject.getClass(), "f");
                        String userid = (String) moneyField.get(param.thisObject);

                        if (userid == null) {
                            userid = "";
                        }
                        System.out.println("开始进入userid" + userid);

                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("userid", userid);
                        broadCastIntent.putExtra("messageuuid", messageuuid);
                        broadCastIntent.setAction(zhifubao_uid_action);
                        context.sendBroadcast(broadCastIntent);

                        XposedHelpers.callMethod(param.thisObject, "finish", new Object[0]);
                    }
                }
            });
            //保活com.alipay.mobile.about.ui.AboutMainActivity_
            XposedHelpers.findAndHookMethod("com.alipay.mobile.about.ui.AboutMainActivity_", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {

                    Intent intent = ((Activity) param.thisObject).getIntent();
                    String isrun = intent.getStringExtra("isrun");
                    String messageuuid = intent.getStringExtra("messageuuid");
                    if (isrun == null) {

                    } else {
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("messageuuid", messageuuid);
                        broadCastIntent.setAction(baohuo_action);
                        context.sendBroadcast(broadCastIntent);
                        XposedHelpers.callMethod(param.thisObject, "finish", new Object[0]);
                    }

                }
            });


            final Class clazzSyncMessage = XposedHelpers.findClass("com.alipay.mobile.rome.longlinkservice.syncmodel.SyncMessage", classLoader);
            XposedHelpers.findAndHookMethod(XposedHelpers.findClass("com.alipay.mobile.socialchatsdk.chat.data.ChatDataSyncCallback", classLoader), "onReceiveMessage", clazzSyncMessage,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            super.afterHookedMethod(param);
                            Object object = param.args[0];
                            String MessageInfo = (String) XposedHelpers.callMethod(object, "toString");
                            System.out.println("信息：" + MessageInfo);
                            JSONArray msgArr = JSON.parseArray(clazzSyncMessage.getField("msgData").get(object).toString());
                            for (int i = 0; i < msgArr.size(); i++) {
                                JSONObject msgData = msgArr.getJSONObject(i);
                                String pl = msgData.getString("pl");
                                Object wireIns = XposedHelpers.newInstance(XposedHelpers.findClass("com.squareup.wire.Wire", classLoader), new ArrayList<Class>());
                                Object decode_pl = XposedHelpers.callMethod(wireIns, "parseFrom", Base64.decode(pl, 0), XposedHelpers.findClass("com.alipay.mobilechat.core.model.message.MessagePayloadModel", classLoader));
                                String decode_pl_str = JSON.toJSONString(decode_pl);
                                JSONObject decode_pl_json = JSON.parseObject(decode_pl_str);
                                System.out.println("信息：1=" + "decode_pl_json==>" + decode_pl_json.toJSONString());
                                String biz_type = decode_pl_json.getString("biz_type");
                                String client_msg_id = decode_pl_json.getString("client_msg_id");
                                if ("TRANSFER".equals(biz_type)) {//转账
                                    if (client_msg_id.contains("STTRANSFER")) {
                                        System.out.println("该条消息过滤：decode_pl_json==>");
                                    } else {


                                        String read = decode_pl_json.getString("read");
                                        String from_u_id = decode_pl_json.getString("from_u_id");//发送人的uid
                                        String to_u_id = decode_pl_json.getString("to_u_id");
                                        String link = decode_pl_json.getString("link");//查账直接扫码这个链接
                                        String template_data = decode_pl_json.getString("template_data");
                                        JSONObject jsonObject = JSON.parseObject(template_data);
                                        String m = jsonObject.getString("m");//收款金额
                                        String mark = jsonObject.getString("title");//收款备注
                                        //回调
                                        String tradeNo = StringUtils.getTextCenter2(link, "tradeNO=", "");
                                        System.out.println("信息：1=" + "发送收款广播");

                                        Intent broadCastIntent = new Intent();
                                        broadCastIntent.putExtra("bill_no", tradeNo);
                                        broadCastIntent.putExtra("bill_money", m);
                                        broadCastIntent.putExtra("bill_mark", mark);
                                        broadCastIntent.putExtra("from_u_id", from_u_id);
                                        broadCastIntent.putExtra("bill_type", "alipay");
                                        broadCastIntent.setAction(BILLRECEIVED_ACTION);
                                        context.sendBroadcast(broadCastIntent);
                                    }
                                }
                            }
                        }
                    });

            Class<?> insertTradeMessageInfo = XposedHelpers.findClass("com.alipay.android.phone.messageboxstatic.biz.dao.TradeDao", classLoader);
            XposedBridge.hookAllMethods(insertTradeMessageInfo, "insertMessageInfo", new XC_MethodHook() {
            	@Override
            	protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
            		try {
            			XposedBridge.log("======支付宝个人账号订单start=========");

            			//更新cookie
                		Intent cookieBroadCastIntent = new Intent();
                		String alipaycookie=PayHelperUtils.getCookieStr(classLoader);
                		cookieBroadCastIntent.putExtra("alipaycookie", alipaycookie);
                		cookieBroadCastIntent.setAction(SAVEALIPAYCOOKIE_ACTION);
                        context.sendBroadcast(cookieBroadCastIntent);

            			//获取content字段
//            			String content=(String) XposedHelpers.getObjectField(param.args[0], "content");
//            			XposedBridge.log(content);
            			//获取全部字段
            			Object object = param.args[0];
            			String MessageInfo = (String) XposedHelpers.callMethod(object, "toString");
            			XposedBridge.log(MessageInfo);
                        System.out.println("个人进入得信息"+MessageInfo);
            			String content=StringUtils.getTextCenter(MessageInfo, "content='", "'");

                        if(content.contains("付款成功")) {
                            org.json.JSONObject jsonObject=new org.json.JSONObject(content);
                            String money=jsonObject.getString("content").replace("￥", "");
                            String mark=jsonObject.getString("assistMsg2");
                            String tradeNo=StringUtils.getTextCenter(MessageInfo,"tradeNO=","&");
                            XposedBridge.log("收到支付宝支付订单："+tradeNo+"=="+money+"=="+mark);

                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("bill_no", tradeNo);
                            broadCastIntent.putExtra("bill_money", money);
                            broadCastIntent.putExtra("bill_mark", mark);
                            broadCastIntent.putExtra("bill_type", "alipay");
                            broadCastIntent.setAction(BILLRECEIVED_ACTION);
                            context.sendBroadcast(broadCastIntent);
                        }
                        XposedBridge.log("======支付宝个人账号订单end=========");
            		} catch (Exception e) {
            			XposedBridge.log(e.getMessage());
            		}
            		super.beforeHookedMethod(param);
            	}
            });
//           Class<?> insertServiceMessageInfo = XposedHelpers.findClass("com.alipay.android.phone.messageboxstatic.biz.dao.ServiceDao", classLoader);
//            XposedBridge.hookAllMethods(insertServiceMessageInfo, "insertMessageInfo", new XC_MethodHook() {
//            	@Override
//            	protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
//            		try {
//						XposedBridge.log("======支付宝商家服务订单start=========");
//
//						//更新cookie
//                		Intent cookieBroadCastIntent = new Intent();
//                		String alipaycookie=PayHelperUtils.getCookieStr(classLoader);
//                		cookieBroadCastIntent.putExtra("alipaycookie", alipaycookie);
//                		cookieBroadCastIntent.setAction(SAVEALIPAYCOOKIE_ACTION);
//                        context.sendBroadcast(cookieBroadCastIntent);
//
//						Object object = param.args[0];
//						String MessageInfo = (String) XposedHelpers.callMethod(object, "toString");
//                        String content=StringUtils.getTextCenter(MessageInfo, "content='", "'");
//
//                        System.out.println("商家进入得信息"+content);
//                        if(content.contains("收款金额") && MessageInfo.contains("收款到账")) {
//
//                            System.out.println("商家进入="+content);
//                            org.json.JSONObject jsonObject=new org.json.JSONObject(content);
//                            String money=jsonObject.getString("mainAmount");
//                            System.out.println("商家进入，金额="+money);
//
//                            Intent broadCastIntent = new Intent();
//                            broadCastIntent.putExtra("bill_no", "");
//                            broadCastIntent.putExtra("bill_money", money);
//                            broadCastIntent.putExtra("bill_mark", "");
//                            broadCastIntent.putExtra("from_u_id", "");
//                            broadCastIntent.putExtra("bill_type", "alipay");
//                            broadCastIntent.setAction(BILLRECEIVED_ACTION);
//                            context.sendBroadcast(broadCastIntent);
//
//                            System.out.println("发送广播了，");
//                        }
////						String content=StringUtils.getTextCenter(MessageInfo, "extraInfo='", "'").replace("\\", "");
////						XposedBridge.log(content);
////
////						System.out.println("商家进入得信息"+MessageInfo);
////                        PayHelperUtils.getTradeInfo(context,alipaycookie);
////
////                        if(content.contains("二维码收款") || content.contains("收到一笔转账")){
////
////                        }
//
////						if(content.contains("店员通")){
////							String money=StringUtils.getTextCenter(content, "mainAmount\":\"", "\",\"mainTitle");
////							String time=StringUtils.getTextCenter(content, "gmtCreate\":", ",gmtValid");
////							String no=PayHelperUtils.getOrderId();
//////							Intent broadCastIntent = new Intent();
//////                			broadCastIntent.putExtra("bill_no", no);
//////                            broadCastIntent.putExtra("bill_money", money);
//////                            broadCastIntent.putExtra("bill_mark", "");
//////                            broadCastIntent.putExtra("bill_time", time);
//////                            broadCastIntent.putExtra("bill_type", "alipay_dy");
//////                            broadCastIntent.setAction(BILLRECEIVED_ACTION);
//////                            context.sendBroadcast(broadCastIntent);
////
////
////                            Intent broadCastIntent = new Intent();
////                            broadCastIntent.putExtra("bill_no", no);
////                            broadCastIntent.putExtra("bill_money", money);
////                            broadCastIntent.putExtra("bill_mark", "");
////                            broadCastIntent.putExtra("from_u_id", "");
////                            broadCastIntent.putExtra("bill_type", "alipay");
////                            broadCastIntent.setAction(BILLRECEIVED_ACTION);
////						}else if(content.contains("收钱到账") || content.contains("收款到账")){
////							PayHelperUtils.getTradeInfo(context,alipaycookie);
////						}
//						XposedBridge.log("======支付宝商家服务订单end=========");
//					} catch (Exception e) {
//						PayHelperUtils.sendmsg(context, e.getMessage());
//					}
//            		super.beforeHookedMethod(param);
//            	}
//            });

            // hook设置金额和备注的onCreate方法，自动填写数据并点击
            XposedHelpers.findAndHookMethod("com.alipay.mobile.payee.ui.PayeeQRSetMoneyActivity", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    XposedBridge.log("========支付宝设置金额start=========");

                    //更新cookie
                    Intent cookieBroadCastIntent = new Intent();
                    String alipaycookie = PayHelperUtils.getCookieStr(classLoader);
                    cookieBroadCastIntent.putExtra("alipaycookie", alipaycookie);
                    cookieBroadCastIntent.setAction(SAVEALIPAYCOOKIE_ACTION);
                    context.sendBroadcast(cookieBroadCastIntent);

                    Field jinErField = XposedHelpers.findField(param.thisObject.getClass(), "b");
                    final Object jinErView = jinErField.get(param.thisObject);
                    Field beiZhuField = XposedHelpers.findField(param.thisObject.getClass(), "c");
                    final Object beiZhuView = beiZhuField.get(param.thisObject);
                    Intent intent = ((Activity) param.thisObject).getIntent();
                    String mark = intent.getStringExtra("mark");
                    String money = intent.getStringExtra("money");
                    //设置支付宝金额和备注
                    XposedHelpers.callMethod(jinErView, "setText", money);
                    XposedHelpers.callMethod(beiZhuView, "setText", mark);
                    //点击确认
                    Field quRenField = XposedHelpers.findField(param.thisObject.getClass(), "e");
                    final Button quRenButton = (Button) quRenField.get(param.thisObject);
                    quRenButton.performClick();
                    XposedBridge.log("=========支付宝设置金额end========");
                }
            });

            // hook获得二维码url的回调方法
            XposedHelpers.findAndHookMethod("com.alipay.mobile.payee.ui.PayeeQRSetMoneyActivity", classLoader, "a",
                    XposedHelpers.findClass("com.alipay.transferprod.rpc.result.ConsultSetAmountRes", classLoader), new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            XposedBridge.log("=========支付宝生成完成start========");
                            Field moneyField = XposedHelpers.findField(param.thisObject.getClass(), "g");
                            String money = (String) moneyField.get(param.thisObject);

                            Field markField = XposedHelpers.findField(param.thisObject.getClass(), "c");
                            Object markObject = markField.get(param.thisObject);
                            String mark = (String) XposedHelpers.callMethod(markObject, "getUbbStr");

                            Object consultSetAmountRes = param.args[0];
                            Field consultField = XposedHelpers.findField(consultSetAmountRes.getClass(), "qrCodeUrl");
                            String payurl = (String) consultField.get(consultSetAmountRes);
                            XposedBridge.log(money + "  " + mark + "  " + payurl);

                            if (money != null) {
                                XposedBridge.log("调用增加数据方法==>支付宝");
                                Intent broadCastIntent = new Intent();
                                broadCastIntent.putExtra("money", money);
                                broadCastIntent.putExtra("mark", mark);
                                broadCastIntent.putExtra("type", "alipay");
                                broadCastIntent.putExtra("payurl", payurl);
                                broadCastIntent.setAction(QRCODERECEIVED_ACTION);
                                context.sendBroadcast(broadCastIntent);
                            }
                            XposedBridge.log("=========支付宝生成完成end========");
                        }
                    });

            // hook获取loginid
            XposedHelpers.findAndHookMethod("com.alipay.mobile.quinox.LauncherActivity", classLoader, "onResume",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            PayHelperUtils.isFirst = true;
                            String loginid = PayHelperUtils.getAlipayLoginId(classLoader);
                            PayHelperUtils.sendLoginId(loginid, "alipay", context);

                        }
                    });
        } catch (Error | Exception e) {
            PayHelperUtils.sendmsg(context, e.getMessage());
        }
    }

    private void securityCheckHook(ClassLoader classLoader) {
        try {
            Class<?> securityCheckClazz = XposedHelpers.findClass("com.alipay.mobile.base.security.CI", classLoader);
            XposedHelpers.findAndHookMethod(securityCheckClazz, "a", String.class, String.class, String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    Object object = param.getResult();
                    XposedHelpers.setBooleanField(object, "a", false);
                    param.setResult(object);
                    super.afterHookedMethod(param);
                }
            });

            XposedHelpers.findAndHookMethod(securityCheckClazz, "a", Class.class, String.class, String.class, new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                    return (byte) 1;
                }
            });
            XposedHelpers.findAndHookMethod(securityCheckClazz, "a", ClassLoader.class, String.class, new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                    return (byte) 1;
                }
            });
            XposedHelpers.findAndHookMethod(securityCheckClazz, "a", new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                    return false;
                }
            });

        } catch (Error | Exception e) {
            e.printStackTrace();
        }
    }
}