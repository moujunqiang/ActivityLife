package com.tools.getway;

import android.content.Context;
import android.text.TextUtils;


import com.tools.getway.utils.AbSharedUtil;
import com.tools.getway.utils.LogToFile;
import com.tools.getway.utils.PayHelperUtils;
import com.tools.getway.utils.StringUtils;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.json.JSONObject;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import static com.tools.getway.MainActivity.sendmsg;


public class SocketClient extends WebSocketClient {
    SocketListener socketListener;
    static Vector<String> payListOrder = new Vector<String>();
    public static Map<String, String> payListOrderMap = new HashMap<>();

    public void setSocketListener(SocketListener socketListener) {
        this.socketListener = socketListener;
    }

    public static boolean isValidLong(String str) {
        try {
//            String a="132.456";
            float b = Float.parseFloat(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * @param args
     * @throws URISyntaxException
     */
    public static void main(String[] args) throws URISyntaxException {
//        WebSocketClient client = new SocketClient(new URI("ws://58.82.250.200:9092/"));
//        client.connect();

//        String str2 = "可用余额 1元";
//        float d = getDoubleValue(str2);
//        System.out.println(">>"+d);
//        String test = "123456";
//        System.out.println(test.substring(5, 6));
        String link="alipays://platformapi/startapp?appId=20000090&actionType=toBillDetails&tradeNO=20190416200040011100470036576756";
        String tradeNo= StringUtils.getTextCenter2(link,"tradeNO=","");
        System.out.println(tradeNo);
    }

    Context context;

    public SocketClient(Context context, URI serverUri) {
        super(serverUri);
        payListOrder.clear();
        this.context = context;
        System.out.println("初始化通道" + CustomApplcation.base_socketurl);
    }

    @Override
    public void onOpen(ServerHandshake handshakedata) {
        System.out.println("打开通道");
        if (socketListener != null) {
            socketListener.onOpen();
        }
    }

    public static long nowTime = 0;

    @Override
    public void onMessage(String message) {

        try {
            System.out.println("接受消息" + JsonHelper.isJson(message) + "   " + message);

            //解析指令，然后请求http
            if (JsonHelper.isJson(message)) {
                //解析type
                JSONObject jsonObj = new JSONObject(message);
                String type = jsonObj.optString("type", "");
                if (type.equals("login")) {
                    //心跳不记录，
                } else {
                    //记录除心跳的所有日志
                    LogToFile.e("socketAllMessage", message);
                }


                if (type != null) {
                    if (type.equals("init")) {
//                        String clientid = jsonObj.getString("client_id");
                        if (socketListener != null) {
//                            socketListener.init_login(clientid);
                        }
                    } else if (type.equals("login")) {
                        //{"type":"login","code":"500","msg":"当前通道所绑定的支付宝其他通道已绑定、请换支付宝"}
                        String code = jsonObj.optString("code", "");
                        String msg = jsonObj.optString("msg", "");
                        if (code.equals("200")) {
                            CustomApplcation.socketLoginIp = jsonObj.optString("ip", "0.0.0.0");//默认0.0.0.0
                            if (socketListener != null) {
                            socketListener.onMessageIp(CustomApplcation.socketLoginIp);
                            }
                            //回调到主页，
                                //{"type":"login","code":200,"msg":"\u767b\u9646\u6210\u529f",
                                // "alipaystatus":2,"wuchatstatus":2,"redstatus":2,"recstatus":2,"
                                // trastatus":2,"ddstatus":1,"dingdingReceiveRed":1,"dingdingMiantatus":1}
                                //正常不处理
                                CustomApplcation.dingdingMiantatusId = jsonObj.optString("dingdingMiantatus", "1").trim();//1，主账号，2，子账号
                                String dingdingReceiveRed = jsonObj.optString("dingdingReceiveRed", "1").trim();
                                ;//主账号，1，能领取，2，不能领取
                                if (CustomApplcation.dingdingMiantatusId.equals("1")) {
                                    if (dingdingReceiveRed.equals("1")) {
                                        //能领取，
                                        CustomApplcation.isCanOpenRedPack = true;
                                    } else {
                                        //不能领取
                                        CustomApplcation.isCanOpenRedPack = false;
                                    }
                                }else {
                                    //能领取
                                    CustomApplcation.isCanOpenRedPack = true;
                                }

                        }else if (code.equals("5000")) {
                            //显示ip错误信息

                            if (socketListener != null) {
                                System.out.println("显示错误信息");
                                socketListener.onMessageIpError(msg);
                            }
                        }  else {

                            sendmsg("心跳返回code:" + code + "  msg:" + msg);

                        }

                    }else if (type.equals("getToAlipayHtml")) {

                        //{"mark":"1|111dd","money":"0.01","bankCode":"SPABANKspabanknucc103_DEPOSIT_DEBIT_EBANK_XBOX_MODEL","key_id":"2088332230634660","type":"getToAlipayHtml"}
                        String key_id = jsonObj.optString("key_id", "");
                        String mark = jsonObj.optString("mark", "");
                        String money = jsonObj.optString("money", "");
                        String bankCode = jsonObj.optString("bankCode", "");
                        String messageid = jsonObj.optString("messageuuid", "");

                        String searchCode_key = "";
                        if (!TextUtils.isEmpty(AbSharedUtil.getString2(context, "dingding_key"))) {
                            searchCode_key = (AbSharedUtil.getString2(context, "dingding_key"));
                        }

                        if (searchCode_key.equals(key_id)) {

                            if (payListOrder.contains(mark)) {
                                return;
                            } else {
                                LogToFile.e("nailgroupcollectionpaytype", message);
                                payListOrder.add(mark);
                                sendmsg("下发获取Html:\n " + key_id + "   mark：" + mark + "  money：" + money+"    bankCode："+bankCode);
                                if (socketListener != null) {

                                    socketListener.getToAlipayHtml(key_id, messageid, money, mark, bankCode);
                                }
                            }
                        }
                    } else if (type.equals("dingdingpaytype")) {
//                        //钉钉请求生成二维码
//                        //先去重{"mark":"1|111dd","money":"0.01","key_id":"2088332230634660","type":"dingdingpaytype"}
//                        String key_id = jsonObj.optString("key_id", "");
//                        String mark = jsonObj.optString("mark", "");
//                        String money = jsonObj.optString("money", "");
//                        String messageid = jsonObj.optString("messageuuid", "");
//                        if (payListOrder.contains(mark)) {
//                            return;
//                        } else {
//                            LogToFile.e("socketDingdingPaytypeMessage", message);
//                            payListOrder.add(mark);
//                            System.out.println("请求生成二维码 " + key_id + "    " + mark + "   " + money);
//                            if (socketListener != null) {
//                                payListOrderMap.put(mark, messageid);
//                                socketListener.getDingQrPayurl(key_id, messageid, money, mark);
//                            }
//                        }
                    } else if (type.equals("postUploadQrCodeDingding")) {
//                        LogToFile.e("socketPostUploadQrCodeDingding", message);
//                        String code = jsonObj.optString("code", "");
//                        String msg = jsonObj.optString("msg", "");
//                        if (code.equals("200")) {
//
//                            //正常不处理
//                        } else {
//
//                            sendmsg("更新上传钉钉二维码结果:" + code + "  msg:" + msg);
//
//                        }
                    } else if (type.equals("notifyurltransfer")) {
                        LogToFile.e("socketNotifyurl", message);
                        String code = jsonObj.optString("code", "");
                        String msg = jsonObj.optString("msg", "");
                        if (code.equals("200")) {

                            //正常不处理
                        } else {

                            sendmsg("更新上传支付宝转账支付结果:" + code + "  msg:" + msg);

                        }
                    } else if (type.equals("forwarding_dingding")) {
//                        String code = jsonObj.optString("code", "");
//                        String msg = jsonObj.optString("msg", "");
//                        if (code.equals("200")) {
//                            //已经转发成功
//                        } else {
//                            //转发失败，当前账号拆开红包
//                            String ddsenter = jsonObj.optString("ddsenter", "");
//                            String no = jsonObj.optString("no", "");
//                            String key = jsonObj.optString("key", "");
////                            "ddsenter":"红包生成者",
////                                    "no":"红包",
////                                    "key":"通道id",
//                            if (socketListener != null) {
//                                socketListener.tostToOpenRedpack(ddsenter, no, key);
//                            }
//                        }
                    } else if (type.equals("turnoverRed")) {
//                        String code = jsonObj.optString("code", "");
//                        String msg = jsonObj.optString("msg", "");
//                        //接收到转发指令，打开红包
//                        if (code.equals("200")) {
//                            String ddsenter = jsonObj.optString("ddsenter", "");
//                            String no = jsonObj.optString("no", "");
//                            String key = jsonObj.optString("key", "");
////                            "ddsenter":"红包生成者",
////                                    "no":"红包",
////                                    "key":"通道id",
//                            if (socketListener != null) {
//                                socketListener.tostToOpenRedpack(ddsenter, no, key);
//                            }
//                        } else {
//                            //转发失败，
//                            sendmsg("收到主账号转发子账号失败:" + code + "  msg:" + msg);
//                        }

                    }
                }
            }
            //回调

        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        if (socketListener != null) {
            socketListener.closed();
        }
        System.out.println("Connection closed by " + (remote ? "remote peer" : "us"));
        System.out.println("picher_log" + "通道关闭");
    }

    @Override
    public void onError(Exception ex) {
        ex.printStackTrace();
        if (socketListener != null) {
            socketListener.onError();
        }

        System.out.println("连接错误");
        PayHelperUtils.sendmsg(context, ex.getMessage() + " \n " + CustomApplcation.base_socketurl);

    }


    /**
     * 解析字符串获得双精度型数值，
     *
     * @param str
     * @return
     */
    public static float getDoubleValue(String str) {
        float d = 0;

        if (str != null && str.length() != 0) {
            StringBuffer bf = new StringBuffer();

            char[] chars = str.toCharArray();
            for (int i = 0; i < chars.length; i++) {
                char c = chars[i];
                if (c >= '0' && c <= '9') {
                    bf.append(c);
                } else if (c == '.') {
                    if (bf.length() == 0) {
                        continue;
                    } else if (bf.indexOf(".") != -1) {
                        break;
                    } else {
                        bf.append(c);
                    }
                } else {
                    if (bf.length() != 0) {
                        break;
                    }
                }
            }
            try {
                d = Float.parseFloat(bf.toString());
            } catch (Exception e) {
            }
        }

        return d;
    }


}
