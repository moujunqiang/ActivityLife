package com.tools.getway;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.tools.getway.utils.AbSharedUtil;
import com.tools.getway.utils.DBManager;
import com.tools.getway.utils.LogToFile;
import com.tools.getway.utils.MD5;
import com.tools.getway.utils.OrderBean;
import com.tools.getway.utils.PayHelperUtils;

import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;


public class MainActivity extends BaseActivity {

    private TextView tvLogOpen, tvLogAdress;
    public static TextView ipMessage;

    private TextView tv_alipay_chaxun, tv_alipay_chaxun1;


    public static TextView console;
    private static ScrollView scrollView;
    private BillReceived billReceived;
    private AlarmReceiver alarmReceiver;

    public static String OPEN_REDPACK_ACTION = "com.tools.getway.redpacketopen";//广播通知拆开红包

    public static String zhifubao_uid_action = "com.tools.getway.uid";
    public static String zhifubao_cook_action = "com.tools.getway.cook";

    public static String BILLRECEIVED_ACTION = "com.tools.getway.billreceived";
    public static String QRCODERECEIVED_ACTION = "com.tools.getway.qrcodereceived";
    public static String MSGRECEIVED_ACTION = "com.tools.getway.msgreceived";
    public static String TRADENORECEIVED_ACTION = "com.tools.getway.tradenoreceived";
    public static String LOGINIDRECEIVED_ACTION = "com.tools.getway.loginidreceived";
    public static String NOTIFY_ACTION = "com.tools.getway.notify";
    public static String SAVEALIPAYCOOKIE_ACTION = "com.tools.getway.savealipaycookie";
    public static int WEBSEERVER_PORT = 8080;

    public static String baohuo_action = "com.tools.getway.live";

    private String currentWechat = "";
    private String currentAlipay = "";
    private String currentQQ = "";

    public static final String ALIPAY_HTML = "com.html.alipay";

    private String userid_now = "";
    private String usercook_now = "";

    //启动一个定时器，定期跳转支付宝和当前保活
    Handler handlerTempTest = new Handler();
    Runnable runnableTempTest = new Runnable() {
        @Override
        public void run() {

            //一分钟生成一个支付宝的二维码，主要用来测试助手一直在首页，防止手机休眠挂掉
            System.out.println("每隔2分钟查询cook:" + CustomApplcation.isStart + " ");
            //取出最后一个
            if (CustomApplcation.isStart == true) {
                long nowTimetemp = new Date().getTime();
//                if ((nowTimetemp - nowTime) > 30000) {
                System.out.println("测试返回主页测试跳转");
                Intent broadCastIntent2 = new Intent();
                broadCastIntent2.setAction("com.getway.alipay.start");
                broadCastIntent2.putExtra("type", "getCook");

                sendBroadcast(broadCastIntent2);
//
//                Intent broadCastIntent = new Intent();
//                broadCastIntent.setAction("com.getway.alipay.start");
//                broadCastIntent.putExtra("type", "live");
//                broadCastIntent.putExtra("messageuuid", "" + (int) (Math.random() * 1000000));
//                sendBroadcast(broadCastIntent);

//                    try {
//                        PayHelperUtils.startAPP(CustomApplcation.getInstance().getApplicationContext(), "com.alibaba.android.rimet");
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//                    PayHelperUtils.startAPP();
//                }

            }
            handlerTempTest.postDelayed(this, 120000);
        }
    };


    //socket心跳机制
    Handler handlertest = new Handler();
    Runnable runnabletest = new Runnable() {
        @Override
        public void run() {
//            showData();
            try {
                if (client == null) {

                } else if (client.isOpen()) {


                    String dingding_key = "";


                    if (!TextUtils.isEmpty(AbSharedUtil.getString2(getApplicationContext(), "dingding_key"))) {
                        dingding_key = (AbSharedUtil.getString2(getApplicationContext(), "dingding_key"));
                    }

                    JSONObject object = new JSONObject();//创建一个总的对象，这个对象对整个json串
                    JSONObject jsonObj = new JSONObject();//pet对象，json形式
                    jsonObj.put("messageuuid", "" + (int) (Math.random() * 1000000));//消息id
                    jsonObj.put("wechat_id", "");//微信的key_id
                    jsonObj.put("alipay_id", "");//支付宝的key_id
                    jsonObj.put("alipay2_id", "");//支付宝转账通道单独app
                    jsonObj.put("red_packet_id", "");//支付宝的红包通道key_id
                    jsonObj.put("alipay_pattern_id", "");//支付宝的收款通道key_id
                    jsonObj.put("alipay_account_user_id", userid_now + "");//支付宝官方ID
                    jsonObj.put("dingding_id", "");//钉钉的收款通道key_id
                    jsonObj.put("bankToAlipay", dingding_key + "");//银行卡转支付宝////////////////////
                    jsonObj.put("merchant_id", SPUtils.getInstance().getString(MERCHANTSID, ""));//码商ID
                    jsonObj.put("phoneId", getPesudoUniqueID()); //设备唯一ID
                    jsonObj.put("cookies",usercook_now ); //支付宝cook


                    object.put("params", jsonObj);//向总对象里面添加包含pet的数组
                    object.put("type", "login");

                    System.out.println("发送心跳日志完成" + CustomApplcation.isStart + "   " + object.toString());
                    //启动，就开始发送，
                    if (CustomApplcation.isStart == true) {
                        client.send(object.toString());
                    }

                } else {
                    if (CustomApplcation.isStart == true) {
                        websocketInit(new WebsocketListener() {
                            @Override
                            public void onSuccessful() {

                            }

                            @Override
                            public void onFailure() {

                            }
                        });
                    }

                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            // 循环调用实现定时刷新界面
            handlertest.postDelayed(this, 5000);
        }

    };

    public SocketClient client = null;
    private Button stop;

    private EditText alipaykeyColect;
    private Button start;
    String mainUserid = "";//支付宝userid

    private TextView logout;//退出按钮

    //码商id
    public static String MERCHANTSID = "merchants_id";
    //ip
    public static String LOGINIP = "login_ip";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (SPUtils.getInstance().getString(MERCHANTSID).equals("")) {
            startIntent(LoginActivity.class);
            finish();
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        setContentView(R.layout.activity_main);
        console = (TextView) findViewById(R.id.console);
        scrollView = (ScrollView) findViewById(R.id.scrollview);
        ipMessage = (TextView) findViewById(R.id.et_ip_message);

        payListOrder.clear();

        this.findViewById(R.id.tv_home_test).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("00获取的数据：", "点击1");
                Intent broadCastIntent2 = new Intent();
                broadCastIntent2.setAction("com.getway.alipay.start");
                broadCastIntent2.putExtra("type", "getHtml");
                broadCastIntent2.putExtra("mark", "C123456");
                broadCastIntent2.putExtra("money", "0.01");
                broadCastIntent2.putExtra("bankCode", "CCBccb103_DEPOSIT_DEBIT_EBANK_XBOX_MODEL");//建设银行
                sendBroadcast(broadCastIntent2);
                sendmsg("下发获取Html:\n " + "   mark：" + "C123456" + "  money：" + "0.01" + "    bankCode：" + "CCBccb103_DEPOSIT_DEBIT_EBANK_XBOX_MODEL");
            }
        });

        this.findViewById(R.id.start_alipay).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View arg0) {
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.setAction("com.getway.alipay.start");
                        String time = System.currentTimeMillis() / 10000L + "";
                        broadCastIntent.putExtra("mark", "test" + time);
                        broadCastIntent.putExtra("money", "0.01");
                        sendBroadcast(broadCastIntent);
                    }
                });
        this.findViewById(R.id.start_wechat).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View arg0) {
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.setAction("com.getway.wechat.start");
                        String time = System.currentTimeMillis() / 10000L + "";
                        broadCastIntent.putExtra("mark", "test" + time);
                        broadCastIntent.putExtra("money", "0.01");
                        sendBroadcast(broadCastIntent);
                    }
                });
        this.findViewById(R.id.start_qq).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View arg0) {
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.setAction("com.getway.qq.start");
                        String time = System.currentTimeMillis() / 10000L + "";
                        broadCastIntent.putExtra("mark", "test" + time);
                        broadCastIntent.putExtra("money", "0.01");
                        sendBroadcast(broadCastIntent);
                    }
                });
        this.findViewById(R.id.setting).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View arg0) {
                        Intent intent = new Intent(MainActivity.this, SettingActivity.class);
                        startActivity(intent);
                    }
                });

        tvLogOpen = findViewById(R.id.tv_log_open);
        tvLogOpen.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View arg0) {
                        if (CustomApplcation.isSaveLogTofile) {
                            CustomApplcation.isSaveLogTofile = false;
                            //记录，设置为不记录
                            tvLogOpen.setText("开始日志记录");
                            showToast("日志记录功能已关闭");
                        } else {
                            CustomApplcation.isSaveLogTofile = true;
                            //不记录,设置为记录
                            tvLogOpen.setText("关闭日志记录");
                            showToast("日志记录功能已开启");
                        }
                    }
                });
        tvLogAdress = findViewById(R.id.tv_log_address);

        if (CustomApplcation.isSaveLogTofile) {
            //记录，
            tvLogOpen.setText("关闭日志记录");
        } else {
            //不记录,
            tvLogOpen.setText("开始日志记录");
        }
        String pathTemp1 = LogToFile.getFilePath(this) + "/LogsDingding";
        tvLogAdress.setText("地址：/" + pathTemp1);


        tv_alipay_chaxun = findViewById(R.id.tv_alipay_chaxun);
        tv_alipay_chaxun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //查询userid
                Intent broadCastIntent = new Intent();
                broadCastIntent.setAction("com.getway.alipay.start");
                broadCastIntent.putExtra("type", "solidcode");
                broadCastIntent.putExtra("messageuuid", "" + (int) (Math.random() * 1000000));
                sendBroadcast(broadCastIntent);
            }
        });
        tv_alipay_chaxun1 = findViewById(R.id.tv_alipay_chaxun1);

        //注册广播
        billReceived = new BillReceived();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(OPEN_REDPACK_ACTION);
        intentFilter.addAction(BILLRECEIVED_ACTION);
        intentFilter.addAction(MSGRECEIVED_ACTION);
        intentFilter.addAction(QRCODERECEIVED_ACTION);
        intentFilter.addAction(TRADENORECEIVED_ACTION);
        intentFilter.addAction(LOGINIDRECEIVED_ACTION);
        intentFilter.addAction(SAVEALIPAYCOOKIE_ACTION);
        intentFilter.addAction(zhifubao_uid_action);
        intentFilter.addAction(zhifubao_cook_action);
        intentFilter.addAction(baohuo_action);
        intentFilter.addAction(ALIPAY_HTML);
        registerReceiver(billReceived, intentFilter);

        alipaykeyColect = (EditText) this.findViewById(R.id.dt_alipay_key);
        String dingding_key = AbSharedUtil.getString2(MainActivity.this, "dingding_key");

        //登录类型
        int login_type = AbSharedUtil.getInt(MainActivity.this, "login_type");
        //授权码返回的key
        String channels_key = SPUtils.getInstance().getString("channels_key");

        if (login_type == 2) {
            sendmsg("当前为授权码登录方式，已自动保存通道ID，请勿修改！");
            alipaykeyColect.setText(channels_key);
            String sava_key = alipaykeyColect.getText().toString().trim();
            if (!TextUtils.isEmpty(sava_key)) {
                AbSharedUtil.putString(getApplicationContext(), "dingding_key", sava_key);
            }
        } else {
            alipaykeyColect.setText(dingding_key);
        }

        start = (Button) this.findViewById(R.id.start_app);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String alipay_colec = alipaykeyColect.getText().toString().trim();
                if (!TextUtils.isEmpty(alipay_colec)) {
                    AbSharedUtil.putString(getApplicationContext(), "dingding_key", alipay_colec);
                    Toast.makeText(MainActivity.this, "保存成功", Toast.LENGTH_SHORT).show();
                }

            }
        });


        logout = (TextView) this.findViewById(R.id.tv_home_logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new CommonDialog(MainActivity.this, "是否退出当前账号？", new CommonDialog.onButtonCLickListener() {
                    @Override
                    public void onActivityButtonClick(int position) {
                        if (position == 1) {
                            websocketClosed();
                            SPUtils.getInstance().clear();
                            startIntent(LoginActivity.class);
                            finish();
                        }
                    }
                }).show();
            }
        });

        stop = (Button) this.findViewById(R.id.stop_app);
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //
                String dingding_key = "";
                if (!TextUtils.isEmpty(AbSharedUtil.getString2(getApplicationContext(), "dingding_key"))) {
                    dingding_key = (AbSharedUtil.getString2(getApplicationContext(), "dingding_key"));
                }

                String alipay_colec = alipaykeyColect.getText().toString().trim();
                if (userid_now == null || userid_now.equals("") || userid_now.equals("null")) {
                    Toast.makeText(MainActivity.this, "请先查询支付宝uid", Toast.LENGTH_SHORT).show();
                } else if (alipay_colec.equals("")) {
                    //
                    Toast.makeText(MainActivity.this, "请填写通道key值", Toast.LENGTH_SHORT).show();
                } else if (!dingding_key.equals(alipay_colec)) {
                    Toast.makeText(MainActivity.this, "请点击通道值上得保存按钮", Toast.LENGTH_SHORT).show();
                } else {


                    if (CustomApplcation.nowState == 2) {
                        //关闭
                        CustomApplcation.isStart = false;
                        CustomApplcation.nowState = 0;
                        //关闭定时器，关闭socket
                        stop.setText("启动");
                        sendmsg("关闭通道成功");
                        Toast.makeText(MainActivity.this, "关闭成功", Toast.LENGTH_SHORT).show();
                        websocketClosed();
                    } else if (CustomApplcation.nowState == 1) {
                        Toast.makeText(MainActivity.this, "正在启动请稍等", Toast.LENGTH_SHORT).show();
                        CustomApplcation.nowState = 0;//
                    } else if (CustomApplcation.nowState == 0) {
                        //启动
                        CustomApplcation.nowState = 1;//设置为启动中，防止多次点击进入


                        //启动定时器，（保活，后台通道在线）启动socket
                        if (!TextUtils.isEmpty(alipay_colec)) {

                            if (GetApksTask.getVersionDingDing(MainActivity.this).equals("10.1.35.828")) {
                                if (PayHelperUtils.isAppRunning(MainActivity.this, "com.eg.android.AlipayGphone")) {
                                    sendmsg("启动支付宝通道成功");
                                    handlerTempTest.removeCallbacks(runnableTempTest);
                                    handlertest.removeCallbacks(runnabletest);
                                    handlertest.postDelayed(runnabletest, 1000);
                                    handlerTempTest.postDelayed(runnableTempTest, 1000);

                                    websocketInit(new WebsocketListener() {
                                        @Override
                                        public void onSuccessful() {

                                        }

                                        @Override
                                        public void onFailure() {

                                        }
                                    });
                                    CustomApplcation.nowState = 2;//设置为已经打开
                                    CustomApplcation.isStart = true;
                                    stop.setText("关闭");
                                    Toast.makeText(MainActivity.this, "启动成功", Toast.LENGTH_SHORT).show();
                                    PayHelperUtils.startAPP();
                                } else {
                                    Toast.makeText(MainActivity.this, "支付宝未打开", Toast.LENGTH_SHORT).show();
                                    PayHelperUtils.sendmsg(MainActivity.this, "支付宝未打开");
                                }
                            } else {
                                Toast.makeText(MainActivity.this, "支付宝版本不是10.1.35.828", Toast.LENGTH_SHORT).show();
                                PayHelperUtils.sendmsg(MainActivity.this, "支付宝版本不是10.1.35.828");
                            }

                        }

                    }


                }
            }
        });
    }


    public void startConnect() {

    }

    //增加回调，打开了，和关闭了，
    public void websocketInit(final WebsocketListener websocketListener) {

//                timer.schedule(task, 0, 30000);

        try {
            client = new SocketClient(this, new URI(CustomApplcation.base_socketurl));
            client.setSocketListener(new SocketListener() {

                @Override
                public void onOpen() {
                    websocketListener.onSuccessful();
                }

                @Override
                public void closed() {
                    websocketListener.onFailure();
                }

                @Override
                public void onError() {
                }

                @Override
                public void tostToMain(String message) {
                    sendmsg(message);

//                    (MainActivity.this).runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            //已在主线程中，可以更新UI
//                            CustomApplcation.isStart = false;
//                            CustomApplcation.nowState = 0;
//                            //关闭定时器，关闭socket
//                            stop.setText("启动");
//                            sendmsg("关闭通道成功");
//                            Toast.makeText(MainActivity.this, "关闭成功", Toast.LENGTH_SHORT).show();
//                            websocketClosed();
//                        }
//                    });
                }

                @Override
                public void getDingQrPayurl(String keyid, String messageuuid, String money, String mark) {
                    Intent broadCastIntent = new Intent();
                    broadCastIntent.putExtra("remark", mark);
                    broadCastIntent.putExtra("money", money);
                    broadCastIntent.putExtra("orderid", "");
                    broadCastIntent.putExtra("type", "dingding");
                    broadCastIntent.setAction("com.tools.getway.dindingstart");
                    sendBroadcast(broadCastIntent);
                }

                @Override
                public void getToAlipayHtml(String keyid, String messageuuid, String money, String mark, String bankCode) {
                    Log.e("00获取的数据：", "点击1");
                    Intent broadCastIntent2 = new Intent();
                    broadCastIntent2.setAction("com.getway.alipay.start");
                    broadCastIntent2.putExtra("type", "getHtml");
                    broadCastIntent2.putExtra("mark", mark);
                    broadCastIntent2.putExtra("money", money);
                    broadCastIntent2.putExtra("bankCode", bankCode);//建设银行
                    sendBroadcast(broadCastIntent2);
                    Log.e("00获取的数据：", "点击");
                }

                @Override
                public void tostToOpenRedpack(String ddsenter, String ddno, String keyid) {
                    String dingding_key = "";

                    if (!TextUtils.isEmpty(AbSharedUtil.getString2(getApplicationContext(), "dingding_key"))) {
                        dingding_key = (AbSharedUtil.getString2(getApplicationContext(), "dingding_key"));

                    }
                    if (dingding_key.equals(keyid)) {//打开红包
                        getRedPack(ddsenter, ddno);
                    }
                }

                @Override
                public void onMessageIp(final String msg) {
                    (MainActivity.this).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //已在主线程中，可以更新UI
                            ipMessage.setText(msg + "");
                            //网关状态最好从后台获取，否则依赖通道下发的指令去设置，启动的时候也无法判断网关是否开启了，需要socket实时
                        }
                    });
                }

                @Override
                public void onMessageIpError(final String msg) {
                    System.out.println("开始显示错误信息");
                    (MainActivity.this).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            MainActivity.this.showDialog1(msg);

                        }
                    });
                }
            });
            client.connect();

        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }


    public void websocketClosed() {
//        timer.cancel();
//        timer1.cancel();
        handlerTempTest.removeCallbacks(runnableTempTest);
        handlertest.removeCallbacks(runnabletest);
        if (client != null) {
            client.close();
        }
    }

    public static Handler handler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            String txt = msg.getData().getString("log");
            if (console != null) {
                if (console.getText() != null) {
                    if (console.getText().toString().length() > 200000) {
                        console.setText("日志定时清理完成..." + "\n\n" + txt);
                    } else {
                        console.setText(console.getText().toString() + "\n\n" + txt);
                    }
                } else {
                    console.setText(txt);
                }
                scrollView.post(new Runnable() {
                    public void run() {
                        scrollView.fullScroll(View.FOCUS_DOWN);
                    }
                });
            }
            super.handleMessage(msg);
        }

    };

    @Override
    protected void onDestroy() {
        //unregisterReceiver(alarmReceiver);
        unregisterReceiver(billReceived);
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }


    public static void sendmsg(String txt) {
        LogToFile.i("getway", txt);
        Message msg = new Message();
        msg.what = 1;
        Bundle data = new Bundle();
        long l = System.currentTimeMillis();
        Date date = new Date(l);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String d = dateFormat.format(date);
        data.putString("log", d + ":" + " " + txt);
        msg.setData(data);
        try {
            handler.sendMessage(msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // 过滤按键动作
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            moveTaskToBack(true);
        }
        return super.onKeyDown(keyCode, event);
    }

    public void dingding(View view) {
        Intent intent = new Intent("com.tools.getway.dindingstart");
        intent.putExtra("type", "getuserid");
        sendBroadcast(intent);
    }

    static Vector<String> payListOrder = new Vector<String>();

    //自定义接受订单通知广播
    class BillReceived extends BroadcastReceiver {
        @Override
        public void onReceive(final Context context, Intent intent) {
            try {
                if (intent.getAction().contentEquals(zhifubao_cook_action)) {
                    String cook = intent.getStringExtra("cook");
                    sendmsg("当前支付宝cook为" + cook);
                    usercook_now=cook;
                } else if (intent.getAction().contentEquals(zhifubao_uid_action)) {
                    String messageid = intent.getStringExtra("messageuuid");
                    if (payListOrder.contains(messageid)) {
                        return;
                    } else {

                        payListOrder.add(messageid);

                        String userid = intent.getStringExtra("userid");
                        sendmsg("当前支付宝userid为" + userid);
                        userid_now = userid;
                        PayHelperUtils.startAPP();
                        tv_alipay_chaxun1.setText("支付宝uid：" + userid_now);
                    }


                } else if (intent.getAction().contentEquals(baohuo_action)) {
                    String messageid = intent.getStringExtra("messageuuid");
                    if (payListOrder.contains(messageid)) {
                        return;
                    } else {

                        payListOrder.add(messageid);

                        PayHelperUtils.startAPP();
                        System.out.println("保活结束");

                    }


                } else if (intent.getAction().contentEquals(ALIPAY_HTML)) {

                    String content = intent.getStringExtra("content");
                    String content_error = intent.getStringExtra("content_error");
                    String epccGwMsg = intent.getStringExtra("epccGwMsg");
                    String actionStr = intent.getStringExtra("actionStr");
                    String batchNo = intent.getStringExtra("batchNo");
                    String bankCode = intent.getStringExtra("bankCode");
                    String money = intent.getStringExtra("money");
                    String mark = intent.getStringExtra("mark");

                    if (content_error != null && !content_error.equals("")) {
                        sendmsg("获取HTML失败\n金额：" + money + "\n" + "银行码:" + bankCode + "\n备注: " + mark + "\n订单号: " + batchNo);
                    } else {
                        sendmsg("获取HTML成功\n金额：" + money + "\n" + "银行码:" + bankCode + "\n备注: " + mark + "\n订单号: " + batchNo + "\n订单参数: " + epccGwMsg + "\n银行参数: " + actionStr);

                    }
                    System.out.println("生成成功1");

                    //发送给后台
                    try {
//                      {"params":{"payurl":"https:\/\/qr.alipay.com\/fkx00013suzjxkgs589856s95?t=1545645515621","mark":"15|2247","money":"1"},"type":"uploadQrCodeDingding"}
                        String dingding_key = "";


                        if (!TextUtils.isEmpty(AbSharedUtil.getString2(getApplicationContext(), "dingding_key"))) {
                            dingding_key = (AbSharedUtil.getString2(getApplicationContext(), "dingding_key"));
                        }

                        if (client == null) {
                        } else if (client.isOpen()) {
                            JSONObject object = new JSONObject();//创建一个总的对象，这个对象对整个json串
                            JSONObject jsonObj = new JSONObject();//pet对象，json形式
                            jsonObj.put("messageuuid", "" + "" + (int) (Math.random() * 1000000));//向pet对象里面添加值
                            jsonObj.put("dt", "" + "" + System.currentTimeMillis());

                            jsonObj.put("money", money); //money
                            jsonObj.put("mark", mark); //mark
                            jsonObj.put("batchNo", batchNo); //batchNo
                            jsonObj.put("bankCode", bankCode); //bankCode
                            jsonObj.put("payhtml", content); //html
                            jsonObj.put("payhtml_error", content_error); //html
                            jsonObj.put("epccGwMsg", epccGwMsg); //epccGwMsg
                            jsonObj.put("actionStr", actionStr); //actionStr

                            jsonObj.put("phoneId", getPesudoUniqueID()); //设备唯一ID
                            jsonObj.put("key_id", dingding_key);
                            jsonObj.put("merchant_id", SPUtils.getInstance().getString(MERCHANTSID, ""));//码商ID

                            object.put("params", jsonObj);//向总对象里面添加包含pet的数组
                            object.put("type", "postAlipayHtml");


                            System.out.println("发送生成HTML到后台=" + CustomApplcation.isStart + "   " + object.toString());
                            //启动，就开始发送，
                            if (CustomApplcation.isStart == true) {
                                sendmsg("发送生成HTML消息到服务器：\n" + object.toString());
                                LogToFile.e("socketSendGetUrl", object.toString());
                                client.send(object.toString());
                            }

                        } else {
                            if (CustomApplcation.isStart == true) {
                                websocketInit(new WebsocketListener() {
                                    @Override
                                    public void onSuccessful() {

                                    }

                                    @Override
                                    public void onFailure() {

                                    }
                                });
                            }

                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                } else if (intent.getAction().contentEquals(BILLRECEIVED_ACTION)) {
                    System.out.println("收到广播了，");

                    //银行卡转支付宝
                    String no = intent.getStringExtra("bill_no");
                    String money = intent.getStringExtra("bill_money");
                    String mark = intent.getStringExtra("bill_mark");
                    //String from_u_id = intent.getStringExtra("from_u_id");

                    System.out.println("收到--------------------------------------------------" + money);

                    sendmsg("收到支付宝余额充值订单," + "金额：" + money + "备注：" + mark);
//                    notifyapi(type, no, money, mark, dt);
                    try {

                        String dingding_key = "";

                        if (!TextUtils.isEmpty(AbSharedUtil.getString2(getApplicationContext(), "dingding_key"))) {
                            dingding_key = (AbSharedUtil.getString2(getApplicationContext(), "dingding_key"));
                        }

                        if (client == null) {
                        } else if (client.isOpen()) {
                            JSONObject object = new JSONObject();//创建一个总的对象，这个对象对整个json串
                            JSONObject jsonObj = new JSONObject();//pet对象，json形式
                            jsonObj.put("messageuuid", "" + "" + (int) (Math.random() * 1000000));//向pet对象里面添加值
                            jsonObj.put("dt", "" + "" + System.currentTimeMillis());
                            jsonObj.put("no", "" + no);
                            jsonObj.put("money", money);
                            jsonObj.put("key", dingding_key);//通道id
                            jsonObj.put("mark", mark);//平台订单备注
                            //jsonObj.put("from_u_id", from_u_id);//付款方得userid

                            jsonObj.put("phoneId", getPesudoUniqueID());//s设备id
                            jsonObj.put("merchant_id", SPUtils.getInstance().getString(MERCHANTSID, ""));//码商ID

                            object.put("params", jsonObj);//向总对象里面添加包含pet的数组

                            object.put("type", "notifyurltoAlipay");
//                    int x = (int) (Math.random() * 1000000);
//                    object.put("code_id", "" + x);
//                    随机id
                            //{"params":{"messageuuid":"736266","dt":"1555400347873",,"money":"1.00","key":"18922299184","nick":"heng","phoneId":"356517454699244","merchant_id":"1"},"type":"notifyurlwechat"}


                            System.out.println("发送收到支付宝消息=" + CustomApplcation.isStart + "   " + object.toString());
                            //启动，就开始发送，
                            if (CustomApplcation.isStart == true) {
                                sendmsg("发送收到支付宝余额充值订单:\n" + object.toString());
                                LogToFile.e("socketSendGetMoney", object.toString());
                                client.send(object.toString());
                            }

                        } else {
                            if (CustomApplcation.isStart == true) {
                                websocketInit(new WebsocketListener() {
                                    @Override
                                    public void onSuccessful() {

                                    }

                                    @Override
                                    public void onFailure() {

                                    }
                                });
                            }

                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else if (intent.getAction().contentEquals(OPEN_REDPACK_ACTION)) {

                    //拆开红包判断,首先判断是否当前拆开红包
                    String senter = intent.getStringExtra("senter");//发送者
                    String no = intent.getStringExtra("no");//单号
                    System.out.println("拆开红包3=obj3=" + senter + "  obj4=" + no + "   boolean=" + CustomApplcation.isCanOpenRedPack);
                    if (CustomApplcation.isCanOpenRedPack) {
                        //当前账号直接领取
                        sendmsg("开始领取红包:发送id" + senter + "红包id:" + no);
                        getRedPack(senter, no);
                    } else {
                        //后台通知其他通道领取
                        try {
                            String dingding_key = "";
                            if (!TextUtils.isEmpty(AbSharedUtil.getString2(getApplicationContext(), "dingding_key"))) {
                                dingding_key = (AbSharedUtil.getString2(getApplicationContext(), "dingding_key"));
                            }
                            sendmsg("通知后台其他通道领取红包：" + senter + "红包id:" + no);
                            if (client == null) {
                            } else if (client.isOpen()) {
                                JSONObject object = new JSONObject();//创建一个总的对象，这个对象对整个json串
                                JSONObject jsonObj = new JSONObject();//pet对象，json形式
                                jsonObj.put("messageuuid", "" + "" + (int) (Math.random() * 1000000));//向pet对象里面添加值
                                jsonObj.put("dt", "" + "" + System.currentTimeMillis());
                                jsonObj.put("ddsenter", senter + "");
                                jsonObj.put("ddno", no);
                                jsonObj.put("key", dingding_key);//通道id
                                jsonObj.put("merchant_id", SPUtils.getInstance().getString(MERCHANTSID, ""));//码商ID

                                object.put("params", jsonObj);//向总对象里面添加包含pet的数组

                                object.put("type", "forwarding_dingding");

                                System.out.println("通知其他通道领取钉钉红包=" + CustomApplcation.isStart + "   " + object.toString());
//                                {
//                                    "params":{
//                                    "messageuuid":"消息id",
//                                            "dt":"时间戳",
//                                            "ddsenter":"红包生成者",
//                                            "no":"红包",
//                                            "key":"通道id",
//                                            "dingdingMiantatus", "1"
//                                },
//                                    "type":"forwarding_dingding"
//                                }
                                //启动，就开始发送，
                                if (CustomApplcation.isStart == true) {
                                    sendmsg("转发其他通道领取钉钉红包:\n" + object.toString());
                                    LogToFile.e("socketTranferDingdingMoney", object.toString());
                                    client.send(object.toString());
                                }

                            } else {
                                if (CustomApplcation.isStart == true) {
                                    websocketInit(new WebsocketListener() {
                                        @Override
                                        public void onSuccessful() {

                                        }

                                        @Override
                                        public void onFailure() {

                                        }
                                    });
                                }

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                } else if (intent.getAction().contentEquals(QRCODERECEIVED_ACTION)) {
                    String money = intent.getStringExtra("money");
                    String mark = intent.getStringExtra("mark");
                    String type = intent.getStringExtra("type");
                    String payurl = intent.getStringExtra("payurl");
//                    DBManager dbManager = new DBManager(CustomApplcation.getInstance().getApplicationContext());
//                    String dt = System.currentTimeMillis() + "";
//                    DecimalFormat df = new DecimalFormat("0.00");
//                    money = df.format(Double.parseDouble(money));
//                    dbManager.addQrCode(new QrCodeBean(money, mark, type, payurl, dt));
                    sendmsg("生成成功,金额:" + money + "备注:" + mark + "二维码:" + payurl);

                    if (!type.equals("dingding")) {

                    } else {


                        //发送给后台
                        try {
//                      {"params":{"payurl":"https:\/\/qr.alipay.com\/fkx00013suzjxkgs589856s95?t=1545645515621","mark":"15|2247","money":"1"},"type":"uploadQrCodeDingding"}
                            String dingding_key = "";


                            if (!TextUtils.isEmpty(AbSharedUtil.getString2(getApplicationContext(), "dingding_key"))) {
                                dingding_key = (AbSharedUtil.getString2(getApplicationContext(), "dingding_key"));
                            }

                            if (client == null) {
                            } else if (client.isOpen()) {
                                JSONObject object = new JSONObject();//创建一个总的对象，这个对象对整个json串
                                JSONObject jsonObj = new JSONObject();//pet对象，json形式
                                jsonObj.put("messageuuid", "" + "" + (int) (Math.random() * 1000000));//向pet对象里面添加值
                                jsonObj.put("dt", "" + "" + System.currentTimeMillis());

                                jsonObj.put("mark", "" + mark);
                                jsonObj.put("money", money);//
                                jsonObj.put("payurl", payurl);//
                                jsonObj.put("key_id", dingding_key);
                                jsonObj.put("merchant_id", SPUtils.getInstance().getString(MERCHANTSID, ""));//码商ID

                                object.put("params", jsonObj);//向总对象里面添加包含pet的数组
                                object.put("type", "postUploadQrCodeDingding");


                                System.out.println("发送生成钉钉消息到后台=" + CustomApplcation.isStart + "   " + object.toString());
                                //启动，就开始发送，
                                if (CustomApplcation.isStart == true) {
                                    sendmsg("发送生成钉钉消息到服务器：\n" + object.toString());
                                    LogToFile.e("socketSendGetUrl", object.toString());
                                    client.send(object.toString());
                                }

                            } else {
                                if (CustomApplcation.isStart == true) {
                                    websocketInit(new WebsocketListener() {
                                        @Override
                                        public void onSuccessful() {

                                        }

                                        @Override
                                        public void onFailure() {

                                        }
                                    });
                                }

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                } else if (intent.getAction().contentEquals(MSGRECEIVED_ACTION)) {
                    String msg = intent.getStringExtra("msg");
                    sendmsg(msg);
                } else if (intent.getAction().contentEquals(SAVEALIPAYCOOKIE_ACTION)) {
                    String cookie = intent.getStringExtra("alipaycookie");
                    PayHelperUtils.updateAlipayCookie(MainActivity.this, cookie);
                } else if (intent.getAction().contentEquals(LOGINIDRECEIVED_ACTION)) {
                    String loginid = intent.getStringExtra("loginid");
                    String type = intent.getStringExtra("type");
                    if (!TextUtils.isEmpty(loginid)) {
                        if (type.equals("wechat") && !loginid.equals(currentWechat)) {
                            //sendmsg("当前登录微信账号：" + loginid);
                            currentWechat = loginid;
                            AbSharedUtil.putString(getApplicationContext(), type, loginid);
                        } else if (type.equals("alipay") && !loginid.equals(currentAlipay)) {
                            //sendmsg("当前登录支付宝账号：" + loginid);
                            currentAlipay = loginid;
                            AbSharedUtil.putString(getApplicationContext(), type, loginid);
                        } else if (type.equals("qq") && !loginid.equals(currentQQ)) {
                            //sendmsg("当前登QQ账号：" + loginid);
                            currentQQ = loginid;
                            AbSharedUtil.putString(getApplicationContext(), type, loginid);
                        } else {
                            //sendmsg("当前登 " + loginid);
                            currentQQ = loginid;
                            AbSharedUtil.putString(getApplicationContext(), type, loginid);
                        }
                    }
                } else if (intent.getAction().contentEquals(TRADENORECEIVED_ACTION)) {
                    //商家服务
                    final String tradeno = intent.getStringExtra("tradeno");
                    String cookie = intent.getStringExtra("cookie");
                    final DBManager dbManager = new DBManager(CustomApplcation.getInstance().getApplicationContext());
                    if (!dbManager.isExistTradeNo(tradeno)) {
                        dbManager.addTradeNo(tradeno, "0");
                        String url = "https://tradeeportlet.alipay.com/wireless/tradeDetail.htm?tradeNo=" + tradeno + "&source=channel&_from_url=https%3A%2F%2Frender.alipay.com%2Fp%2Fz%2Fmerchant-mgnt%2Fsimple-order._h_t_m_l_%3Fsource%3Dmdb_card";
                        try {
                            HttpUtils httpUtils = new HttpUtils(15000);
                            httpUtils.configResponseTextCharset("GBK");
                            RequestParams params = new RequestParams();
                            params.addHeader("Cookie", cookie);

                            httpUtils.send(HttpMethod.GET, url, params, new RequestCallBack<String>() {

                                @Override
                                public void onFailure(HttpException arg0, String arg1) {
                                    PayHelperUtils.sendmsg(context, "服务器异常" + arg1);
                                }

                                @Override
                                public void onSuccess(ResponseInfo<String> arg0) {
                                    try {
                                        String result = arg0.result;
                                        Document document = Jsoup.parse(result);
                                        Elements elements = document.getElementsByClass("trade-info-value");
                                        if (elements.size() >= 5) {
                                            dbManager.updateTradeNo(tradeno, "1");
                                            String money = document.getElementsByClass("amount").get(0).ownText().replace("+", "").replace("-", "");
                                            String mark = elements.get(3).ownText();
                                            String dt = System.currentTimeMillis() + "";
                                            dbManager.addOrder(new OrderBean(money, mark, "alipay", tradeno, dt, "", 0));
                                            sendmsg("收到支付宝订单,订单号：" + tradeno + "金额：" + money + "备注：" + mark);
                                            notifyapi("alipay", tradeno, money, mark, dt);
                                        }
                                    } catch (Exception e) {
                                        PayHelperUtils.sendmsg(context, "TRADENORECEIVED_ACTION-->>onSuccess异常" + e.getMessage());
                                    }
                                }
                            });
                        } catch (Exception e) {
                            PayHelperUtils.sendmsg(context, "TRADENORECEIVED_ACTION异常" + e.getMessage());
                        }
                    }
                }
            } catch (Exception e) {
                PayHelperUtils.sendmsg(context, "BillReceived异常" + e.getMessage());
            }
        }

        public void notifyapi(String type, final String no, String money, String mark, String dt) {
            try {
                String notifyurl = AbSharedUtil.getString(getApplicationContext(), "notifyurl");
                String signkey = AbSharedUtil.getString(getApplicationContext(), "signkey");
                String custom = AbSharedUtil.getString(getApplicationContext(), "custom");
                if (TextUtils.isEmpty(notifyurl) || TextUtils.isEmpty(signkey)) {
                    sendmsg("发送异步通知异常，异步通知地址为空");
                    update(no, "异步通知地址为空");
                    return;
                }

                String account = "";
                if (type.equals("alipay")) {
                    account = AbSharedUtil.getString(getApplicationContext(), "alipay");
                } else if (type.equals("wechat")) {
                    account = AbSharedUtil.getString(getApplicationContext(), "wechat");
                } else if (type.equals("qq")) {
                    account = AbSharedUtil.getString(getApplicationContext(), "qq");
                }

                HttpUtils httpUtils = new HttpUtils(15000);

                String sign = MD5.md5(dt + mark + money + no + type + signkey);
                RequestParams params = new RequestParams();
                params.addBodyParameter("type", type);
                params.addBodyParameter("no", no);
                params.addBodyParameter("money", money);
                params.addBodyParameter("mark", mark);
                params.addBodyParameter("dt", dt);
                params.addBodyParameter("custom", custom);


                sendmsg("收到支付宝支付订单," + "金额：" + money + "备注：" + mark);
//                    notifyapi(type, no, money, mark, dt);
                try {

                    String dingding_key = "";

                    if (!TextUtils.isEmpty(AbSharedUtil.getString2(getApplicationContext(), "dingding_key"))) {
                        dingding_key = (AbSharedUtil.getString2(getApplicationContext(), "dingding_key"));
                    }

                    if (client == null) {
                    } else if (client.isOpen()) {
                        JSONObject object = new JSONObject();//创建一个总的对象，这个对象对整个json串
                        JSONObject jsonObj = new JSONObject();//pet对象，json形式
                        jsonObj.put("messageuuid", "" + "" + (int) (Math.random() * 1000000));//向pet对象里面添加值
                        jsonObj.put("dt", "" + "" + System.currentTimeMillis());
                        jsonObj.put("no", "" + no);
                        jsonObj.put("money", money);
                        jsonObj.put("key", dingding_key);//通道id
                        jsonObj.put("mark", mark);//平台订单备注

                        jsonObj.put("phoneId", getPesudoUniqueID());//s设备id
                        jsonObj.put("merchant_id", SPUtils.getInstance().getString(MERCHANTSID, ""));//码商ID

                        object.put("params", jsonObj);//向总对象里面添加包含pet的数组

                        object.put("type", "notifyurltransfer");
//                    int x = (int) (Math.random() * 1000000);
//                    object.put("code_id", "" + x);
//                    随机id


                        System.out.println("发送收到支付宝消息=" + CustomApplcation.isStart + "   " + object.toString());
                        //启动，就开始发送，
                        if (CustomApplcation.isStart == true) {
                            sendmsg("发送收到支付宝支付订单:\n" + object.toString());
                            LogToFile.e("socketSendGetMoney", object.toString());
                            client.send(object.toString());
                        }

                    } else {
                        if (CustomApplcation.isStart == true) {
                            websocketInit(new WebsocketListener() {
                                @Override
                                public void onSuccessful() {

                                }

                                @Override
                                public void onFailure() {

                                }
                            });
                        }

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                //这里发送给后台

//                if (!TextUtils.isEmpty(account)) {
//                    params.addBodyParameter("account", account);
//                }
//                params.addBodyParameter("sign", sign);
//                httpUtils.send(HttpMethod.POST, notifyurl, params, new RequestCallBack<String>() {
//
//                    @Override
//                    public void onFailure(HttpException arg0, String arg1) {
//                        sendmsg("发送异步通知异常，服务器异常" + arg1);
//                        update(no, arg1);
//                    }
//
//                    @Override
//                    public void onSuccess(ResponseInfo<String> arg0) {
//                        String result = arg0.result;
//                        if (result.contains("success")) {
//                            sendmsg("发送异步通知成功，服务器返回" + result);
//                        } else {
//                            sendmsg("发送异步通知失败，服务器返回" + result);
//                        }
//                        update(no, result);
//                    }
//                });
            } catch (Exception e) {
                sendmsg("notifyapi异常" + e.getMessage());
            }
        }

        private void update(String no, String result) {
            DBManager dbManager = new DBManager(CustomApplcation.getInstance().getApplicationContext());
            dbManager.updateOrder(no, result);
        }
    }

    public static String getPesudoUniqueID() {
        String m_szDevIDShort = "35" + //we make this look like a valid IMEI
                Build.BOARD.length() % 10 +
                Build.BRAND.length() % 10 +
                Build.CPU_ABI.length() % 10 +
                Build.DEVICE.length() % 10 +
                Build.DISPLAY.length() % 10 +
                Build.HOST.length() % 10 +
                Build.ID.length() % 10 +
                Build.MANUFACTURER.length() % 10 +
                Build.MODEL.length() % 10 +
                Build.PRODUCT.length() % 10 +
                Build.TAGS.length() % 10 +
                Build.TYPE.length() % 10 +
                Build.USER.length() % 10; //13 digits
        System.out.println("当前的唯一设备id" + m_szDevIDShort);
        return m_szDevIDShort;
    }

    public void getRedPack(String senter, String no) {
        System.out.println("广播出去打开红包========");
        //广播出去领取红包
        Intent broadCastIntent = new Intent();
        broadCastIntent.putExtra("senter", senter);
        broadCastIntent.putExtra("no", no);
        broadCastIntent.putExtra("type", "dingding_openredpack");
        broadCastIntent.setAction("com.tools.getway.dindingstart");
        sendBroadcast(broadCastIntent);
    }
}
