package com.example.music.custom;

import android.content.Context;
import android.widget.TextView;

/**
 * Created by iwanghang on 16/5/12.
 */
public class PlayView extends androidx.appcompat.widget.AppCompatTextView {
    private String TtileText = "歌名";

    public PlayView(Context context) {
        super(context);
    }

    @Override
    public void setText(CharSequence text, BufferType type) {
        super.setText(text, type);
    }

    public String getTtileText() {
        return TtileText;
    }

    public void setTtileText(String text){
        TtileText = text;
    }


}
