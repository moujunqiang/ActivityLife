package com.example.music.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.music.R;
import com.example.music.utils.MediaUtils;
import com.example.music.vo.Mp3Info;
import com.example.music.vo.SearchResult;

import java.util.ArrayList;


public class NetMusicListAdapter extends BaseAdapter{

    private Context ctx; //上下文对象引用
    private ArrayList<SearchResult> searchResults;//存放SearchResult引用的集合
    private SearchResult searchResult;//SearchResult对象引用

    public NetMusicListAdapter(Context ctx, ArrayList<SearchResult> searchResults){
        this.ctx = ctx;
        this.searchResults = searchResults;
    }

    public ArrayList<SearchResult> searchResults() {
        System.out.println("NetMusicListAdapter.java #1 : public ArrayList<SearchResult> searchResults() {");
        return searchResults;
    }

    public void setSearchResults(ArrayList<SearchResult> searchResults) {
        System.out.println("NetMusicListAdapter.java #2 : public void setMp3Infos(ArrayList<SearchResult> searchResults) {");
        this.searchResults = searchResults;
    }

    public ArrayList<SearchResult> getSearchResults() {
        return searchResults;
    }

    @Override
    public int getCount() {
        //System.out.println("NetMusicListAdapter.java #3 : public int getCount() {" + mp3Infos.size());
        //return mp3Infos.size();
        return searchResults.size();
    }

    @Override
    public Object getItem(int position) {
        System.out.println("NetMusicListAdapter.java #4 : public Object getItem(int position) {");
        return searchResults.get(position);
    }

    @Override
    public long getItemId(int position) {
        //System.out.println("NetMusicListAdapter.java #5 : public long getItemId(int position) {");
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //System.out.println("NetMusicListAdapter.java #6 : public View getView ");
        ViewHolder vh;
        if(convertView==null){
            //vh = new ViewHolder();
            convertView = LayoutInflater.from(ctx).inflate(R.layout.item_net_music_list,null);
            vh = new ViewHolder();
            vh.textView1_title = (TextView) convertView.findViewById(R.id.textView1_title);
            vh.textView2_singer = (TextView) convertView.findViewById(R.id.textView2_singer);
            //vh.textView3_time = (TextView) convertView.findViewById(R.id.textView3_time);
            //vh.imageView1_ablum = (ImageView) convertView.findViewById(R.id.imageView1_ablum);

            //System.out.println("NetMusicListAdapter.java #7 : textView1_title = " + vh.textView1_title);
            convertView.setTag(vh);//表示给View添加一个格外的数据，
        }else {
            vh = (ViewHolder)convertView.getTag();//通过getTag的方法将数据取出来
        }

        SearchResult searchResult = searchResults.get(position);
        vh.textView1_title.setText(searchResult.getMusicName());//显示标题
        vh.textView2_singer.setText(searchResult.getArtist());

        return convertView;
    }

    static class ViewHolder{
        //所有控件对象引用
        TextView textView1_title;//标题
        TextView textView2_singer;//歌手
    }
}